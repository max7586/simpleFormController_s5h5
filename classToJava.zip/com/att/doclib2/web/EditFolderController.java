package com.att.doclib2.web;

import com.att.doclib2.domain.Folder;
import com.att.doclib2.domain.FolderAccess;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.FusionFormController;
import com.att.fusion.web.support.UserUtils;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class EditFolderController extends FusionFormController {
	public Object formBackingObject(HttpServletRequest request) {
		this.logger.debug("FolderController - formBackingObject");
		long folderId = ServletRequestUtils.getLongParameter(request, "folderId", 0L);
		Folder folder;
		if (folderId == 0L) {
			long parentFolderId = ServletRequestUtils.getLongParameter(request, "parentFolderId", 0L);
			folder = new Folder();
			folder.setParentFolderId(new Long(parentFolderId));
		} else {
			folder = (Folder) this.getDomainService().getDomainObject(Folder.class, new Long(folderId));
		}

		return folder;
	}

	public ModelAndView save(HttpServletRequest request, HttpServletResponse response, Object command,
			ModelAndView modelView, BindException errors) throws Exception {
		Folder folder = (Folder) command;
		Long userId = UserUtils.getUserIdAsLong(request);
		boolean createFolder = false;
		if (folder.getDescr().length() > 2000) {
			folder.setDescr(folder.getDescr().substring(0, 2000));
		}

		if (folder.getId() == null) {
			createFolder = true;
			folder.setCreated(new Date());
			folder.setCreatedId(userId);
			folder.getAccesses().add(new FolderAccess(folder, (Long) null, userId, new Boolean(false)));
			folder.getAccesses().add(new FolderAccess(folder,
					new Long(SystemProperties.getProperty("doclib_user_role_id")), (Long) null, new Boolean(true)));
		}

		folder.setModified(new Date());
		folder.setModifiedId(userId);
		this.getDomainService().saveDomainObject(folder);
		return new ModelAndView("redirect:doclib.htm?action=displayFolder&folderId=" + folder.getId() + "&createFolder="
				+ (createFolder ? "Y" : "N"));
	}
}