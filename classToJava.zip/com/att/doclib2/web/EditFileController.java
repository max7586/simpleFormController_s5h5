package com.att.doclib2.web;

import com.att.doclib2.domain.File;
import com.att.fusion.web.support.FusionFormController;
import com.att.fusion.web.support.UserUtils;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class EditFileController extends FusionFormController {
	public Object formBackingObject(HttpServletRequest request) throws Exception {
		this.logger.info("EditFileController - formBackingObject");
		Long fileId = ServletRequestUtils.getLongParameter(request, "fileId");
		return this.getDomainService().getDomainObject(File.class, fileId);
	}

	public ModelAndView save(HttpServletRequest request, HttpServletResponse response, Object command,
			ModelAndView modelView, BindException errors) throws Exception {
		this.logger.info("EditFileController - save");
		Long userId = UserUtils.getUserIdAsLong(request);
		File file = (File) command;
		file.setModified(new Date());
		file.setModifiedId(userId);
		this.getDomainService().saveDomainObject(file);
		return new ModelAndView("redirect:doclib.htm?action=displayFolder&folderId=" + file.getFolderId());
	}
}