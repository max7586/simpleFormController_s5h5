package com.att.doclib2.web;

import com.att.doclib2.domain.ContentCommand;
import com.att.doclib2.domain.Url;
import com.att.fusion.dao.support.BatchStep;
import com.att.fusion.web.support.FusionFormController;
import com.att.fusion.web.support.UserUtils;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class AddUrlsController extends FusionFormController {
	public Object formBackingObject(HttpServletRequest request) throws Exception {
		this.logger.info("AddUrlsController - formBackingObject");
		ContentCommand contentCommand = new ContentCommand();
		contentCommand.initUrls();
		return contentCommand;
	}

	public ModelAndView save(HttpServletRequest request, HttpServletResponse response, Object command,
			ModelAndView modelView, BindException errors) throws Exception {
		this.logger.info("AddUrlsController - save");
		Long folderId = ServletRequestUtils.getLongParameter(request, "folderId");
		Long userId = UserUtils.getUserIdAsLong(request);
		ContentCommand contentCommand = (ContentCommand) command;
		LinkedHashSet batch = new LinkedHashSet();
		Iterator i$ = contentCommand.getUrls().iterator();

		while (i$.hasNext()) {
			Url url = (Url) i$.next();
			url.setName(url.getName().trim());
			url.setUrl(url.getUrl().trim());
			if (url.getName().length() != 0 && url.getUrl().length() != 0) {
				url.setFolderId(folderId);
				url.setCreated(new Date());
				url.setCreatedId(userId);
				url.setModified(new Date());
				url.setModifiedId(userId);
				BatchStep batchStep = new BatchStep();
				batchStep.setVo(url);
				batchStep.setType(30);
				batch.add(batchStep);
			}
		}

		if (batch.size() > 0) {
			this.getDomainService().executeBatchUpdate(batch);
			DoclibController.updateFolderModifyInfo(this.getDomainService(), folderId, userId);
		}

		return new ModelAndView("redirect:doclib.htm?action=displayFolder&folderId=" + folderId);
	}
}