package com.att.doclib2.web;

import com.att.doclib2.domain.File;
import com.att.doclib2.domain.Folder;
import com.att.doclib2.domain.FolderAccessForDisplay;
import com.att.doclib2.domain.Url;
import com.att.fusion.service.DomainService;
import com.att.fusion.service.QueryService;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FusionMultiActionController;
import com.att.fusion.web.support.UserUtils;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class DoclibController extends FusionMultiActionController {
	public static final String DOCLIB_ADMIN_ROLE_ID = SystemProperties.getProperty("doclib_admin_role_id");
	public static final String DOCLIB_USER_ROLE_ID = SystemProperties.getProperty("doclib_user_role_id");
	private DomainService domainService;
	private QueryService queryService;

	public DomainService getDomainService() {
		return this.domainService;
	}

	public void setDomainService(DomainService domainService) {
		this.domainService = domainService;
	}

	public QueryService getQueryService() {
		return this.queryService;
	}

	public void setQueryService(QueryService queryService) {
		this.queryService = queryService;
	}

	public ModelAndView displayFrame(HttpServletRequest request, HttpServletResponse response) throws Exception {
		this.logger.debug("displayFrame");
		return new ModelAndView("doclib2/frameset");
	}

	public ModelAndView displayTree(HttpServletRequest request, HttpServletResponse response) throws Exception {
		this.logger.debug("displayTree");
		long rootFolderId = ServletRequestUtils.getLongParameter(request, "rootFolderId", 0L);
		List treeNodeList = getSubFolderList(this.getQueryService(), request, rootFolderId);
		request.setAttribute("treeNodeList", treeNodeList);
		return new ModelAndView("doclib2/tree");
	}

	public static List getSubFolderList(QueryService queryService, HttpServletRequest request, long parentFolderId) {
		Map roles = UserUtils.getRoles(request);
		Map params = new HashMap();
		params.put("userId", UserUtils.getUserIdAsLong(request));
		params.put("parentFolderId", new Long(parentFolderId));
		params.put("roleIdList", roles.keySet());
		return queryService.executeNamedQuery("getTreeNodeList", params);
	}

	public ModelAndView displayTreeNav(HttpServletRequest request, HttpServletResponse response) throws Exception {
		this.logger.debug("displayFrame");
		return new ModelAndView("doclib2/treenav");
	}

	public ModelAndView displayFolder(HttpServletRequest request, HttpServletResponse response) throws Exception {
		this.logger.debug("displayFolder");
		long folderId = ServletRequestUtils.getLongParameter(request, "folderId", 0L);
		if (folderId != 0L) {
			Folder folder = (Folder) this.getDomainService().getDomainObject(Folder.class, new Long(folderId));
			folder.setFiles(
					this.getDomainService().getList(File.class, " where folder_id=" + folderId, " UPPER(name)"));
			folder.setUrls(this.getDomainService().getList(Url.class, " where folder_id=" + folderId, " UPPER(name)"));
			folder.setReadOnly(this.getFolderReadOnly(this.getQueryService(), request, folderId));
			folder.setNeedNotification(
					needNotification(this.getQueryService(), folderId, UserUtils.getUserIdAsLong(request)));
			request.setAttribute("folder", folder);
		}

		return new ModelAndView("doclib2/display_folder");
	}

	public String getFolderReadOnly(QueryService queryService, HttpServletRequest request, long folderId) {
		String readOnly = null;
		Map roles = UserUtils.getRoles(request);
		Map params = new HashMap();
		params.put("folderId", new Long(folderId));
		params.put("userId", UserUtils.getUserIdAsLong(request));
		params.put("roleIdList", roles.keySet());
		this.logger.debug("roleIdList: " + roles.keySet().toString());
		List list = queryService.executeNamedQuery("getFolderReadOnly", params);
		if (list != null && list.size() == 1) {
			readOnly = (String) list.get(0);
		}

		this.logger.debug("readOnly: " + readOnly);
		return readOnly;
	}

	public static void updateFolderModifyInfo(DomainService domainService, Long folderId, Long userId) {
		Folder folder = (Folder) domainService.getDomainObject(Folder.class, folderId);
		folder.setModified(new Date());
		folder.setModifiedId(userId);
		domainService.saveDomainObject(folder);
	}

	public static boolean needNotification(QueryService queryService, Long folderId, Long userId) {
		Map params = new HashMap();
		params.put("folderId", folderId);
		params.put("userId", userId);
		List list = queryService.executeNamedQuery("getNotifyCount", params);
		if (list != null && list.size() > 0) {
			return !((String) list.get(0)).equals("0");
		} else {
			return false;
		}
	}

	public ModelAndView displayFolderAccess(HttpServletRequest request, HttpServletResponse response) throws Exception {
		this.logger.debug("displayFolderAccess");
		Long folderId = ServletRequestUtils.getLongParameter(request, "folderId");
		if (folderId != null) {
			Folder folder = (Folder) this.getDomainService().getDomainObject(Folder.class, new Long(folderId));
			List userList = this.getDomainService().getList(FolderAccessForDisplay.class,
					" where user_id is not null and folder_id=" + folderId, " UPPER(userName)");
			List roleList = this.getDomainService().getList(FolderAccessForDisplay.class,
					" where role_id is not null and folder_id=" + folderId, " UPPER(roleName)");
			request.setAttribute("folder", folder);
			request.setAttribute("userList", userList);
			request.setAttribute("roleList", roleList);
			request.setAttribute("allUsers", AppUtils.getLookupListNoCache("fn_user", "user_id",
					"upper(last_name||', '||first_name)", "active_yn='Y'", ""));
			request.setAttribute("allRoles", AppUtils.getLookupList("fn_role", "role_id", "role_name", "", ""));
		}

		return new ModelAndView("doclib2/folder_access");
	}

	public static void sendEmailNotification(QueryService queryService, DomainService domainService, Long folderId,
			String msg) {
		Map params = new HashMap();
		params.put("folderId", folderId);
		List<String> emailList = queryService.executeNamedQuery("getNotificationEmailList", params);
		if (emailList != null && emailList.size() != 0) {
			StringBuffer emails = new StringBuffer();
			Iterator i$ = emailList.iterator();

			String subject;
			while (i$.hasNext()) {
				subject = (String) i$.next();
				if (subject != null && subject.length() > 0) {
					emails.append(subject).append(",");
				}
			}

			if (emails.length() > 0) {
				Folder folder = (Folder) domainService.getDomainObject(Folder.class, folderId);
				subject = "Document Library Notification for folder: " + folder.getFullPath();
				String message = "*****************************************\n* Document Library Notification         *\n* Folder: "
						+ folder.getFullPath() + " *\n" + "*****************************************\n\n" + msg;
				String to = emails.toString();
				String from = SystemProperties.getProperty("error_email_source_address");
				AppUtils.notify(message, to, from, subject, (String) null, (String) null, false);
			}

		}
	}

	public static boolean isParentFolder(QueryService queryService, Long parentFolderId, Long childFolderId) {
		Map params = new HashMap();
		params.put("parentFolderId", parentFolderId);
		params.put("childFolderId", childFolderId);
		List list = queryService.executeNamedQuery("checkParentFolder", params);
		if (list != null && list.size() > 0) {
			return !((String) list.get(0)).equals("0");
		} else {
			return false;
		}
	}
}