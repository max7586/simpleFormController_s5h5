package com.att.doclib2.web;

import com.att.doclib2.domain.ContentCommand;
import com.att.doclib2.domain.File;
import com.att.fusion.dao.support.BatchStep;
import com.att.fusion.service.QueryService;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.FusionFormController;
import com.att.fusion.web.support.UserUtils;
import java.util.Date;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

public class AddFilesController extends FusionFormController {
	public static final String DL_FILE_NAME_PREFIX = "DL_";
	public static final String UNKNOWN_FILE_EXTENSION = "unk";

	public Object formBackingObject(HttpServletRequest request) throws Exception {
		this.logger.info("AddFilesController - formBackingObject");
		ContentCommand contentCommand = new ContentCommand();
		contentCommand.initFiles();
		return contentCommand;
	}

	public ModelAndView save(HttpServletRequest request, HttpServletResponse response, Object command,
			ModelAndView modelView, BindException errors) throws Exception {
		this.logger.info("AddFilesController - save");
		Long folderId = ServletRequestUtils.getLongParameter(request, "folderId");
		Long userId = UserUtils.getUserIdAsLong(request);
		ContentCommand contentCommand = (ContentCommand) command;
		LinkedHashSet batch = new LinkedHashSet();
		String fileNames = "";
		int notifyFileCount = 0;
		Iterator i$ = contentCommand.getFiles().iterator();

		while (i$.hasNext()) {
			File file = (File) i$.next();
			if (file.getFile() != null && file.getFile().getOriginalFilename() != null
					&& file.getFile().getOriginalFilename().length() != 0) {
				file.setId(getNewFileId(this.getQueryService()));
				file.setFolderId(folderId);
				file.setName(file.getFile().getOriginalFilename());
				file.setFileName("DL_" + file.getId() + "." + getFileExt(file.getName()));
				file.setCreated(new Date());
				file.setCreatedId(userId);
				file.setModified(new Date());
				file.setModifiedId(userId);
				if (this.saveUploadedFile(file.getFile(), file.getFileName())) {
					BatchStep batchStep = new BatchStep();
					batchStep.setVo(file);
					batchStep.setType(30);
					batch.add(batchStep);
					if (file.getSendEmail()) {
						fileNames = fileNames + "," + file.getName();
						++notifyFileCount;
					}
				}
			}
		}

		if (batch.size() > 0) {
			this.getDomainService().executeBatchUpdate(batch);
			DoclibController.updateFolderModifyInfo(this.getDomainService(), folderId, userId);
		}

		if (notifyFileCount > 0) {
			String msg = "Following file" + (notifyFileCount > 1 ? "s" : "") + ": ";
			msg = msg + fileNames.substring(1) + " " + (notifyFileCount > 1 ? "have" : "has")
					+ " been added to this folder.";
			this.logger.debug("msg: " + msg);
			DoclibController.sendEmailNotification(this.getQueryService(), this.getDomainService(), folderId, msg);
		}

		return new ModelAndView("redirect:doclib.htm?action=displayFolder&folderId=" + folderId);
	}

	public static Long getNewFileId(QueryService queryService) {
		List<Long> list = queryService.executeNamedQuery("getNewFileId");
		return (Long) list.get(0);
	}

	public static String getFileExt(String fileName) {
		String ext = fileName.lastIndexOf(".") > 0 && fileName.lastIndexOf(".") < fileName.length() - 1
				? fileName.substring(fileName.lastIndexOf(".") + 1)
				: "unk";
		return ext;
	}

	private boolean saveUploadedFile(MultipartFile file, String fileName) {
		this.logger.debug("Saved File Name: " + file.getOriginalFilename() + " - " + fileName);
		String filePath = SystemProperties.getProperty("files_path");
		java.io.File newFile = new java.io.File(filePath + fileName);

		try {
			file.transferTo(newFile);
			return true;
		} catch (Exception var6) {
			this.logger.error("Upload file errror: " + var6.getMessage());
			this.logger
					.error("File: " + file.getOriginalFilename() + " filePath: " + filePath + " fileName:" + fileName);
			return false;
		}
	}
}