package com.att.doclib2.web;

import com.att.doclib2.domain.Url;
import com.att.fusion.web.support.FusionFormController;
import com.att.fusion.web.support.UserUtils;
import java.util.Date;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class EditUrlController extends FusionFormController {
	public Object formBackingObject(HttpServletRequest request) throws Exception {
		this.logger.info("EditUrlController - formBackingObject");
		Long urlId = ServletRequestUtils.getLongParameter(request, "urlId");
		return this.getDomainService().getDomainObject(Url.class, urlId);
	}

	public ModelAndView save(HttpServletRequest request, HttpServletResponse response, Object command,
			ModelAndView modelView, BindException errors) throws Exception {
		this.logger.info("EditUrlController - save");
		Long userId = UserUtils.getUserIdAsLong(request);
		Url url = (Url) command;
		url.setModified(new Date());
		url.setModifiedId(userId);
		this.getDomainService().saveDomainObject(url);
		return new ModelAndView("redirect:doclib.htm?action=displayFolder&folderId=" + url.getFolderId());
	}
}