package com.att.doclib2.domain;

import com.att.fusion.domain.support.DomainVo;
import org.springframework.web.multipart.MultipartFile;

public class File extends DomainVo {
	private String name;
	private String descr;
	private String fileName;
	private Long folderId;
	private String keywords;
	private String createdName;
	private String modifiedName;
	private MultipartFile file;
	private boolean sendEmail = false;

	public Long getFolderId() {
		return this.folderId;
	}

	public void setFolderId(Long folderId) {
		this.folderId = folderId;
	}

	public String getDescr() {
		return this.descr;
	}

	public String getFileName() {
		return this.fileName;
	}

	public String getKeywords() {
		return this.keywords;
	}

	public String getModifiedName() {
		return this.modifiedName;
	}

	public String getName() {
		return this.name;
	}

	public String getCreatedName() {
		return this.createdName;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public void setKeywords(String keywords) {
		this.keywords = keywords;
	}

	public void setModifiedName(String modifiedName) {
		this.modifiedName = modifiedName;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setCreatedName(String createdName) {
		this.createdName = createdName;
	}

	public boolean getSendEmail() {
		return this.sendEmail;
	}

	public void setSendEmail(boolean sendEmail) {
		this.sendEmail = sendEmail;
	}

	public MultipartFile getFile() {
		return this.file;
	}

	public void setFile(MultipartFile file) {
		this.file = file;
	}
}