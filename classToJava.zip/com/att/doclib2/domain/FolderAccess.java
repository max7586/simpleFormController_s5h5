package com.att.doclib2.domain;

import com.att.fusion.domain.support.DomainVo;

public class FolderAccess extends DomainVo {
	private Folder folder;
	private Long roleId;
	private Long userId;
	private Boolean readOnly;

	public FolderAccess() {
	}

	public FolderAccess(Folder folder, Long roleId, Long userId, Boolean readOnly) {
		this.folder = folder;
		this.roleId = roleId;
		this.userId = userId;
		this.readOnly = readOnly;
	}

	public Folder getFolder() {
		return this.folder;
	}

	public void setFolder(Folder folder) {
		this.folder = folder;
	}

	public Boolean getReadOnly() {
		return this.readOnly;
	}

	public void setReadOnly(Boolean readOnly) {
		this.readOnly = readOnly;
	}

	public Long getRoleId() {
		return this.roleId;
	}

	public void setRoleId(Long roleId) {
		this.roleId = roleId;
	}

	public Long getUserId() {
		return this.userId;
	}

	public void setUserId(Long userId) {
		this.userId = userId;
	}
}