package com.att.doclib2.domain;

import com.att.fusion.domain.support.DomainVo;

public class Url extends DomainVo {
	private String url;
	private String name;
	private Long folderId;
	private String modifiedName;
	private String createdName;

	public Long getFolderId() {
		return this.folderId;
	}

	public void setFolderId(Long folderId) {
		this.folderId = folderId;
	}

	public String getName() {
		return this.name;
	}

	public String getUrl() {
		return this.url;
	}

	public String getModifiedName() {
		return this.modifiedName;
	}

	public String getCreatedName() {
		return this.createdName;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public void setModifiedName(String modifiedName) {
		this.modifiedName = modifiedName;
	}

	public void setCreatedName(String createdName) {
		this.createdName = createdName;
	}
}