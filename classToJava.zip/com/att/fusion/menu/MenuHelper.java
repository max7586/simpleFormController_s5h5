package com.att.fusion.menu;

import java.util.Iterator;

public class MenuHelper {
	private int numMenuChars;
	private String topLevelMenuBar;
	private int i;

	public MenuHelper() {
		this.numMenuChars = 0;
		this.topLevelMenuBar = null;
		this.i = 1;
	}

	public MenuHelper(int childMenuOffset) {
		this();
		this.i = childMenuOffset;
	}

	public String writeTopMenu(MenuConfigData menuData) {
		StringBuffer childMenuSb = new StringBuffer();
		StringBuffer topMenuSb = new StringBuffer();
		Iterator iterator = menuData.getMenuItems().iterator();

		while (iterator.hasNext()) {
			MenuItem menuItem = (MenuItem) iterator.next();
			if (menuItem.isEnabled()) {
				menuItem.printTopItems(topMenuSb, childMenuSb, String.valueOf(this.i++), menuData.getMenuId());
				this.numMenuChars = this.numMenuChars + 1 + menuItem.label.length() + 1;
			}
		}

		this.topLevelMenuBar = topMenuSb.toString();
		return childMenuSb.toString();
	}

	public int getNumMenuChars() {
		return this.numMenuChars;
	}

	public String getTopLevelMenuBar() {
		return this.topLevelMenuBar;
	}

	public static String getMenuBuilder(String menuId) {
		StringBuffer menuSb = new StringBuffer();
		menuSb.append("[").append(MenuProperties.getProperty("width", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("left_position", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("top_position", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("font_color", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("mouseover_font_color", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("background_color", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("mouseover_background_color", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("border_color", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("separator_color", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("top_is_permanent", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("top_is_horizontal", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("tree_is_horizontal", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("position_under", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("top_more_images_visible", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("tree_more_images_visible", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("evaluate_upon_tree_show", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("evaluate_upon_tree_hide", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("right_to_left", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("display_on_click", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("top_is_variable_width", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("tree_is_variable_width", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("top_keep_in_window_x", menuId)).append(",").append("\n")
				.append(MenuProperties.getProperty("top_keep_in_window_y", menuId)).append("]");
		return menuSb.toString();
	}
}