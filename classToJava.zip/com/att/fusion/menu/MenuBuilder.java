package com.att.fusion.menu;

import com.att.fusion.domain.Menu;
import com.att.fusion.service.QueryService;
import com.att.fusion.util.SystemProperties;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import javax.servlet.ServletContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class MenuBuilder {
	protected final Log logger = LogFactory.getLog(this.getClass());
	private HashMap siteMenuItemsExcluded = new HashMap();
	private QueryService queryService;
	private ServletContext servletContext;

	public MenuConfigData buildMenu(String menuSetName, String siteAccess, Set roleFunctions, String propertiesFilename)
			throws Exception {
		MenuProperties.loadFromFile(this.getServletContext(), propertiesFilename, menuSetName);
		MenuConfigData menuData = new MenuConfigData(menuSetName);
		this.populateMenu(menuData, menuSetName, siteAccess, roleFunctions);
		return menuData;
	}

	private void populateMenu(MenuConfigData menuData, String menuSetName, String siteAccess, Set roleFunctions)
			throws Exception {
		HashMap params = new HashMap();
		params.put("menu_set_cd", menuSetName);
		List menuItems = this.getQueryService().executeNamedQuery(SystemProperties.getProperty("menu_query_name"),
				params, (HashMap) null);
		Iterator i = menuItems.iterator();

		while (true) {
			while (true) {
				String level;
				String menuId;
				String label;
				String parentId;
				String action;
				String funcId;
				String sortOrder;
				String servlet;
				String queryString;
				String externalUrl;
				String target;
				do {
					if (!i.hasNext()) {
						return;
					}

					Menu menu = (Menu) i.next();
					level = menu.getMenuLevel();
					menuId = String.valueOf(menu.getId());
					label = menu.getLabel();
					parentId = String.valueOf(menu.getParentId());
					action = menu.getAction();
					funcId = menu.getFunctionCd();
					sortOrder = menu.getSortOrder();
					servlet = menu.getServlet();
					queryString = menu.getQueryString();
					externalUrl = menu.getExternalUrl();
					target = menu.getTarget();
					this.logger.debug("Adding '" + label + "' menu item...");
					if (target == null) {
						if (MenuProperties.getProperty("main_frame") == null
								&& MenuProperties.getProperty("main_frame").equals("")) {
							target = "_self";
						} else {
							target = MenuProperties.getProperty("main_frame");
						}
					}
				} while ((!isAccessible(roleFunctions, funcId) || this.isExcludedMenuItem(siteAccess, menuId))
						&& !menuId.equals(MenuProperties.getProperty("menu_id_logout")));

				if (level.equals("1")) {
					menuData.addTopLevelMenu(menuId, label,
							this.constructUrl(externalUrl, action, servlet, queryString, target, true), true);
				} else if (!parentId.equals(MenuProperties.getProperty("menu_id_admin"))
						|| parentId.equals(MenuProperties.getProperty("menu_id_admin"))
								&& this.isAdminMenuItemDisplayed(sortOrder)) {
					MenuItem menuItem = menuData.findMenuItem(parentId);
					if (menuItem != null) {
						menuItem.addChild(menuData, menuId, label,
								this.constructUrl(externalUrl, action, servlet, queryString, target, false), true);
					}
				}
			}
		}
	}

	private boolean isExcludedMenuItem(String currentSite, String menuId) {
		boolean exclude = false;
		int[] menuItemsExcluded = (int[]) ((int[]) this.siteMenuItemsExcluded.get(currentSite));
		if (menuItemsExcluded != null) {
			for (int i = 0; i < menuItemsExcluded.length; ++i) {
				if (menuItemsExcluded[i] == Integer.parseInt(menuId)) {
					exclude = true;
				}
			}
		}

		return exclude;
	}

	private boolean isAdminMenuItemDisplayed(String sortOrder) {
		boolean displayed = false;
		return Integer.parseInt(sortOrder) <= Integer
				.parseInt(MenuProperties.getProperty("max_displayable_admin_menu_sort_order")) ? true : displayed;
	}

	private String constructUrl(String externalUrl, String action, String servlet, String queryString, String target,
			boolean isTopLevel) {
		String url = null;
		if (!isNull(externalUrl)) {
			url = externalUrl + (isNull(queryString) ? "" : "?" + queryString);
			url = "javascript:navigateUrl(\"" + url + "\", " + (isTopLevel ? "\"{0}\"" : "this") + ", \"" + target
					+ "\");";
		} else if (isNull(action) && isNull(servlet)) {
			url = "";
		} else if (isNull(action) && !isNull(servlet)) {
			url = "javascript:navigateUrl(\"" + servlet + "?" + queryString + "\", " + (isTopLevel ? "\"{0}\"" : "this")
					+ ", \"" + target + "\");";
		} else if (!isNull(action)) {
			url = "javascript:navigateUrl(\"" + action + (isNull(queryString) ? "" : "&" + queryString) + "\", "
					+ (isTopLevel ? "\"{0}\"" : "this") + ", \"" + target + "\");";
		}

		return url;
	}

	public static boolean isAccessible(Set roleFunctions, String sFuncId) {
		return roleFunctions == null ? false : roleFunctions.contains(sFuncId);
	}

	public static boolean stringToBoolean(String s) {
		return !isNull(s) && (s.equals("Y") || s.equals("1"));
	}

	public static boolean isNull(String a) {
		return a == null || a.length() == 0 || a.equalsIgnoreCase("null");
	}

	public static String globalReplace(String source, String search, String replace) {
		boolean stop = false;
		String retStr = source.substring(0);
		int start = retStr.indexOf(search);
		int searchForLength = search.length();

		for (int replaceWithLength = replace.length(); start >= 0; start = retStr.indexOf(search,
				start + replaceWithLength)) {
			retStr = retStr.substring(0, start) + replace + retStr.substring(start + searchForLength);
		}

		return retStr;
	}

	public void setSiteMenuItemsExcluded(HashMap siteMenuItemsExcluded) {
		this.siteMenuItemsExcluded = siteMenuItemsExcluded;
	}

	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public void setQueryService(QueryService queryService) {
		this.queryService = queryService;
	}

	public ServletContext getServletContext() {
		return this.servletContext;
	}

	public QueryService getQueryService() {
		return this.queryService;
	}
}