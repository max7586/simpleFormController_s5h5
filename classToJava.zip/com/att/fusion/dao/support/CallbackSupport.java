package com.att.fusion.dao.support;

import com.att.fusion.web.support.MessagesList;
import org.hibernate.Session;

public interface CallbackSupport {
	void transactionBody(Session var1, Object var2, MessagesList var3) throws Throwable;
}