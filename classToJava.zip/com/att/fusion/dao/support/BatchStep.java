package com.att.fusion.dao.support;

import com.att.fusion.domain.support.DomainVo;
import java.util.HashMap;
import java.util.Map;

public class BatchStep {
	private int type;
	private DomainVo vo;
	private Class domainClass;
	private String queryName;
	private String sql;
	private Map params;
	private Object results;
	private int rowsAffected;
	private Throwable throwable;
	private Class callbackClass;
	private Object callbackBean;
	public static final int TYPE_UPDATE = 10;
	public static final int TYPE_DELETE = 20;
	public static final int TYPE_DELETE_MULTIPLE = 25;
	public static final int TYPE_INSERT = 30;
	public static final int TYPE_QUERY = 100;
	public static final int TYPE_NAMED_UPDATE_QUERY = 110;
	public static final int TYPE_UPDATE_QUERY = 120;
	public static final int TYPE_NAMED_QUERY = 130;
	public static final int TYPE_CALLBACK = 140;
	public static final int TYPE_FLUSH = 150;

	public BatchStep() {
	}

	public BatchStep(int type) {
		this(type, (DomainVo) null, (Class) null, (String) null, (String) null, (HashMap) null, (Class) null,
				(Object) null);
	}

	public BatchStep(int type, DomainVo vo) {
		this(type, vo, (Class) null, (String) null, (String) null, (HashMap) null, (Class) null, (Object) null);
	}

	public BatchStep(int type, Class domainClass, String sql) {
		this(type, (DomainVo) null, domainClass, sql, (String) null, (HashMap) null, (Class) null, (Object) null);
	}

	public BatchStep(int type, Class domainClass, String queryName, HashMap params) {
		this(type, (DomainVo) null, domainClass, (String) null, queryName, params, (Class) null, (Object) null);
	}

	public BatchStep(int type, Class callbackClass, Object callbackBean) {
		this(type, (DomainVo) null, (Class) null, (String) null, (String) null, (HashMap) null, callbackClass,
				callbackBean);
	}

	private BatchStep(int type, DomainVo vo, Class domainClass, String sql, String queryName, HashMap params,
			Class callbackClass, Object callbackBean) {
		this();
		this.setType(type);
		this.setVo(vo);
		this.setDomainClass(domainClass);
		this.setSql(sql);
		this.setQueryName(queryName);
		this.setParams(params);
		this.setCallbackClass(callbackClass);
		this.setCallbackBean(callbackBean);
	}

	public int getType() {
		return this.type;
	}

	public Map getParams() {
		return this.params;
	}

	public String getQueryName() {
		return this.queryName;
	}

	public Object getResults() {
		return this.results;
	}

	public String getSql() {
		return this.sql;
	}

	public DomainVo getVo() {
		return this.vo;
	}

	public Throwable getThrowable() {
		return this.throwable;
	}

	public int getRowsAffected() {
		return this.rowsAffected;
	}

	public Class getDomainClass() {
		return this.domainClass;
	}

	public Object getCallbackBean() {
		return this.callbackBean;
	}

	public Class getCallbackClass() {
		return this.callbackClass;
	}

	public void setType(int type) {
		this.type = type;
	}

	public void setParams(Map params) {
		this.params = params;
	}

	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	public void setResults(Object results) {
		this.results = results;
	}

	public void setSql(String sql) {
		this.sql = sql;
	}

	public void setVo(DomainVo vo) {
		this.vo = vo;
	}

	public void setThrowable(Throwable throwable) {
		this.throwable = throwable;
	}

	public void setRowsAffected(int rowsAffected) {
		this.rowsAffected = rowsAffected;
	}

	public void setDomainClass(Class domainClass) {
		this.domainClass = domainClass;
	}

	public void setCallbackBean(Object callbackBean) {
		this.callbackBean = callbackBean;
	}

	public void setCallbackClass(Class callbackClass) {
		this.callbackClass = callbackClass;
	}
}