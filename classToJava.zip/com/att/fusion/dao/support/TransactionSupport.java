package com.att.fusion.dao.support;

import com.att.fusion.dao.hibernate.ModelOperationsCommon;

public abstract class TransactionSupport extends ModelOperationsCommon implements CallbackSupport {
}