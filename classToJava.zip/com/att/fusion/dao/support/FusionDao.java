package com.att.fusion.dao.support;

import com.att.fusion.FusionObject;
import org.hibernate.SessionFactory;

public class FusionDao implements FusionObject {
	private SessionFactory sessionFactory;

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public SessionFactory getSessionFactory() {
		return this.sessionFactory;
	}
}