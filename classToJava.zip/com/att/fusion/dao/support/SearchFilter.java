package com.att.fusion.dao.support;

public class SearchFilter {
	public static final int MATCH_MODE_ANYWHERE = 10;
	public static final int MATCH_MODE_END = 20;
	public static final int MATCH_MODE_EXACT = 30;
	public static final int MATCH_MODE_START = 40;
	public static final int OPERATOR_ID_EQUALITY = 110;
	public static final int OPERATOR_EQUALITY = 120;
	public static final int OPERATOR_LIKE = 140;
	public static final int TYPE_STRING = 210;
	public static final int TYPE_DATE = 220;
	public static final int TYPE_NUMERIC_PRIMITIVE = 230;
	public static final int TYPE_NUMERIC_CLASS = 240;
	public static final int TYPE_BOOLEAN = 250;
	private String field;
	private int operator;
	private Object value;
	private int matchMode;
	private int type;

	public SearchFilter() {
	}

	public SearchFilter(String field, int operator, Object value) {
		this(field, operator, value, 0);
	}

	public SearchFilter(String field, int operator, Object value, int matchMode) {
		this(field, operator, value, matchMode, 210);
	}

	public SearchFilter(String field, int operator, Object value, int matchMode, int type) {
		this();
		this.field = field;
		this.operator = operator;
		this.value = value;
		this.matchMode = matchMode;
		this.type = type;
	}

	public String getField() {
		return this.field;
	}

	public int getMatchMode() {
		return this.matchMode;
	}

	public int getOperator() {
		return this.operator;
	}

	public Object getValue() {
		return this.value;
	}

	public int getType() {
		return this.type;
	}

	public void setField(String field) {
		this.field = field;
	}

	public void setMatchMode(int matchMode) {
		this.matchMode = matchMode;
	}

	public void setOperator(int operator) {
		this.operator = operator;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public void setType(int type) {
		this.type = type;
	}
}