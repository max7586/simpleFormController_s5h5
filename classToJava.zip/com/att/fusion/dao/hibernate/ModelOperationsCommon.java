package com.att.fusion.dao.hibernate;

import com.att.fusion.dao.support.FusionDao;
import com.att.fusion.dao.support.QueryFilter;
import com.att.fusion.dao.support.TransactionSupport;
import com.att.fusion.domain.support.DomainVo;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.MessagesList;
import java.io.Serializable;
import java.sql.Connection;
import java.sql.Statement;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.springframework.orm.hibernate3.SessionFactoryUtils;

public abstract class ModelOperationsCommon extends FusionDao {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public List _getList(Class domainClass, List filter, Integer fromIndex, Integer toIndex, String orderBy) {
		StringBuffer filterClause = new StringBuffer("");
		if (filter != null) {
			Iterator i = filter.iterator();

			while (i.hasNext()) {
				if (filterClause.toString().equals("")) {
					filterClause.append(" where 1=1 ");
				}

				QueryFilter filterRow = (QueryFilter) i.next();
				filterClause.append(filterRow.getFilterClause());
			}
		}

		return this._getList(domainClass, filterClause.toString(), fromIndex, toIndex, orderBy);
	}

	public List _getList(Class domainClass, String filterClause, Integer fromIndex, Integer toIndex, String orderBy) {
		List list = null;
		String className = domainClass.getName();
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		this.logger.info("Getting " + className.toLowerCase() + " records"
				+ (fromIndex != null ? " from rows " + fromIndex.toString() + " to " + toIndex.toString() : "")
				+ "...");
		if (filterClause != null && filterClause.length() > 0) {
			this.logger.info("Filtering " + className + " by: " + filterClause);
		}

		list = session.createQuery("from " + className + filterClause + (orderBy != null ? " order by " + orderBy : ""))
				.list();
		list = fromIndex != null ? list.subList(fromIndex - 1, toIndex) : list;
		if (orderBy == null && list != null) {
			Collections.sort(list);
		}

		return list;
	}

	public DomainVo _get(Class domainClass, Serializable id) {
		DomainVo vo = null;
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		this.logger.info("Getting " + domainClass.getName() + " record for id - " + id.toString());
		vo = (DomainVo) session.get(domainClass, id);
		if (vo == null) {
			try {
				vo = (DomainVo) domainClass.newInstance();
			} catch (Exception var6) {
				this.logger.error("An error occured while instantiating a class of " + domainClass.getName());
			}
		}

		return vo;
	}

	protected final void _executeCallback(Class callbackClass, Object bean) throws Throwable {
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		TransactionSupport callback = (TransactionSupport) callbackClass.newInstance();
		callback.transactionBody(session, bean, (MessagesList) null);
	}

	protected final List _executeQuery(String sql, Class domainClass) {
		return this._executeQuery(sql, domainClass, (Integer) null, (Integer) null);
	}

	protected final List _executeQuery(String sql, Class domainClass, Integer fromIndex, Integer toIndex) {
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		SQLQuery query = session.createSQLQuery(sql).addEntity(domainClass.getName().toLowerCase(), domainClass);
		if (fromIndex != null && toIndex != null) {
			query.setFirstResult(fromIndex);
			int pageSize = toIndex - fromIndex + 1;
			query.setMaxResults(pageSize);
		}

		return query.list();
	}

	protected final List _executeQuery(String sql) {
		return this._executeQuery(sql, (Integer) null, (Integer) null);
	}

	protected final List _executeQuery(String sql, Integer fromIndex, Integer toIndex) {
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		Query query = session.createQuery(sql);
		if (fromIndex != null && toIndex != null) {
			query.setFirstResult(fromIndex);
			int pageSize = toIndex - fromIndex + 1;
			query.setMaxResults(pageSize);
		}

		return query.list();
	}

	protected final List _executeNamedQuery(String queryName, Map params) {
		return this._executeNamedQuery(queryName, params, (Integer) null, (Integer) null);
	}

	protected final List _executeNamedQuery(String queryName, Map params, Integer fromIndex, Integer toIndex) {
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		Query query = session.getNamedQuery(queryName);
		if (params != null) {
			Iterator i = params.entrySet().iterator();

			label33 : while (true) {
				while (true) {
					if (!i.hasNext()) {
						break label33;
					}

					Entry entry = (Entry) i.next();
					Object parameterValue = entry.getValue();
					if (!(parameterValue instanceof Collection) && !(parameterValue instanceof Object[])) {
						query.setParameter((String) entry.getKey(), parameterValue);
					} else if (parameterValue instanceof Collection) {
						query.setParameterList((String) entry.getKey(), (Collection) parameterValue);
					} else if (parameterValue instanceof Object[]) {
						query.setParameterList((String) entry.getKey(), (Object[]) ((Object[]) parameterValue));
					}
				}
			}
		}

		if (fromIndex != null && toIndex != null) {
			query.setFirstResult(fromIndex);
			int pageSize = toIndex - fromIndex + 1;
			query.setMaxResults(pageSize);
		}

		return query.list();
	}

	protected final int _executeUpdateQuery(String sql) throws Exception {
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		Connection con = session.connection();
		Statement st = con.createStatement();
		return st.executeUpdate(sql);
	}

	protected final int _executeNamedUpdateQuery(String queryName, Map params) throws Exception {
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		Query query = session.getNamedQuery(queryName);
		String queryString = query.toString();
		String sql = queryString.substring(queryString.indexOf("(") + 1, queryString.lastIndexOf(")"));
		System.out.println(queryName + " named query sql - " + sql);
		Entry entry;
		if (params != null) {
			for (Iterator i = params.entrySet().iterator(); i
					.hasNext(); sql = sql.replaceAll(":" + (String) entry.getKey(), String.valueOf(entry.getValue()))) {
				entry = (Entry) i.next();
			}
		}

		Connection con = session.connection();
		Statement st = con.createStatement();
		return st.executeUpdate(sql.trim());
	}

	protected final void _update(DomainVo vo, Integer userId) {
		this._update(vo, userId != null ? userId : 0);
	}

	protected final void _update(DomainVo vo, int userId) {
		Date timestamp = new Date();
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		if (vo.getId() != null && vo.getId().intValue() != 0) {
			vo.setModified(timestamp);
			if (userId != 0 && userId != Integer.parseInt(SystemProperties.getProperty("application_user_id"))) {
				vo.setModifiedId(new Long((long) userId));
			}
		} else {
			vo.setCreated(timestamp);
			vo.setModified(timestamp);
			if (userId != 0 && userId != Integer.parseInt(SystemProperties.getProperty("application_user_id"))) {
				vo.setCreatedId(new Long((long) userId));
				vo.setModifiedId(new Long((long) userId));
			}
		}

		session.saveOrUpdate(vo);
	}

	protected final void _remove(DomainVo vo) {
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		session.delete(vo);
	}

	protected final int _remove(Class domainClass, String whereClause) {
		int rowsAffected = false;
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		StringBuffer sql = new StringBuffer("delete from ");
		sql.append(domainClass.getName()).append(" where ").append(whereClause);
		int rowsAffected = session.createQuery(sql.toString()).executeUpdate();
		return rowsAffected;
	}

	protected final void _flush() {
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		session.flush();
	}
}