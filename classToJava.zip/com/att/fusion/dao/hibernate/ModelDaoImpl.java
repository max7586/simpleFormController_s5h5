package com.att.fusion.dao.hibernate;

import com.att.fusion.dao.ModelDao;
import com.att.fusion.dao.support.BatchStep;
import com.att.fusion.domain.support.DomainVo;
import com.att.fusion.web.support.UserUtils;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ModelDaoImpl extends ModelOperationsCommon implements ModelDao {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public List getList(Class domainClass, HashMap additionalParams) {
		return this.getList(domainClass, (List) ((List) null), (Integer) null, (Integer) null, (String) null,
				additionalParams);
	}

	public List getList(Class domainClass, int fromIndex, int toIndex, HashMap additionalParams) {
		return this.getList(domainClass, (List) ((List) null), new Integer(fromIndex), new Integer(toIndex),
				(String) null, additionalParams);
	}

	public List getList(Class domainClass, List filter, HashMap additionalParams) {
		return this.getList(domainClass, (List) filter, (Integer) null, (Integer) null, (String) null,
				additionalParams);
	}

	public List getList(Class domainClass, List filter, String orderBy, HashMap additionalParams) {
		return this.getList(domainClass, (List) filter, (Integer) null, (Integer) null, orderBy, additionalParams);
	}

	public List getList(Class domainClass, List filter, Integer fromIndex, Integer toIndex, String orderBy,
			HashMap additionalParams) {
		return this._getList(domainClass, filter, fromIndex, toIndex, orderBy);
	}

	public List getList(Class domainClass, String filter, Integer fromIndex, Integer toIndex, String orderBy,
			HashMap additionalParams) {
		return this._getList(domainClass, filter, fromIndex, toIndex, orderBy);
	}

	public DomainVo get(Class domainClass, Serializable id, HashMap additionalParams) {
		return this._get(domainClass, id);
	}

	public void update(DomainVo vo, HashMap additionalParams) {
		Integer userId = null;
		if (additionalParams != null) {
			userId = (Integer) additionalParams.get("userId");
			if (userId == null) {
				userId = new Integer(UserUtils.getUserId((HttpServletRequest) additionalParams.get("request")));
			}
		}

		this._update(vo, userId);
	}

	public void remove(DomainVo vo, HashMap additionalParams) {
		this._remove(vo);
	}

	public void remove(Class domainClass, String whereClause, HashMap additionalParams) {
		this._remove(domainClass, whereClause);
	}

	public List executeQuery(String sql, Class domainClass, Integer fromIndex, Integer toIndex,
			HashMap additionalParams) {
		return this._executeQuery(sql, domainClass, fromIndex, toIndex);
	}

	public List executeQuery(String sql, Integer fromIndex, Integer toIndex, HashMap additionalParams) {
		return this._executeQuery(sql, fromIndex, toIndex);
	}

	public List executeNamedQuery(String queryName, Map params, Integer fromIndex, Integer toIndex,
			HashMap additionalParams) {
		return this._executeNamedQuery(queryName, params, fromIndex, toIndex);
	}

	public int executeUpdateQuery(String sql, HashMap additionalParams) throws RuntimeException {
		boolean var3 = false;

		try {
			int recordsAffected = this._executeUpdateQuery(sql);
			return recordsAffected;
		} catch (Exception var5) {
			throw new RuntimeException(var5.getMessage());
		}
	}

	public int executeNamedUpdateQuery(String queryName, Map params, HashMap additionalParams) throws RuntimeException {
		boolean var4 = false;

		try {
			int recordsAffected = this._executeNamedUpdateQuery(queryName, params);
			return recordsAffected;
		} catch (Exception var6) {
			throw new RuntimeException(var6.getMessage());
		}
	}

	public void executeCallback(Class callbackClass, Object bean, HashMap additionalParams) throws RuntimeException {
		try {
			this._executeCallback(callbackClass, bean);
		} catch (Throwable var5) {
			throw new RuntimeException(var5.getMessage());
		}
	}

	public void removeBatchStep(Class domainClass, String whereClause, HashMap additionalParams) {
		this._remove(domainClass, whereClause);
	}

	public List executeQuery(String sql, Class domainClass, HashMap additionalParams) {
		return this._executeQuery(sql, domainClass);
	}

	public List executeNamedQuery(String queryName, Map params, HashMap additionalParams) {
		return this._executeNamedQuery(queryName, params);
	}

	public int executeUpdateQueryBatchStep(String sql, HashMap additionalParams) throws RuntimeException {
		boolean var3 = false;

		try {
			int recordsAffected = this._executeUpdateQuery(sql);
			return recordsAffected;
		} catch (Exception var5) {
			throw new RuntimeException(var5.getMessage());
		}
	}

	public int executeNamedUpdateQueryBatchStep(String queryName, Map params, HashMap additionalParams)
			throws RuntimeException {
		boolean var4 = false;

		try {
			int recordsAffected = this._executeNamedUpdateQuery(queryName, params);
			return recordsAffected;
		} catch (Exception var6) {
			throw new RuntimeException(var6.getMessage());
		}
	}

	public void executeBatchCallback(Class callbackClass, Object bean, HashMap additionalParams)
			throws RuntimeException {
		try {
			this._executeCallback(callbackClass, bean);
		} catch (Throwable var5) {
			throw new RuntimeException(var5.getMessage());
		}
	}

	public void flush(HashMap additionalParams) {
		this._flush();
	}

	public void executeBatch(LinkedHashSet batch, boolean atomic, HashMap additionalParams) throws RuntimeException {
		this.logger.info("Executing batch...");
		Iterator i = batch.iterator();

		for (int j = 1; i.hasNext(); ++j) {
			BatchStep step = (BatchStep) i.next();

			try {
				switch (step.getType()) {
					case 10 :
					case 30 :
						this.update(step.getVo(), additionalParams);
						break;
					case 20 :
						this.remove(step.getVo(), additionalParams);
						break;
					case 25 :
						this.remove(step.getDomainClass(), step.getSql(), additionalParams);
						break;
					case 100 :
						step.setResults(this.executeQuery(step.getSql(), step.getDomainClass(), additionalParams));
						break;
					case 110 :
						step.setRowsAffected(
								this.executeNamedUpdateQuery(step.getQueryName(), step.getParams(), additionalParams));
						break;
					case 120 :
						step.setRowsAffected(this.executeUpdateQuery(step.getSql(), additionalParams));
						break;
					case 130 :
						step.setResults(
								this.executeNamedQuery(step.getQueryName(), step.getParams(), additionalParams));
						break;
					case 140 :
						this.executeCallback(step.getCallbackClass(), step.getCallbackBean(), additionalParams);
						break;
					case 150 :
						this.flush(additionalParams);
						break;
					default :
						this.logger.error("Batch step type not supported - " + String.valueOf(step.getType()));
				}
			} catch (Throwable var8) {
				switch (step.getType()) {
					case 10 :
					case 20 :
					case 30 :
						this.logger.error("An error has occurred while running the batch at step " + String.valueOf(j)
								+ ": type - " + step.getType() + ", id - " + step.getVo().getId());
						break;
					case 25 :
					case 100 :
					case 120 :
						this.logger.error("An error has occurred while running the batch at step " + String.valueOf(j)
								+ ": type - " + step.getType() + ", sql - " + step.getSql());
						break;
					case 110 :
					case 130 :
						this.logger.error("An error has occurred while running the batch at step " + String.valueOf(j)
								+ ": type - " + step.getType() + ", queryName - " + step.getQueryName());
						break;
					case 140 :
						this.logger.error("An error has occurred while running the batch at step " + String.valueOf(j)
								+ ": type - " + step.getType() + ", callback class - "
								+ step.getCallbackClass().getClass().getName());
						break;
					case 150 :
						this.logger.error(
								"An error has occurred while attempting to flush the Hibernate session to the database.");
				}

				this.logger.error(var8.getMessage());
				step.setThrowable(var8);
				if (atomic) {
					throw new RuntimeException(var8.getMessage());
				}
			}
		}

		this.logger.info("Batch executed successfully.");
	}
}