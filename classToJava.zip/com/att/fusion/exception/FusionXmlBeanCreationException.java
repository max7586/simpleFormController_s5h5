package com.att.fusion.exception;

import com.att.fusion.exception.support.FusionException;

public class FusionXmlBeanCreationException extends Exception implements FusionException {
	public FusionXmlBeanCreationException() {
	}

	public FusionXmlBeanCreationException(String message) {
		super(message);
	}

	public FusionXmlBeanCreationException(String message, Throwable cause) {
		super(message, cause);
	}

	public FusionXmlBeanCreationException(Throwable cause) {
		super(cause);
	}
}