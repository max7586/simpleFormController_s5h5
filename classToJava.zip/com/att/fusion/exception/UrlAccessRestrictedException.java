package com.att.fusion.exception;

import com.att.fusion.exception.support.FusionRuntimeException;

public class UrlAccessRestrictedException extends FusionRuntimeException {
	public static final String MESSAGE = "Authorization Denied";

	public UrlAccessRestrictedException() {
		super("Authorization Denied");
	}
}