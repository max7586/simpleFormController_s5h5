package com.att.fusion.exception.support;

public class FusionRuntimeException extends RuntimeException implements FusionException {
	public FusionRuntimeException() {
		this("");
	}

	public FusionRuntimeException(String message) {
		super(message);
	}
}