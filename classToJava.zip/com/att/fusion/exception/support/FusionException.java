package com.att.fusion.exception.support;

import com.att.fusion.FusionObject;

public interface FusionException extends FusionObject {
}