package com.att.fusion;

public interface FusionObject {
}