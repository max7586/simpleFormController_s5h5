package com.att.fusion.interceptor;

import com.att.fusion.domain.support.DomainVo;
import com.att.fusion.interceptor.support.FusionHandlerInterceptor;
import com.att.fusion.web.support.AppUtils;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public abstract class AbstractProfileInterceptor extends FusionHandlerInterceptor {
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		return true;
	}

	public final void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView mav) throws Exception {
		String userId = request.getRequestedSessionId();
		String task = ServletRequestUtils.getStringParameter(request, "task");
		boolean hasError = AppUtils.hasError(userId) || AppUtils.hasWarning(userId);
		DomainVo profileBean = (DomainVo) mav.getModel().get("profileBean");
		DomainVo appProfile = null;
		if (profileBean != null) {
			appProfile = this.getCustomProfileInfo(profileBean.getId(), request);
			if (!hasError && appProfile != null && task != null && task.equals("save")) {
				this.saveCustomProfileInfo(request, appProfile);
			}
		}

		this.modifyModel(request, mav, appProfile);
	}

	public void afterCompletion(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex)
			throws Exception {
	}

	public abstract DomainVo getCustomProfileInfo(Long var1, HttpServletRequest var2) throws Exception;

	public abstract void saveCustomProfileInfo(HttpServletRequest var1, DomainVo var2) throws Exception;

	public abstract void modifyModel(HttpServletRequest var1, ModelAndView var2, DomainVo var3) throws Exception;
}