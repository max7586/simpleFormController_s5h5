package com.att.fusion.interceptor;

import com.att.fusion.interceptor.support.FusionHandlerInterceptor;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FeedbackMessage;
import com.att.fusion.web.support.FusionController;
import com.att.fusion.web.support.MessagesList;
import com.att.fusion.web.support.UserUtils;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;

public class MessagingInterceptor extends FusionHandlerInterceptor {
	private boolean isFeedbackEmpty(HttpServletRequest request) {
		String userSessionId = request.getRequestedSessionId();
		return !AppUtils.hasError(userSessionId) && !AppUtils.hasSuccess(userSessionId)
				&& !AppUtils.hasWarning(userSessionId);
	}

	private boolean isTransactionTask(String task) {
		return SystemProperties.getSuccessTasks() != null
				? SystemProperties.getSuccessTasks().containsKey(task)
				: false;
	}

	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		FusionController controller = (FusionController) handler;
		String task = request.getParameter("task");
		if (task != null && this.isTransactionTask(task)) {
			controller.setSuccessMessagingOn(request);
		}

		return super.preHandle(request, response, handler);
	}

	public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView modelAndView) throws Exception {
		super.postHandle(request, response, handler, modelAndView);
		FusionController controller = (FusionController) handler;
		MessagesList messages = controller.getCustomMessages();
		if (controller.displaySuccessMessaging(request) && this.isFeedbackEmpty(request)) {
			if (messages == null || messages.isSuccessMessageDisplayed() && !messages.hasSuccessMessages()) {
				AppUtils.addFeedback(
						request != null
								? request.getRequestedSessionId()
								: String.valueOf(UserUtils.getUserId(request)),
						new FeedbackMessage("Update successful.", 40));
			} else if (messages.isSuccessMessageDisplayed() && messages.hasSuccessMessages()) {
				for (int i = 0; i < messages.getSuccessMessages().size(); ++i) {
					AppUtils.addFeedback(
							request != null
									? request.getRequestedSessionId()
									: String.valueOf(UserUtils.getUserId(request)),
							(FeedbackMessage) messages.getSuccessMessages().get(i));
				}
			}
		}

	}
}