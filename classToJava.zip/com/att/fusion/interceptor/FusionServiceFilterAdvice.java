package com.att.fusion.interceptor;

import com.att.fusion.dao.support.Filter;
import com.att.fusion.dao.support.FilterParameter;
import com.att.fusion.interceptor.support.FusionInterceptor;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.aspectj.lang.ProceedingJoinPoint;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.core.Ordered;
import org.springframework.orm.hibernate3.SessionFactoryUtils;

public class FusionServiceFilterAdvice extends FusionInterceptor implements Ordered {
	private int order;
	private SessionFactory sessionFactory;

	public int getOrder() {
		return this.order;
	}

	public void setOrder(int order) {
		this.order = order;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public SessionFactory getSessionFactory() {
		return this.sessionFactory;
	}

	public Object setSessionFilters(ProceedingJoinPoint pjp, HashMap additionalParams) throws Throwable {
		Log logger = LogFactory.getLog(pjp.getClass());
		Object returnValue = null;
		String[] filters = null;
		boolean enableFilters = false;
		if (additionalParams != null) {
			enableFilters = additionalParams.containsKey("filters");
		}

		if (enableFilters) {
			filters = this.applyFilters((HashSet) additionalParams.get("filters"));
		}

		returnValue = pjp.proceed();
		if (enableFilters) {
			this.removeFilters(filters);
		}

		return returnValue;
	}

	private String[] applyFilters(HashSet filters) {
		String[] filterList = new String[filters.size()];
		int count = 0;
		if (filterList.length > 0) {
			Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
			Iterator i = filters.iterator();

			label35 : while (i.hasNext()) {
				Filter entry = (Filter) i.next();
				String filterName = entry.getName();
				filterList[count++] = filterName;
				org.hibernate.Filter sessionFilter = session.enableFilter(filterName);
				Set filterParameters = (HashSet) entry.getParameters();
				Iterator j = filterParameters.iterator();

				while (true) {
					while (true) {
						if (!j.hasNext()) {
							continue label35;
						}

						FilterParameter parameterEntry = (FilterParameter) j.next();
						String parameterName = parameterEntry.getName();
						Object parameterValue = parameterEntry.getValue();
						if (!(parameterValue instanceof Collection) && !(parameterValue instanceof Object[])) {
							sessionFilter.setParameter(parameterName, parameterValue);
						} else if (parameterValue instanceof Collection) {
							sessionFilter.setParameterList(parameterName, (Collection) parameterValue);
						} else if (parameterValue instanceof Object[]) {
							sessionFilter.setParameterList(parameterName, (Object[]) ((Object[]) parameterValue));
						}
					}
				}
			}
		}

		return filterList;
	}

	private void removeFilters(String[] filters) {
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);

		for (int k = 0; k < filters.length; ++k) {
			session.disableFilter(filters[k]);
		}

	}
}