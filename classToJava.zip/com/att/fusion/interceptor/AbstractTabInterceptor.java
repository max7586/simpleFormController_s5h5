package com.att.fusion.interceptor;

import com.att.fusion.FusionObject.Utilities;
import com.att.fusion.domain.Tab;
import com.att.fusion.interceptor.support.FusionHandlerInterceptor;
import com.att.fusion.service.QueryService;
import com.att.fusion.web.support.UserUtils;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;

public abstract class AbstractTabInterceptor extends FusionHandlerInterceptor {
	private QueryService queryService;
	protected String objectId;

	public final void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
			ModelAndView mav) throws Exception {
		Map params = new HashMap();
		String uri = request.getRequestURI();
		this.setCustomParameters(params, request);
		params.put("user_id", new Integer(UserUtils.getUserId(request)));
		params.put("object_id", this.getObjectId());
		params.put("uri", uri.substring(uri.lastIndexOf("/") + 1, uri.lastIndexOf(".htm")));
		List tabs = this.getQueryService().executeNamedQuery("viewableTabs", params);
		request.setAttribute("tabs", this.packageTabData(tabs));
	}

	private Set packageTabData(List tabs) {
		HashMap allTabs = new HashMap();
		int numLevels = 0;

		try {
			int j;
			TreeSet tabSet;
			for (j = 0; j < tabs.size(); ++j) {
				Tab tab = (Tab) tabs.get(j);
				tabSet = (TreeSet) allTabs.get(tab.getLevel());
				if (tabSet == null) {
					tabSet = new TreeSet();
				}

				tabSet.add(tab);
				allTabs.put(tab.getLevel(), tabSet);
				if (tab.getLevel() > numLevels) {
					numLevels = tab.getLevel();
				}
			}

			for (j = numLevels - 1; j > 0; --j) {
				Integer level = new Integer(j);
				tabSet = (TreeSet) allTabs.get(level);
				if (tabSet != null) {
					Iterator t = tabSet.iterator();

					while (t.hasNext()) {
						Tab tab = (Tab) t.next();
						if (tab.isSelected()) {
							tabSet.remove(tab);
							tab.setSubTabs((TreeSet) allTabs.get(new Integer(j + 1)));
							tabSet.add(tab);
							break;
						}
					}
				}

				allTabs.put(level, tabSet);
			}
		} catch (Exception var9) {
			var9.printStackTrace();
		}

		return (TreeSet) allTabs.get(new Integer("1"));
	}

	public abstract void setCustomParameters(Map var1, HttpServletRequest var2);

	public QueryService getQueryService() {
		return this.queryService;
	}

	public String getObjectId() {
		return Utilities.nvl(this.objectId, "0");
	}

	public void setQueryService(QueryService queryService) {
		this.queryService = queryService;
	}

	public void setObjectId(String objectId) {
		this.objectId = objectId;
	}
}