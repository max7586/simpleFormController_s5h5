package com.att.fusion.interceptor.support;

import com.att.fusion.FusionObject;

public class FusionInterceptor implements FusionObject {
}