package com.att.fusion.web.ajax;

import com.att.doclib2.domain.File;
import com.att.doclib2.domain.Folder;
import com.att.doclib2.domain.FolderAccess;
import com.att.doclib2.domain.Url;
import com.att.doclib2.web.AddFilesController;
import com.att.doclib2.web.DoclibController;
import com.att.fusion.dao.support.BatchStep;
import com.att.fusion.domain.Role;
import com.att.fusion.domain.User;
import com.att.fusion.menu.MenuBuilder;
import com.att.fusion.menu.MenuConfigData;
import com.att.fusion.service.DomainService;
import com.att.fusion.service.QueryService;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.UserUtils;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;
import javax.servlet.http.HttpServletRequest;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.directwebremoting.WebContext;
import org.directwebremoting.WebContextFactory;

public final class FusionAjax {
	protected final Log logger = LogFactory.getLog(this.getClass());
	private DomainService domainService;
	private QueryService queryService;
	private MenuBuilder menuBuilder;

	public DomainService getDomainService() {
		return this.domainService;
	}

	public QueryService getQueryService() {
		return this.queryService;
	}

	public MenuBuilder getMenuBuilder() {
		return this.menuBuilder;
	}

	public void setDomainService(DomainService domainService) {
		this.domainService = domainService;
	}

	public void setQueryService(QueryService queryService) {
		this.queryService = queryService;
	}

	public void setMenuBuilder(MenuBuilder menuBuilder) {
		this.menuBuilder = menuBuilder;
	}

	public Long toggleUserActive(Long actionUserId, Long userId) {
		this.logger.info("toggleUserActive - actionUserId: " + actionUserId + " userId: " + userId);
		User user = (User) this.getDomainService().getDomainObject(User.class, userId);
		user.setActive(!user.getActive());
		this.getDomainService().saveDomainObject(user);
		this.logger.info("completed toggleUserActive");
		return userId;
	}

	public void removeRoleFunction(Long roleId, String roleFunctionCd) {
		this.logger.info("removeRoleFunction - roleId: " + roleId + " roleFunctionCd: " + roleFunctionCd);
		Role role = (Role) this.getDomainService().getDomainObject(Role.class, roleId);
		role.removeRoleFunction(roleFunctionCd);
		this.getDomainService().saveDomainObject(role);
		this.logger.info("completed removeRoleFunction");
	}

	public void removeChildRole(Long roleId, Long childRoleId) {
		this.logger.info("removeChildRole - roleId: " + roleId + " childRoleId: " + childRoleId);
		Role role = (Role) this.getDomainService().getDomainObject(Role.class, roleId);
		role.removeChildRole(childRoleId);
		this.getDomainService().saveDomainObject(role);
		this.logger.info("completed removeChildRole");
	}

	public void switchProfile(Long pseudoRoleId) {
		Set switchedProfile = new TreeSet();
		WebContext ctx = WebContextFactory.get();
		HttpServletRequest request = ctx.getHttpServletRequest();
		HashMap allUserRoles = null;
		User user = UserUtils.getUserSession(request);
		String loginMethod = UserUtils.getLoginMethod(request);
		UserUtils.clearUserSession(request);
		if (pseudoRoleId.intValue() == 0) {
			this.logger.info("switchProfile - back to normal Profile for userId: " + user.getId());
			User currentUser = (User) this.getDomainService().getDomainObject(User.class, user.getId());
			user.setSelectedProfileId((Long) null);
			user.setRoles(currentUser.getRoles());
			allUserRoles = UserUtils.getAllUserRoles(user);
		} else {
			this.logger.info("switchProfile - switch to profile for userId: " + user.getId() + ", pseudoRoleId: "
					+ pseudoRoleId);
			Role role = (Role) this.getDomainService().getDomainObject(Role.class, pseudoRoleId);
			switchedProfile.add(role);
			user.setRoles(switchedProfile);
			user.setSelectedProfileId(pseudoRoleId);
			allUserRoles = UserUtils.getAllUserRoles(role);
		}

		try {
			MenuConfigData applicationMenu = this.getMenuBuilder().buildMenu(
					SystemProperties.getProperty("application_menu_set_name"), (String) null,
					UserUtils.getRoleFunctions(allUserRoles),
					SystemProperties.getProperty("application_menu_properties_name"));
			MenuConfigData businessDirectMenu = this.getMenuBuilder().buildMenu(
					SystemProperties.getProperty("business_direct_menu_set_name"), (String) null,
					UserUtils.getRoleFunctions(allUserRoles),
					SystemProperties.getProperty("business_direct_menu_properties_name"));
			UserUtils.setUserSession(request, user, applicationMenu, businessDirectMenu, loginMethod);
		} catch (Exception var10) {
			this.logger.error("Could not switch profile for userId: " + user.getId()
					+ " due to the following exception: " + var10.getMessage());
		}

	}

	public List getSubFolderList(long folderId) {
		this.logger.debug("getSubFolderList - folderId: " + folderId);
		WebContext ctx = WebContextFactory.get();
		HttpServletRequest request = ctx.getHttpServletRequest();
		return DoclibController.getSubFolderList(this.getQueryService(), request, folderId);
	}

	public boolean toggleDoclibNotification(Long folderId, Long userId) {
		this.logger.debug("toggleDoclibNotification - folderId: " + folderId + " userId:" + userId);
		boolean needNotification = DoclibController.needNotification(this.getQueryService(), folderId, userId);
		String sql = "";
		if (needNotification) {
			sql = "delete from dl_notify where folder_id = '" + folderId + "' and user_id = '" + userId + "'";
		} else {
			sql = "insert into dl_notify (folder_id, user_id) values ('" + folderId + "', '" + userId + "')";
		}

		this.logger.debug("sql: " + sql);
		this.getQueryService().executeUpdateQuery(sql);
		return !needNotification;
	}

	public boolean toggleDoclibAccessReadonly(Long id) {
		this.logger.debug("toggleDoclibAccessReadonly - id: " + id);
		FolderAccess access = (FolderAccess) this.getDomainService().getDomainObject(FolderAccess.class, id);
		boolean readOnly = access.getReadOnly();
		access.setReadOnly(!readOnly);
		this.getDomainService().saveDomainObject(access);
		return !readOnly;
	}

	public void deleteDoclibItem(Long folderId, Long id, String type) {
		this.logger.debug("deleteDoclibItem - id: " + id + " type:" + type);
		if (type.equalsIgnoreCase("Access")) {
			this.getDomainService().deleteDomainObjects(FolderAccess.class, " fa_id = " + id);
		} else {
			String msg = "";
			if (type.equalsIgnoreCase("File")) {
				File file = (File) this.getDomainService().getDomainObject(File.class, id);
				if (file.getId() != null) {
					msg = "File \"" + file.getName() + "\"";
					this.getDomainService().deleteDomainObject(file);
				}
			} else if (type.equalsIgnoreCase("Url")) {
				Url url = (Url) this.getDomainService().getDomainObject(Url.class, id);
				if (url.getId() != null) {
					msg = "URL \"" + url.getName() + "\"";
					this.getDomainService().deleteDomainObject(url);
				}
			}

			WebContext ctx = WebContextFactory.get();
			HttpServletRequest request = ctx.getHttpServletRequest();
			DoclibController.updateFolderModifyInfo(this.getDomainService(), folderId,
					UserUtils.getUserIdAsLong(request));
			if (msg.length() > 0) {
				msg = msg + " has been deleted from this folder.";
				this.logger.debug("msg: " + msg);
				DoclibController.sendEmailNotification(this.getQueryService(), this.getDomainService(), folderId, msg);
			}
		}

	}

	public Long addDoclibAccess(Long folderId, Long id, String type) {
		this.logger.debug("addDoclibAccess - folderId:" + folderId + " id: " + id + " type:" + type);
		FolderAccess access = new FolderAccess();
		Folder folder = new Folder();
		folder.setId(folderId);
		access.setFolder(folder);
		access.setReadOnly(true);
		if (type.equals("addUser")) {
			access.setUserId(id);
		} else {
			access.setRoleId(id);
		}

		this.getDomainService().saveDomainObject(access);
		return access.getId();
	}

	public Long deleteDoclibFolder(Long folderId, Long parentFolderId) {
		Folder folder = (Folder) this.getDomainService().getDomainObject(Folder.class, folderId);
		this.getDomainService().deleteDomainObject(folder);
		return parentFolderId;
	}

	public boolean pasteToDoclibFolder(Long folderId, boolean isCopy, String fileIdList, String urlIdList,
			Long srcFolderId) {
		this.logger.debug("pasteToDoclibFolder - folderId:" + folderId + " isCopy:" + isCopy + " fileIdList:"
				+ fileIdList + " urlIdList:" + urlIdList + " srcFolderId:" + srcFolderId);
		boolean done = false;
		if (folderId == null) {
			return done;
		} else {
			boolean isFolder = true;
			String fileMsg = "";
			String urlMsg = "";
			LinkedHashSet batch = new LinkedHashSet();
			String[] idList;
			String[] arr$;
			int len$;
			int i$;
			String id;
			BatchStep batchStep;
			if (fileIdList != null && fileIdList.length() > 0) {
				isFolder = false;
				idList = fileIdList.split(",");
				arr$ = idList;
				len$ = idList.length;

				for (i$ = 0; i$ < len$; ++i$) {
					id = arr$[i$];
					if (id.length() != 0) {
						File file = (File) this.getDomainService().getDomainObject(File.class, new Long(id));
						if (file != null && file.getId() != null) {
							fileMsg = fileMsg + "," + file.getName();
							batchStep = new BatchStep();
							if (isCopy) {
								file.setId(AddFilesController.getNewFileId(this.getQueryService()));
								file.setFolderId(folderId);
								batchStep.setVo(file);
								batchStep.setType(30);
							} else {
								file.setFolderId(folderId);
								batchStep.setVo(file);
								batchStep.setType(10);
							}

							batch.add(batchStep);
						}
					}
				}
			}

			if (urlIdList != null && urlIdList.length() > 0) {
				isFolder = false;
				idList = urlIdList.split(",");
				arr$ = idList;
				len$ = idList.length;

				for (i$ = 0; i$ < len$; ++i$) {
					id = arr$[i$];
					if (id.length() != 0) {
						Url url = (Url) this.getDomainService().getDomainObject(Url.class, new Long(id));
						if (url != null && url.getId() != null) {
							urlMsg = urlMsg + "," + url.getName();
							batchStep = new BatchStep();
							if (isCopy) {
								url.setId((Long) null);
								url.setFolderId(folderId);
								batchStep.setVo(url);
								batchStep.setType(30);
							} else {
								url.setFolderId(folderId);
								batchStep.setVo(url);
								batchStep.setType(10);
							}

							batch.add(batchStep);
						}
					}
				}
			}

			if (batch.size() > 0) {
				this.getDomainService().executeBatchUpdate(batch);
				String msg = "";
				if (fileMsg.length() > 0) {
					msg = "File: " + fileMsg.substring(1) + "\n";
				}

				if (urlMsg.length() > 0) {
					msg = msg + "URL: " + urlMsg.substring(1) + "\n";
				}

				if (msg.length() > 0) {
					this.logger.debug("msg: " + msg);
					if (isCopy) {
						DoclibController.sendEmailNotification(this.getQueryService(), this.getDomainService(),
								folderId, "Following file/URL have been copied to this folder:\n" + msg);
					} else {
						DoclibController.sendEmailNotification(this.getQueryService(), this.getDomainService(),
								srcFolderId, "Following file/URL have been moved out from this folder:\n" + msg);
						DoclibController.sendEmailNotification(this.getQueryService(), this.getDomainService(),
								folderId, "Following file/URL have been moved to this folder:\n" + msg);
					}
				}

				done = true;
			}

			if (isFolder && srcFolderId != null
					&& !DoclibController.isParentFolder(this.getQueryService(), srcFolderId, folderId)) {
				this.logger.debug("Not Parent Folder");
				Folder srcFolder = (Folder) this.getDomainService().getDomainObject(Folder.class, srcFolderId);
				if (folderId != srcFolder.getParentFolderId()) {
					srcFolder.setParentFolderId(folderId);
					this.getDomainService().saveDomainObject(srcFolder);
					done = true;
				}
			}

			return done;
		}
	}
}