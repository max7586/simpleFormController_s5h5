package com.att.fusion.web;

import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FeedbackMessage;
import com.att.fusion.web.support.FusionBaseController;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;

public class ApplicationLockoutController extends FusionBaseController {
	public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) {
		String messageKey = null;
		AppUtils.setApplicationLocked(!AppUtils.isApplicationLocked());
		if (AppUtils.isApplicationLocked()) {
			messageKey = "general.application.locked";
		} else {
			messageKey = "general.application.unlocked";
		}

		AppUtils.addFeedback(request.getRequestedSessionId(), new FeedbackMessage(messageKey, 40, true));
		return new ModelAndView("redirect:welcome.htm");
	}
}