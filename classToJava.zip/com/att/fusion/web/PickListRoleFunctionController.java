package com.att.fusion.web;

import com.att.fusion.command.PickListBean;
import com.att.fusion.domain.Role;
import com.att.fusion.domain.RoleFunction;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FeedbackMessage;
import com.att.fusion.web.support.FusionFormController;
import com.att.fusion.web.support.UserUtils;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class PickListRoleFunctionController extends FusionFormController {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public Object formBackingObject(HttpServletRequest request) {
		PickListBean pickListBean = new PickListBean();
		pickListBean.setParentId(ServletRequestUtils.getLongParameter(request, "role_id", 0L));
		pickListBean.setParentName(ServletRequestUtils.getStringParameter(request, "role_name",
				"Role Id - " + pickListBean.getParentId()));
		return pickListBean;
	}

	protected Map referenceData(HttpServletRequest request) throws Exception {
		Map lookupData = new HashMap();
		HashMap selectedRoleFunctions = new HashMap();
		int roleId = ServletRequestUtils.getIntParameter(request, "role_id", 0);
		Role role = (Role) this.getDomainService().getDomainObject(Role.class, new Long((long) roleId));
		if (role.getRoleFunctions() != null) {
			Iterator i = role.getRoleFunctions().iterator();

			while (i.hasNext()) {
				RoleFunction roleFunction = (RoleFunction) i.next();
				selectedRoleFunctions.put(roleFunction.getCode(), roleFunction.getCode());
			}
		}

		lookupData.put("selectedRoleFunctions", selectedRoleFunctions);
		lookupData.put("allRoleFunctions", this.getDomainService().getList(RoleFunction.class));
		return lookupData;
	}

	public ModelAndView save(HttpServletRequest request, HttpServletResponse response, Object command,
			ModelAndView modelView, BindException errors) throws Exception {
		PickListBean bean = (PickListBean) command;
		long roleId = bean.getParentId();
		String[] selected = bean.getSelected();
		int userId = UserUtils.getUserId(request);
		HashMap additionalParams = new HashMap();
		additionalParams.put("request", request);
		Role role = (Role) this.getDomainService().getDomainObject(Role.class, new Long(roleId));
		role.setRoleFunctions(new TreeSet());
		if (selected != null) {
			for (int i = 0; i < selected.length; ++i) {
				String roleFunctionCd = selected[i];
				RoleFunction roleFunction = new RoleFunction();
				roleFunction.setCode(roleFunctionCd);
				role.addRoleFunction(roleFunction);
			}

			this.getDomainService().saveDomainObject(role, additionalParams);
		} else {
			AppUtils.addFeedback(request.getRequestedSessionId(),
					new FeedbackMessage("At least one role function must be selected.", 10));
		}

		return this.showForm(request, response, errors);
	}
}