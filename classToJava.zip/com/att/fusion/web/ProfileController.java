package com.att.fusion.web;

import com.att.fusion.domain.Role;
import com.att.fusion.domain.User;
import com.att.fusion.domain.support.DomainVo;
import com.att.fusion.web.support.FusionFormController;
import com.att.fusion.web.support.UserUtils;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class ProfileController extends FusionFormController {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public Object formBackingObject(HttpServletRequest request) {
		int profileId = ServletRequestUtils.getIntParameter(request, "profile_id", 0);
		boolean selfEditYn = request.getRequestURI().indexOf("self_profile.htm") > -1;
		if (selfEditYn) {
			profileId = UserUtils.getUserId(request);
		}

		User user = (User) this.getDomainService().getDomainObject(User.class, new Long((long) profileId));
		int roleId = ServletRequestUtils.getIntParameter(request, "role_id", 0);
		if (roleId != 0) {
			Set roles = user.getRoles();
			Iterator i = roles.iterator();

			while (i.hasNext()) {
				Role role = (Role) i.next();
				if (roleId == role.getId().intValue()) {
					roles.remove(role);
					break;
				}
			}
		}

		return user;
	}

	protected Map referenceData(HttpServletRequest request) throws Exception {
		Map lookupData = new HashMap();
		lookupData.put("luState", this.getQueryService().executeNamedQuery("luState"));
		lookupData.put("luCountry", this.getQueryService().executeNamedQuery("luCountry"));
		return lookupData;
	}

	public ModelAndView save(HttpServletRequest request, HttpServletResponse response, Object command,
			ModelAndView modelView, BindException errors) throws Exception {
		DomainVo bean = (DomainVo) command;
		HashMap additionalParams = new HashMap();
		additionalParams.put("request", request);
		this.getDomainService().saveDomainObject(bean, additionalParams);
		return this.showForm(request, response, errors);
	}
}