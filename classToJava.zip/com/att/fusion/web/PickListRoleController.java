package com.att.fusion.web;

import com.att.fusion.command.PickListBean;
import com.att.fusion.domain.Role;
import com.att.fusion.domain.User;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FeedbackMessage;
import com.att.fusion.web.support.FusionFormController;
import com.att.fusion.web.support.UserUtils;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class PickListRoleController extends FusionFormController {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public Object formBackingObject(HttpServletRequest request) {
		PickListBean pickListBean = new PickListBean();
		pickListBean.setParentId(ServletRequestUtils.getLongParameter(request, "profile_id", 0L));
		pickListBean.setParentName(ServletRequestUtils.getStringParameter(request, "profile_name",
				"Profile Id - " + pickListBean.getParentId()));
		return pickListBean;
	}

	protected Map referenceData(HttpServletRequest request) throws Exception {
		Map lookupData = new HashMap();
		HashMap selectedRoles = new HashMap();
		int profileId = ServletRequestUtils.getIntParameter(request, "profile_id", 0);
		User user = (User) this.getDomainService().getDomainObject(User.class, new Long((long) profileId));
		if (user.getRoles() != null) {
			Iterator i = user.getRoles().iterator();

			while (i.hasNext()) {
				Role role = (Role) i.next();
				selectedRoles.put(role.getId(), role.getId());
			}
		}

		lookupData.put("selectedRoles", selectedRoles);
		lookupData.put("allRoles", this.getDomainService().getList(Role.class));
		return lookupData;
	}

	public ModelAndView save(HttpServletRequest request, HttpServletResponse response, Object command,
			ModelAndView modelView, BindException errors) throws Exception {
		PickListBean bean = (PickListBean) command;
		long profileId = bean.getParentId();
		String[] selected = bean.getSelected();
		int userId = UserUtils.getUserId(request);
		HashMap additionalParams = new HashMap();
		additionalParams.put("request", request);
		User user = (User) this.getDomainService().getDomainObject(User.class, new Long(profileId));
		user.setRoles(new TreeSet());
		if (selected != null) {
			for (int i = 0; i < selected.length; ++i) {
				Long roleId = new Long(selected[i]);
				Role role = new Role();
				role.setId(roleId);
				user.addRole(role);
			}

			this.getDomainService().saveDomainObject(user, additionalParams);
		} else {
			AppUtils.addFeedback(request.getRequestedSessionId(),
					new FeedbackMessage("At least one role must be selected.", 10));
		}

		return new ModelAndView("redirect:profile.htm?profile_id=" + String.valueOf(profileId));
	}
}