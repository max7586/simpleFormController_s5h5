package com.att.fusion.web;

import com.att.fusion.web.support.FusionBaseViewConfigController;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;

public class MenuListController extends FusionBaseViewConfigController {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) {
		List items = null;
		items = this.getQueryService().executeNamedQuery("luMenuSet");
		Map model = new HashMap();
		model.put("items", items);
		return new ModelAndView(this.getViewName(), "model", model);
	}
}