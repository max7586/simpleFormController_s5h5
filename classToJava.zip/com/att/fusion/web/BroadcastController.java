package com.att.fusion.web;

import com.att.fusion.domain.BroadcastMessage;
import com.att.fusion.domain.support.DomainVo;
import com.att.fusion.service.BroadcastService;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FusionFormController;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class BroadcastController extends FusionFormController {
	protected final Log logger = LogFactory.getLog(this.getClass());
	private BroadcastService broadcastService;

	public Object formBackingObject(HttpServletRequest request) throws Exception {
		long messageId = ServletRequestUtils.getLongParameter(request, "message_id", 0L);
		BroadcastMessage message = (BroadcastMessage) this.getDomainService().getDomainObject(BroadcastMessage.class,
				new Long(messageId));
		if (message.getLocationId() == null) {
			message.setLocationId(new Integer(ServletRequestUtils.getStringParameter(request, "message_location_id")));
			message.setActive(Boolean.TRUE);
		}

		return message;
	}

	protected Map referenceData(HttpServletRequest request) throws Exception {
		Map lookupData = new HashMap();
		if ("true".equals(SystemProperties.getProperty("clustered"))) {
			lookupData.put("broadcastSites", AppUtils.getLookupList("fn_lu_broadcast_site", "broadcast_site_cd",
					"broadcast_site_descr", "", "broadcast_site_descr"));
		}

		return lookupData;
	}

	public ModelAndView save(HttpServletRequest request, HttpServletResponse response, Object command,
			ModelAndView modelView, BindException errors) throws Exception {
		DomainVo bean = (DomainVo) command;
		HashMap additionalParams = new HashMap();
		additionalParams.put("request", request);
		this.getDomainService().saveDomainObject(bean, additionalParams);
		this.getBroadcastService().loadMessages();
		return new ModelAndView("redirect:broadcast_list.htm");
	}

	public BroadcastService getBroadcastService() {
		return this.broadcastService;
	}

	public void setBroadcastService(BroadcastService broadcastService) {
		this.broadcastService = broadcastService;
	}
}