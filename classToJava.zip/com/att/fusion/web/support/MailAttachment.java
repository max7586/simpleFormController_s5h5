package com.att.fusion.web.support;

public class MailAttachment {
	public static int INLINE_ATTACHMENT = 1;
	public static int FILE_ATTACHMENT = 2;
	private String fileName;
	private String filePathName;
	private int attachmentType = 1;

	public int getAttachmentType() {
		return this.attachmentType;
	}

	public void setAttachmentType(int attachmentType) {
		this.attachmentType = attachmentType;
	}

	public String getFileName() {
		return this.fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFilePathName() {
		return this.filePathName;
	}

	public void setFilePathName(String filePath) {
		this.filePathName = filePath;
	}
}