package com.att.fusion.web.support;

public class FeedbackMessage {
	private String message;
	private int messageType;
	private boolean keyed;
	public static final int MESSAGE_TYPE_ERROR = 10;
	public static final int MESSAGE_TYPE_WARNING = 20;
	public static final int MESSAGE_TYPE_INFO = 30;
	public static final int MESSAGE_TYPE_SUCCESS = 40;
	public static final String DEFAULT_MESSAGE_SUCCESS = "Update successful.";
	public static final String DEFAULT_MESSAGE_ERROR = "An error occurred while processing the request: ";
	public static final String DEFAULT_MESSAGE_SYSTEM_ADMINISTRATOR = "If the problem persists, please contact your Administrator.";

	public FeedbackMessage() {
	}

	public FeedbackMessage(String message) {
		this(message, 10);
	}

	public FeedbackMessage(String message, int messageType) {
		this(message, messageType, false);
	}

	public FeedbackMessage(String message, int messageType, boolean keyed) {
		this.message = message;
		this.messageType = messageType;
		this.keyed = keyed;
	}

	public String getMessage() {
		return this.message;
	}

	public int getMessageType() {
		return this.messageType;
	}

	public boolean isKeyed() {
		return this.keyed;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public void setMessageType(int messageType) {
		this.messageType = messageType;
	}

	public void setKeyed(boolean keyed) {
		this.keyed = keyed;
	}
}