package com.att.fusion.web.support;

import com.att.fusion.domain.Lookup;
import com.att.fusion.exception.SessionExpiredException;
import com.att.fusion.objectcache.AbstractCacheManager;
import com.att.fusion.service.SearchService;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.AppUtils.1;
import com.att.fusion.web.support.AppUtils.2;
import com.att.fusion.web.support.AppUtils.3;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import net.sf.dozer.util.mapping.MapperIF;
import org.apache.commons.logging.Log;
import org.hibernate.Session;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.util.StringUtils;

public class AppUtils {
	private static SearchService searchService;
	private static AbstractCacheManager cacheManager;
	private static JavaMailSenderImpl mailSender;
	private static MapperIF objectMapper;
	private static boolean applicationLocked;
	private static Hashtable feedback = new Hashtable();

	public static void removeLookupListsFromCache(String keyStartsWith) {
	}

	private static void addLookupListToCache(String key, List list) {
		if (isCacheManagerAvailable()) {
			getCacheManager().putObject(key, list);
		}

	}

	public static void removeLookupListFromCache(String key) {
		if (isCacheManagerAvailable()) {
			getCacheManager().removeObject(key);
		}

	}

	private static List getLookupListFromCache(String key) {
		return isCacheManagerAvailable() ? (List) getCacheManager().getObject(key) : null;
	}

	public static List getLookupList(String dbTable, String dbValueCol, String dbLabelCol) {
		return getLookupList(dbTable, dbValueCol, dbLabelCol, "", "");
	}

	public static List getLookupList(String dbTable, String dbValueCol, String dbLabelCol, String dbFilter,
			String dbOrderBy) {
		return getLookupList(dbTable, dbValueCol, dbLabelCol, dbFilter, dbOrderBy, (Session) null);
	}

	public static List getLookupList(String dbTable, String dbValueCol, String dbLabelCol, String dbFilter,
			String dbOrderBy, Session session) {
		String cacheKey = dbTable + "|" + dbValueCol + "|" + dbLabelCol + "|" + dbFilter + "|" + dbOrderBy;
		List list = getLookupListFromCache(cacheKey);
		if (list == null) {
			list = getSearchService().getLookupList(dbTable, dbValueCol, dbLabelCol, dbFilter, dbOrderBy,
					(HashMap) null);
			if (list != null) {
				addLookupListToCache(cacheKey, list);
			}
		}

		return list;
	}

	public static List getLookupListNoCache(String dbTable, String dbValueCol, String dbLabelCol, String dbFilter,
			String dbOrderBy) {
		return getLookupListNoCache(dbTable, dbValueCol, dbLabelCol, dbFilter, dbOrderBy, (Session) null);
	}

	public static List getLookupListNoCache(String dbTable, String dbValueCol, String dbLabelCol, String dbFilter,
			String dbOrderBy, Session session) {
		return getSearchService().getLookupList(dbTable, dbValueCol, dbLabelCol, dbFilter, dbOrderBy, (HashMap) null);
	}

	public static String getLookupValuebyLabel(String sLabel, String sDBTable, String sDBValueCol, String sDBLabelCol) {
		if (sLabel != null && !sLabel.equals("")) {
			List lstResult = getLookupListNoCache(sDBTable, sDBValueCol, sDBLabelCol,
					sDBLabelCol + "='" + sLabel.replaceAll("'", "''") + "'", "");
			if (lstResult == null) {
				return "";
			} else {
				return lstResult.size() > 0 ? ((Lookup) lstResult.toArray()[0]).getValue() : "";
			}
		} else {
			return "";
		}
	}

	public static String getLookupValueByLabel(String label, List lookupList) {
		Iterator i = null;
		if (label != null && !label.equalsIgnoreCase("")) {
			if (lookupList != null && lookupList.size() != 0) {
				i = lookupList.iterator();

				Lookup lookup;
				do {
					if (!i.hasNext()) {
						return "";
					}

					lookup = (Lookup) i.next();
				} while (!lookup.getLabel().equals(label));

				return lookup.getValue();
			} else {
				return "";
			}
		} else {
			return "";
		}
	}

	public static String lookupValueLabel(String value, List lookupList) {
		if (lookupList != null) {
			Iterator iter = lookupList.iterator();

			while (iter.hasNext()) {
				Lookup lvb = (Lookup) iter.next();
				if (lvb.getValue() != null && lvb.getValue().equals(value)) {
					return lvb.getLabel();
				}
			}
		}

		return null;
	}

	public static String lookupValueLabel(String codeValue, String dbTable, String dbValueCol, String dbLabelCol,
			String dbFilter, String dbOrderBy) {
		try {
			return lookupValueLabel(codeValue, getLookupList(dbTable, dbValueCol, dbLabelCol, dbFilter, dbOrderBy));
		} catch (Exception var7) {
			return null;
		}
	}

	public static String lookupValueLabel(String codeValue, String dbTable, String dbValueCol, String dbLabelCol,
			String dbFilter, String dbOrderBy, Session session) {
		try {
			return lookupValueLabel(codeValue,
					getLookupList(dbTable, dbValueCol, dbLabelCol, dbFilter, dbOrderBy, session));
		} catch (Exception var8) {
			return null;
		}
	}

	public static String lookupValueLabel(String codeValue, String dbTable, String dbValueCol, String dbLabelCol) {
		return lookupValueLabel(codeValue, dbTable, dbValueCol, dbLabelCol, "", "");
	}

	public static AbstractCacheManager getCacheManager() {
		return cacheManager;
	}

	public static boolean isCacheManagerAvailable() {
		return getCacheManager() != null;
	}

	public static Hashtable getFeedback() {
		return feedback;
	}

	public static void notify(String message, String to, String from, boolean contentTypeHtml) {
		notify(message, (String) to, from, (String) null, (String) null, (String) null, contentTypeHtml);
	}

	public static void notify(String message, String to, String from, String subject, boolean contentTypeHtml) {
		notify(message, (String) to, from, subject, (String) null, (String) null, contentTypeHtml);
	}

	public static void notify(String message, String to, String from, String subject, String cc, String bcc,
			boolean contentTypeHtml) {
		String[] toList = new String[1];
		String[] ccList = null;
		String[] bccList = null;
		if (cc != null) {
			ccList = new String[]{cc};
		}

		if (bcc != null) {
			bccList = new String[]{bcc};
		}

		toList[0] = to;
		notify(message, toList, from, subject, ccList, bccList, contentTypeHtml);
	}

	public static void notify(String message, String[] to, String from, String subject, String[] cc, String[] bcc, boolean contentTypeHtml) {
      MimeMessagePreparator messagePreparator = getMessagePreparator(message, to, from, subject, cc, bcc, (List)null, contentTypeHtml);
      Thread mailerThread = new 1(messagePreparator);
      mailerThread.start();
   }

	public static void notifyWithAttachments(String message, String[] to, String from, String subject, String[] cc, String[] bcc, List mailAttachments, boolean contentTypeHtml) {
      MimeMessagePreparator messagePreparator = getMessagePreparator(message, to, from, subject, cc, bcc, mailAttachments, contentTypeHtml);
      Thread mailerThread = new 2(messagePreparator);
      mailerThread.start();
   }

	private static MimeMessagePreparator getMessagePreparator(String message, String[] to, String from, String subject, String[] cc, String[] bcc, List mailAttachments, boolean contentTypeHtml) {
      MimeMessagePreparator messagePreparator = new 3(from, to, message, contentTypeHtml, subject, cc, bcc, mailAttachments);
      return messagePreparator;
   }

	public static void processError(Throwable t, Log logger, HttpServletRequest request) {
		processError(t, logger, request, (MessagesList) null);
	}

	public static void processError(Throwable t, Log logger, HttpServletRequest request, MessagesList messages) {
		String userId = String.valueOf(UserUtils.getUserId(request));
		StringBuffer errorCause = new StringBuffer(
				t.getCause() != null ? t.getMessage() + ", cause: " + t.getCause().getMessage() : t.getMessage());
		StringBuffer message = new StringBuffer();
		message.append("An error occurred while processing the request: ").append(errorCause).append('\n');
		if (messages != null && messages.hasExceptionMessages()) {
			for (int i = 0; i < messages.getExceptionMessages().size(); ++i) {
				addFeedback(
						request != null
								? request.getRequestedSessionId()
								: String.valueOf(UserUtils.getUserId(request)),
						(FeedbackMessage) messages.getExceptionMessages().get(i));
			}

			if (messages.isIncludeCauseInCustomExceptions()) {
				String errorMessage = "Underlying error: " + errorCause.toString() + '\n';
				addFeedback(
						request != null
								? request.getRequestedSessionId()
								: String.valueOf(UserUtils.getUserId(request)),
						new FeedbackMessage(errorMessage.toString() + ". "
								+ "If the problem persists, please contact your Administrator."));
			}
		} else {
			addFeedback(
					request != null ? request.getRequestedSessionId() : String.valueOf(UserUtils.getUserId(request)),
					new FeedbackMessage(
							message.toString() + ". " + "If the problem persists, please contact your Administrator."));
		}

		StackTraceElement[] stackTrace = t.getStackTrace();

		for (int i = 0; i < stackTrace.length; ++i) {
			message.append(stackTrace[i].toString()).append('\n');
		}

		message.append("See below for additional information from the request that caused this error:\n\n");
		if (request != null) {
			message.append(getRequestParameters(request));
			message.append(getRequestAttributes(request));
			message.append(getSessionAttributes(request));
		} else {
			message.append("The request information is not available. The user's session may have expired. ");
		}

		logger.error("[user id - " + userId + "] - " + message.toString());

		try {
			notify("[" + new Date() + ", user id - " + userId + "]\n\n\n" + message.toString(),
					(String[]) StringUtils
							.commaDelimitedListToStringArray(SystemProperties.getProperty("error_email_distribution")),
					SystemProperties.getProperty("error_email_source_address"), "Application Error", (String[]) null,
					(String[]) null, false);
		} catch (MailException var9) {
			logger.error("Error while attempting to send an email message.");
			logger.error(var9.getMessage());
		}

	}

	public static synchronized Vector getFeedback(String userId, boolean removeMessages) {
		Vector messages = null;
		if (feedback.get(userId) != null) {
			messages = new Vector((Vector) feedback.get(userId));
			if (removeMessages) {
				removeFeedback(userId);
			}
		}

		return messages;
	}

	public static synchronized Vector getFeedback(String userId) {
		return getFeedback(userId, true);
	}

	public static synchronized void removeFeedback(String userId) {
		feedback.remove(userId);
	}

	public static synchronized boolean hasError(String userId) {
		Vector messages = getFeedback(userId, false);
		if (messages != null) {
			for (int i = 0; i < messages.size(); ++i) {
				FeedbackMessage message = (FeedbackMessage) messages.get(i);
				if (message.getMessageType() == 10) {
					return true;
				}
			}
		}

		return false;
	}

	public static synchronized boolean hasInfo(String userId) {
		Vector messages = getFeedback(userId, false);
		if (messages != null) {
			for (int i = 0; i < messages.size(); ++i) {
				FeedbackMessage message = (FeedbackMessage) messages.get(i);
				if (message.getMessageType() == 30) {
					return true;
				}
			}
		}

		return false;
	}

	public static synchronized boolean hasWarning(String userId) {
		Vector messages = getFeedback(userId, false);
		if (messages != null) {
			for (int i = 0; i < messages.size(); ++i) {
				FeedbackMessage message = (FeedbackMessage) messages.get(i);
				if (message.getMessageType() == 20) {
					return true;
				}
			}
		}

		return false;
	}

	public static synchronized boolean hasSuccess(String userId) {
		Vector messages = getFeedback(userId, false);
		if (messages != null) {
			for (int i = 0; i < messages.size(); ++i) {
				FeedbackMessage message = (FeedbackMessage) messages.get(i);
				if (message.getMessageType() == 40) {
					return true;
				}
			}
		}

		return false;
	}

	public static synchronized void addFeedback(String userId, FeedbackMessage message) {
		Vector messages = (Vector) feedback.get(userId);
		if (messages == null) {
			messages = new Vector();
			messages.add(message);
			feedback.put(userId, messages);
		} else {
			((Vector) feedback.get(userId)).add(message);
		}

	}

	public void setFeedback(Hashtable feedback) {
		feedback = feedback;
	}

	public static synchronized JavaMailSenderImpl getMailSender() {
		return mailSender;
	}

	public static SearchService getSearchService() {
		return searchService;
	}

	public static boolean isApplicationLocked() {
		return applicationLocked;
	}

	public void setMailSender(JavaMailSenderImpl mailSender) {
		mailSender = mailSender;
	}

	public void setCacheManager(AbstractCacheManager cacheManager) {
		cacheManager = cacheManager;
	}

	public void setSearchService(SearchService searchService) {
		searchService = searchService;
	}

	public static void setApplicationLocked(boolean locked) {
		applicationLocked = locked;
	}

	public static HttpSession getSession(HttpServletRequest request) {
		HttpSession session = null;
		if (request != null) {
			session = request.getSession(false);
			if (session == null) {
				throw new SessionExpiredException();
			} else {
				return session;
			}
		} else {
			throw new SessionExpiredException();
		}
	}

	public static String getRequestParameters(HttpServletRequest request) {
		StringBuffer s = new StringBuffer("The following parameters were in the request:\n");
		Map parameters = request.getParameterMap();
		Iterator i = parameters.keySet().iterator();
		int count = 0;

		while (true) {
			String[] parameterValues;
			do {
				if (!i.hasNext()) {
					s.append("\n");
					return s.toString();
				}

				String key = (String) i.next();
				++count;
				s.append(count).append(". ").append(key).append(" - ");
				parameterValues = (String[]) ((String[]) parameters.get(key));
			} while (parameterValues == null);

			for (int j = 0; j < parameterValues.length; ++j) {
				s.append(parameterValues[j]);
				if (j < parameterValues.length - 1) {
					s.append(", ");
				}

				s.append("\n");
			}
		}
	}

	public static String getRequestAttributes(HttpServletRequest request) {
		StringBuffer s = new StringBuffer("The following attributes were in the request:\n");
		Enumeration e = request.getAttributeNames();
		int count = 0;

		while (e.hasMoreElements()) {
			String key = (String) e.nextElement();
			++count;
			s.append(count).append(". ").append(key).append(" - ").append(request.getAttribute(key)).append("\n");
		}

		s.append("\n");
		return s.toString();
	}

	public static String getSessionAttributes(HttpServletRequest request) {
		StringBuffer s = new StringBuffer("The following attributes were in the session:\n");
		HttpSession httpSession = getSession(request);
		if (httpSession != null) {
			Enumeration e = httpSession.getAttributeNames();
			int count = 0;

			while (e.hasMoreElements()) {
				String key = (String) e.nextElement();
				++count;
				s.append(count).append(". ").append(key).append(" - ").append(httpSession.getAttribute(key))
						.append("\n");
			}
		}

		s.append("\n");
		return s.toString();
	}

	public static MapperIF getDomainObjectToXmlBeanMapper() {
		return objectMapper;
	}

	public void setDomainObjectToXmlBeanMapper(MapperIF domainObjectMapper) {
		objectMapper = domainObjectMapper;
	}
}