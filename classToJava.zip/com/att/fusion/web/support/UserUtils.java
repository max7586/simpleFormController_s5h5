package com.att.fusion.web.support;

import com.att.fusion.FusionObject;
import com.att.fusion.FusionObject.Utilities;
import com.att.fusion.domain.Role;
import com.att.fusion.domain.RoleFunction;
import com.att.fusion.domain.User;
import com.att.fusion.exception.SessionExpiredException;
import com.att.fusion.menu.MenuConfigData;
import com.att.fusion.service.QueryService;
import com.att.fusion.util.SystemProperties;
import java.io.Serializable;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.util.StringUtils;

public class UserUtils implements Serializable, FusionObject {
	private static QueryService queryService;

	public static void setUserSession(HttpServletRequest request, User user, MenuConfigData applicationMenuData,
			MenuConfigData businessDirectMenuData, String loginMethod) {
		HttpSession session = request.getSession(true);
		session.setAttribute(SystemProperties.getProperty("user_attribute_name"), user);
		session.setAttribute(SystemProperties.getProperty("application_menu_attribute_name"), applicationMenuData);
		session.setAttribute(SystemProperties.getProperty("business_direct_menu_attribute_name"),
				businessDirectMenuData);
		session.setAttribute(SystemProperties.getProperty("login_method_attribute_name"), loginMethod);
		getRoleFunctions(request);
		user.setRoles((Set) null);
	}

	public static User getUserSession(HttpServletRequest request) {
		HttpSession session = AppUtils.getSession(request);
		if (session == null) {
			throw new SessionExpiredException();
		} else {
			return (User) session.getAttribute(SystemProperties.getProperty("user_attribute_name"));
		}
	}

	public static void clearUserSession(HttpServletRequest request) {
		HttpSession session = AppUtils.getSession(request);
		if (session == null) {
			throw new SessionExpiredException();
		} else {
			session.removeAttribute(SystemProperties.getProperty("user_attribute_name"));
			session.removeAttribute(SystemProperties.getProperty("application_menu_attribute_name"));
			session.removeAttribute(SystemProperties.getProperty("business_direct_menu_attribute_name"));
			session.removeAttribute(SystemProperties.getProperty("roles_attribute_name"));
			session.removeAttribute(SystemProperties.getProperty("role_functions_attribute_name"));
			session.removeAttribute(SystemProperties.getProperty("login_method_attribute_name"));
		}
	}

	public static String getLoginMethod(HttpServletRequest request) {
		HttpSession session = AppUtils.getSession(request);
		if (session == null) {
			throw new SessionExpiredException();
		} else {
			return (String) session.getAttribute(SystemProperties.getProperty("login_method_attribute_name"));
		}
	}

	public static HashMap getRoles(HttpServletRequest request) {
		HashMap roles = null;
		HttpSession session = request.getSession();
		roles = (HashMap) session.getAttribute(SystemProperties.getProperty("roles_attribute_name"));
		if (roles == null) {
			User user = getUserSession(request);
			roles = getAllUserRoles(user);
			session.setAttribute(SystemProperties.getProperty("roles_attribute_name"), getAllUserRoles(user));
		}

		return roles;
	}

	public static HashMap getAllUserRoles(User user) {
		HashMap roles = new HashMap();
		Iterator i = user.getRoles().iterator();

		while (i.hasNext()) {
			Role role = (Role) i.next();
			if (role.getActive()) {
				roles.put(role.getId(), role);
				addChildRoles(role, roles);
			}
		}

		return roles;
	}

	public static HashMap getAllUserRoles(Role role) {
		HashMap roles = new HashMap();
		if (role.getActive()) {
			roles.put(role.getId(), role);
			addChildRoles(role, roles);
		}

		return roles;
	}

	public static String getRolesAsList(HttpServletRequest request) {
		return Utilities.nvl(StringUtils.collectionToCommaDelimitedString(getRoles(request).keySet()));
	}

	public static Long getPriorityRole(HttpServletRequest request) {
		Long roleId = null;
		TreeMap orderedRoles = new TreeMap();
		Map roleMap = getRoles(request);
		Iterator i = roleMap.keySet().iterator();

		while (i.hasNext()) {
			Role role = (Role) roleMap.get(i.next());
			Integer priority = role.getPriority();
			if (priority != null) {
				orderedRoles.put(priority, role.getId());
			}
		}

		if (!orderedRoles.isEmpty()) {
			roleId = (Long) orderedRoles.get(orderedRoles.firstKey());
		}

		return roleId;
	}

	public static Set getRoleFunctions(HttpServletRequest request) {
		HashSet roleFunctions = null;
		HttpSession session = request.getSession();
		roleFunctions = (HashSet) session.getAttribute(SystemProperties.getProperty("role_functions_attribute_name"));
		if (roleFunctions == null) {
			HashMap roles = getRoles(request);
			roleFunctions = new HashSet();
			Iterator i = roles.keySet().iterator();

			while (i.hasNext()) {
				Long roleKey = (Long) i.next();
				Role role = (Role) roles.get(roleKey);
				Iterator j = role.getRoleFunctions().iterator();

				while (j.hasNext()) {
					RoleFunction function = (RoleFunction) j.next();
					roleFunctions.add(function.getCode());
				}
			}

			session.setAttribute(SystemProperties.getProperty("role_functions_attribute_name"), roleFunctions);
		}

		return roleFunctions;
	}

	public static Set getRoleFunctions(Map roles) {
		HashSet roleFunctions = new HashSet();
		Iterator i = roles.keySet().iterator();

		while (i.hasNext()) {
			Long roleKey = (Long) i.next();
			Role role = (Role) roles.get(roleKey);
			Iterator j = role.getRoleFunctions().iterator();

			while (j.hasNext()) {
				RoleFunction function = (RoleFunction) j.next();
				roleFunctions.add(function.getCode());
			}
		}

		return roleFunctions;
	}

	public static boolean isAccessible(HttpServletRequest request, String functionKey) {
		return getRoleFunctions(request).contains(functionKey);
	}

	public static boolean hasRole(HttpServletRequest request, String roleKey) {
		return getRoles(request).keySet().contains(new Long(roleKey));
	}

	public static boolean hasRole(User user, String roleKey) {
		return getAllUserRoles(user).keySet().contains(new Long(roleKey));
	}

	public static int getUserId(HttpServletRequest request) {
		return getUserIdAsLong(request).intValue();
	}

	public static Long getUserIdAsLong(HttpServletRequest request) {
		Long userId = new Long(SystemProperties.getProperty("application_user_id"));
		if (request != null && getUserSession(request) != null) {
			userId = getUserSession(request).getId();
		}

		return userId;
	}

	private static void addChildRoles(Role role, HashMap roles) {
		Set childRoles = role.getChildRoles();
		if (childRoles != null && childRoles.size() > 0) {
			Iterator j = childRoles.iterator();

			while (j.hasNext()) {
				Role childRole = (Role) j.next();
				if (childRole.getActive()) {
					roles.put(childRole.getId(), childRole);
					addChildRoles(childRole, roles);
				}
			}
		}

	}

	public static boolean isUrlAccessible(HttpServletRequest request, String currentUrl) {
		Map params = new HashMap();
		params.put("current_url", currentUrl);
		List list = getQueryService().executeNamedQuery("restrictedUrls", params);
		if (list != null) {
			for (int i = 0; i < list.size(); ++i) {
				Object[] restrictedUrl = (Object[]) ((Object[]) list.get(i));
				String url = (String) restrictedUrl[0];
				String functionCd = (String) restrictedUrl[1];
				if (!isAccessible(request, functionCd)) {
					return false;
				}
			}
		}

		return true;
	}

	public static QueryService getQueryService() {
		return queryService;
	}

	public void setQueryService(QueryService queryService) {
		queryService = queryService;
	}
}