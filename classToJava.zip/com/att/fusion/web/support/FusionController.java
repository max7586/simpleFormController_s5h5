package com.att.fusion.web.support;

import com.att.fusion.FusionObject;
import javax.servlet.http.HttpServletRequest;

public interface FusionController extends ControllerProperties, FusionObject {
	MessagesList getCustomMessages();

	void setCustomMessages(MessagesList var1);

	boolean displaySuccessMessaging(HttpServletRequest var1);

	void setSuccessMessagingOn(HttpServletRequest var1);

	void setSuccessMessagingOff(HttpServletRequest var1);

	Object getContext(HttpServletRequest var1);

	String getExceptionView();

	void setExceptionView(String var1);
}