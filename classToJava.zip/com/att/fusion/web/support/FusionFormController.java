package com.att.fusion.web.support;

import com.att.fusion.service.DomainService;
import com.att.fusion.service.QueryService;
import com.att.fusion.web.support.FusionController.StaticMessageHandler;
import java.lang.reflect.Method;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.beans.propertyeditors.CustomBooleanEditor;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.beans.propertyeditors.CustomNumberEditor;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.ServletRequestDataBinder;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.SimpleFormController;

public abstract class FusionFormController extends SimpleFormController implements FusionController {
	private MessagesList customMessages;
	private DomainService domainService;
	private QueryService queryService;
	private String exceptionView;

	protected void initBinder(HttpServletRequest request, ServletRequestDataBinder dataBinder) throws Exception {
		super.initBinder(request, dataBinder);
		NumberFormat nf = NumberFormat.getInstance(request.getLocale());
		DecimalFormat df = (DecimalFormat) nf;
		df.setDecimalSeparatorAlwaysShown(false);
		df.applyPattern("########################");
		CustomNumberEditor longNumberEditor = new CustomNumberEditor(Long.class, nf, true);
		dataBinder.registerCustomEditor(Long.class, longNumberEditor);
		CustomNumberEditor doubleNumberEditor = new CustomNumberEditor(Double.class, nf, true);
		dataBinder.registerCustomEditor(Double.class, doubleNumberEditor);
		CustomNumberEditor integerNumberEditor = new CustomNumberEditor(Integer.class, nf, true);
		dataBinder.registerCustomEditor(Integer.class, integerNumberEditor);
		CustomNumberEditor shortNumberEditor = new CustomNumberEditor(Short.class, nf, true);
		dataBinder.registerCustomEditor(Short.class, shortNumberEditor);
		CustomBooleanEditor booleanEditor = new CustomBooleanEditor("Y", "N", true);
		dataBinder.registerCustomEditor(Boolean.class, booleanEditor);
		SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy");
		dateFormat.setLenient(false);
		dataBinder.registerCustomEditor(Date.class, (String) null, new CustomDateEditor(dateFormat, true));
	}

	protected void onBind(HttpServletRequest request, Object command, BindException bindExceptions) throws Exception {
		if (bindExceptions.hasErrors()) {
			List errors = bindExceptions.getAllErrors();

			for (int i = 0; i < errors.size(); ++i) {
				ObjectError bindError = (ObjectError) errors.get(i);
				Object[] arr = bindError.getArguments();
				int j = 0;
				if (j < arr.length) {
					AppUtils.addFeedback(request.getRequestedSessionId(),
							new FeedbackMessage("validation.error", 10, true));
					return;
				}
			}
		}

	}

	protected final ModelAndView onSubmit(HttpServletRequest request, HttpServletResponse response, Object command,
			BindException errors) throws Exception {
		ModelAndView modelView = new ModelAndView(this.getFormView());
		String task = ServletRequestUtils.getRequiredStringParameter(request, "task");
		Class[] parameterTypes = new Class[]{HttpServletRequest.class, HttpServletResponse.class, Object.class,
				ModelAndView.class, BindException.class};
		Object[] argumentList = new Object[]{request, response, command, modelView, errors};
		Method m = this.getClass().getMethod(task, parameterTypes);
		this.logger.info("Calling " + this.getClass().getName() + "." + task
				+ "(HttpServletRequest, HttpServletResonse, Object, ModelAndView, BindException)...");
		return (ModelAndView) m.invoke(this, argumentList);
	}

	public ModelAndView handleError(HttpServletRequest request) {
		try {
			Object command = this.formBackingObject(request);
			ServletRequestDataBinder binder = this.bindAndValidate(request, command);
			BindException errors = new BindException(binder.getBindingResult());
			return this.showForm(request, errors, this.getExceptionView());
		} catch (Exception var5) {
			this.logger.error(
					"An error occurred while attempting to recover from a form submission error. Here are the details: "
							+ var5.getMessage());
			return new ModelAndView(this.getExceptionView());
		}
	}

	public DomainService getDomainService() {
		return this.domainService;
	}

	public QueryService getQueryService() {
		return this.queryService;
	}

	public MessagesList getCustomMessages() {
		return this.customMessages;
	}

	public String getExceptionView() {
		return this.exceptionView == null ? this.getFormView() : this.exceptionView;
	}

	public void setDomainService(DomainService domainService) {
		this.domainService = domainService;
	}

	public void setQueryService(QueryService queryService) {
		this.queryService = queryService;
	}

	public void setCustomMessages(MessagesList customMessages) {
		this.customMessages = customMessages;
	}

	public void setExceptionView(String exceptionView) {
		this.exceptionView = exceptionView;
	}

	public Object getContext(HttpServletRequest request) {
		return "user_id = " + UserUtils.getUserId(request);
	}

	public boolean displaySuccessMessaging(HttpServletRequest request) {
		return StaticMessageHandler.displaySuccessMessaging(request);
	}

	public void setSuccessMessagingOn(HttpServletRequest request) {
		StaticMessageHandler.setSuccessMessagingOn(request);
	}

	public void setSuccessMessagingOff(HttpServletRequest request) {
		StaticMessageHandler.setSuccessMessagingOff(request);
	}
}