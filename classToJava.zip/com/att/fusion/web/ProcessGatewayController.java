package com.att.fusion.web;

import com.att.fusion.command.LoginBean;
import com.att.fusion.service.LoginService;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.FusionBaseController;
import com.att.fusion.web.support.UserUtils;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.ModelAndView;

public class ProcessGatewayController extends FusionBaseController {
	public static final String DEFAULT_SUCCESS_VIEW = "welcome";
	public static final String DEFAULT_FAILURE_VIEW = "login";
	public static final String ERROR_MESSAGE_KEY = "error";
	private LoginService loginService;
	protected final Log logger = LogFactory.getLog(this.getClass());

	public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response)
			throws Exception {
		Map model = new HashMap();
		LoginBean commandBean = new LoginBean();
		String attuid = this.getAttuid(request);
		if (attuid != null && attuid.length() != 0) {
			commandBean.setAttuid(attuid);
			commandBean = this.getLoginService().findUser(commandBean,
					(String) request.getAttribute("menu_properties_filename"), (HashMap) null);
			if (commandBean.getUser() == null) {
				String loginErrorMessage = commandBean.getLoginErrorMessage() != null
						? commandBean.getLoginErrorMessage()
						: "login.error.hrid.not-found";
				model.put("error", loginErrorMessage);
				return new ModelAndView("login", "model", model);
			} else {
				UserUtils.setUserSession(request, commandBean.getUser(), commandBean.getMenu(),
						commandBean.getBusinessDirectMenu(), SystemProperties.getProperty("login_method_web_junction"));
				this.logger.info(commandBean.getUser().getSbcid() + " exists in the the system.");
				return new ModelAndView("redirect:welcome.htm");
			}
		} else {
			model.put("error", "login.error.header.empty");
			return new ModelAndView("login", "model", model);
		}
	}

	public String getAttuid(HttpServletRequest request) {
		String attuid = null;

		try {
			attuid = request.getHeader(SystemProperties.getProperty("web_junction_user_id_header_name"));
			this.logger.info("ATTUID - " + attuid);
		} catch (Throwable var4) {
			this.logger.info(
					"An error occurred while attempting to extract the user's ATTUID from their CSP cookie. Here are the details: "
							+ var4.getMessage());
		}

		return attuid;
	}

	public LoginService getLoginService() {
		return this.loginService;
	}

	public void setLoginService(LoginService loginService) {
		this.loginService = loginService;
	}
}