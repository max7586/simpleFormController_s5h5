package com.att.fusion.web;

import com.att.fusion.domain.BroadcastMessage;
import com.att.fusion.service.BroadcastService;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FusionBaseViewConfigController;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class BroadcastListController extends FusionBaseViewConfigController {
	private BroadcastService broadcastService;
	protected final Log logger = LogFactory.getLog(this.getClass());

	public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) {
		Map model = new HashMap();
		List items = null;
		int messageId = ServletRequestUtils.getIntParameter(request, "message_id", 0);
		String task = ServletRequestUtils.getStringParameter(request, "task", "get");
		if (messageId != 0 && (task.equals("delete") || task.equals("toggleActive"))) {
			BroadcastMessage message = (BroadcastMessage) this.getDomainService()
					.getDomainObject(BroadcastMessage.class, new Long((long) messageId));
			if (task.equals("delete")) {
				this.getDomainService().deleteDomainObject(message);
			} else if (task.equals("toggleActive")) {
				HashMap additionalParams = new HashMap();
				additionalParams.put("request", request);
				message.setActive(new Boolean(!message.getActive()));
				this.getDomainService().saveDomainObject(message, additionalParams);
			}

			this.getBroadcastService().loadMessages();
		}

		items = this.getDomainService().getList(BroadcastMessage.class);
		Collections.sort(items);
		model.put("messagesList", this.packageMessages(items));
		List locations = AppUtils.getLookupList("fn_lu_message_location", "message_location_id",
				"message_location_descr", "", "message_location_id");
		model.put("messageLocations", locations);
		if ("true".equals(SystemProperties.getProperty("clustered"))) {
			List sites = AppUtils.getLookupList("fn_lu_broadcast_site", "broadcast_site_cd", "broadcast_site_descr", "",
					"broadcast_site_descr");
			model.put("broadcastSites", sites);
		}

		return new ModelAndView(this.getViewName(), "model", model);
	}

	private HashMap packageMessages(List messages) {
		HashMap messagesList = new HashMap();
		Set locationMessages = null;
		Integer previousLocationId = null;

		for (int i = 0; i < messages.size(); ++i) {
			BroadcastMessage message = (BroadcastMessage) messages.get(i);
			if (!message.getLocationId().equals(previousLocationId)) {
				if (previousLocationId != null) {
					messagesList.put(previousLocationId.toString(), locationMessages);
				}

				locationMessages = new TreeSet();
				previousLocationId = message.getLocationId();
			}

			locationMessages.add(message);
		}

		if (previousLocationId != null) {
			messagesList.put(previousLocationId.toString(), locationMessages);
		}

		return messagesList;
	}

	public BroadcastService getBroadcastService() {
		return this.broadcastService;
	}

	public void setBroadcastService(BroadcastService broadcastService) {
		this.broadcastService = broadcastService;
	}
}