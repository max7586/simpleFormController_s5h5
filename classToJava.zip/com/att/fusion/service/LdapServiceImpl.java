package com.att.fusion.service;

import com.att.fusion.FusionObject.Utilities;
import com.att.fusion.command.support.SearchResult;
import com.att.fusion.domain.User;
import com.att.fusion.domain.support.DomainVo;
import com.att.fusion.service.support.FusionService;
import com.att.fusion.service.support.ServiceLocator;
import com.att.fusion.util.SystemProperties;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.Attribute;
import javax.naming.directory.Attributes;
import javax.naming.directory.DirContext;
import javax.naming.directory.SearchControls;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LdapServiceImpl extends FusionService implements LdapService {
	private ServiceLocator serviceLocator = null;
	protected final Log logger = LogFactory.getLog(this.getClass());

	public SearchResult searchPost(DomainVo searchCriteria, String sortBy1, String sortBy2, String sortBy3, int pageNo,
			int dataSize, int userId) throws Exception {
		DirContext dirContext = this.getServiceLocator().getDirContext(
				SystemProperties.getProperty("post_initial_context_factory"),
				SystemProperties.getProperty("post_provider_url"),
				SystemProperties.getProperty("post_security_principal"));
		SearchResult searchResult = new SearchResult();

		try {
			String[] postAttributes = new String[]{"nickname", "givenName", "initials", "sn", "employeeNumber", "mail",
					"telephoneNumber", "departmentNumber", "a1", "street", "l", "st", "postalCode", "zip4",
					"physicalDeliveryOfficeName", "bc", "friendlyCountryName", "bd", "bdname", "jtname", "mgrid", "a2",
					"compcode", "compdesc"};
			SearchControls searchControls = new SearchControls();
			searchControls.setTimeLimit(5000);
			searchControls.setReturningAttributes(postAttributes);
			StringBuffer filterClause = new StringBuffer("(&(objectClass=*)");
			User user = (User) searchCriteria;
			if (Utilities.nvl(user.getFirstName()).length() > 0) {
				filterClause.append("(givenName=").append(user.getFirstName()).append("*)");
			}

			if (Utilities.nvl(user.getLastName()).length() > 0) {
				filterClause.append("(sn=").append(user.getLastName()).append("*)");
			}

			if (Utilities.nvl(user.getHrid()).length() > 0) {
				filterClause.append("(employeeNumber=").append(user.getHrid()).append("*)");
			}

			if (Utilities.nvl(user.getOrgCode()).length() > 0) {
				filterClause.append("(departmentNumber=").append(user.getOrgCode()).append("*)");
			}

			if (Utilities.nvl(user.getEmail()).length() > 0) {
				filterClause.append("(mail=").append(user.getEmail()).append("*)");
			}

			if (Utilities.nvl(user.getSbcid()).length() > 0) {
				filterClause.append("(a1=").append(user.getSbcid()).append("*)");
			}

			filterClause.append(")");
			List list = new ArrayList();
			if (!filterClause.toString().equals("(&(objectClass=*))")) {
				NamingEnumeration e = dirContext.search(
						SystemProperties.getProperty("post_provider_url") + "/"
								+ SystemProperties.getProperty("post_security_principal"),
						filterClause.toString(), searchControls);
				list = this.processResults(e);
			}

			Collections.sort(list);
			searchResult = new SearchResult(list);
			searchResult.setPageNo(pageNo);
			if (dataSize >= 0) {
				searchResult.setDataSize(dataSize);
			} else {
				searchResult.setDataSize(list.size());
			}
		} catch (NamingException var19) {
			this.logger.error(var19.getMessage());
		} finally {
			dirContext.close();
		}

		return searchResult;
	}

	private ArrayList processResults(NamingEnumeration e) throws NamingException {
		ArrayList results = new ArrayList();
		int count = 0;

		while (e.hasMore()) {
			javax.naming.directory.SearchResult searchResult = (javax.naming.directory.SearchResult) e.next();
			results.add(this.processAttributes(searchResult.getAttributes()));
			++count;
			if (count > Integer.parseInt(SystemProperties.getProperty("post_max_result_size"))) {
				break;
			}
		}

		return results;
	}

	private DomainVo processAttributes(Attributes resultAttributes) throws NamingException {
		User user = new User();

		try {
			if (resultAttributes == null) {
				System.out.println("This result has no attributes");
			} else {
				NamingEnumeration e = resultAttributes.getAll();

				while (e.hasMore()) {
					Attribute attribute = (Attribute) e.next();
					NamingEnumeration ie = attribute.getAll();

					while (ie.hasMore()) {
						if (attribute.getID().equalsIgnoreCase("nickname")) {
							user.setFirstName((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("initials")) {
							user.setMiddleInitial((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("sn")) {
							user.setLastName((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("employeeNumber")) {
							user.setHrid((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("mail")) {
							user.setEmail((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("telephoneNumber")) {
							user.setPhone((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("departmentNumber")) {
							user.setOrgCode((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("a1")) {
							user.setSbcid((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("street")) {
							user.setAddress1((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("l")) {
							user.setCity((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("st")) {
							user.setState((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("postalCode")) {
							user.setZipCode((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("zip4")) {
							user.setZipCodeSuffix((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("physicalDeliveryOfficeName")) {
							user.setLocationClli((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("bc")) {
							user.setBusinessCountryCode((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("friendlyCountryName")) {
							user.setBusinessCountryName((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("bd")) {
							user.setDepartmentCode((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("bdname")) {
							user.setDepartment((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("jtname")) {
							user.setJobTitle((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("mgrid")) {
							user.setManagerAttuid((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("a2")) {
							user.setCommandChain((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("compcode")) {
							user.setCompanyCode((String) ie.next());
						} else if (attribute.getID().equalsIgnoreCase("compdesc")) {
							user.setCompany((String) ie.next());
						} else {
							ie.next();
						}
					}
				}
			}

			return user;
		} catch (NamingException var9) {
			this.logger.error("An error occurred while processing the following user from POST with an ATTUID of "
					+ user.getSbcid());
			this.logger.error(var9.getMessage());
			return user;
		} finally {
			;
		}
	}

	public ServiceLocator getServiceLocator() {
		return this.serviceLocator;
	}

	public void setServiceLocator(ServiceLocator serviceLocator) {
		this.serviceLocator = serviceLocator;
	}
}