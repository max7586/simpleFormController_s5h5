package com.att.fusion.service;

import com.att.fusion.command.LoginBean;
import java.util.HashMap;

public interface LoginService {
	LoginBean findUser(LoginBean var1, String var2, HashMap var3) throws Exception;
}