package com.att.fusion.service;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

public interface QueryService {
	List executeQuery(String var1, Class var2, HashMap var3);

	List executeQuery(String var1, Class var2, Integer var3, Integer var4, HashMap var5);

	List executeQuery(String var1, HashMap var2);

	List executeQuery(String var1, Integer var2, Integer var3, HashMap var4);

	List executeNamedQuery(String var1, Integer var2, Integer var3, HashMap var4);

	List executeNamedQuery(String var1, Map var2, HashMap var3);

	List executeNamedQuery(String var1, Map var2, Integer var3, Integer var4, HashMap var5);

	int executeUpdateQuery(String var1, HashMap var2) throws RuntimeException;

	int executeNamedUpdateQuery(String var1, Map var2, HashMap var3) throws RuntimeException;

	void executeBatchUpdate(LinkedHashSet var1, boolean var2, HashMap var3) throws RuntimeException;

	List executeQuery(String var1, Class var2);

	List executeQuery(String var1, Class var2, Integer var3, Integer var4);

	List executeQuery(String var1);

	List executeQuery(String var1, Integer var2, Integer var3);

	List executeNamedQuery(String var1);

	List executeNamedQuery(String var1, Integer var2, Integer var3);

	List executeNamedQuery(String var1, Map var2);

	List executeNamedQuery(String var1, Map var2, Integer var3, Integer var4);

	int executeUpdateQuery(String var1) throws RuntimeException;

	int executeNamedUpdateQuery(String var1) throws RuntimeException;

	int executeNamedUpdateQuery(String var1, Map var2) throws RuntimeException;

	void executeBatchUpdate(LinkedHashSet var1, boolean var2) throws RuntimeException;
}