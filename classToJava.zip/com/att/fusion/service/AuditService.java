package com.att.fusion.service;

import com.att.fusion.domain.AuditLog;
import java.util.HashMap;

public interface AuditService {
	void logActivity(AuditLog var1, HashMap var2);
}