package com.att.fusion.service;

import com.att.fusion.domain.support.DomainVo;
import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;

public interface DomainService {
	DomainVo getDomainObject(Class var1, Serializable var2, HashMap var3);

	void deleteDomainObject(DomainVo var1, HashMap var2);

	void deleteDomainObjects(Class var1, String var2, HashMap var3);

	void saveDomainObject(DomainVo var1, HashMap var2);

	void executeBatchUpdate(LinkedHashSet var1, HashMap var2) throws RuntimeException;

	void executeCallback(Class var1, Object var2, HashMap var3) throws RuntimeException;

	List getList(Class var1, HashMap var2);

	List getList(Class var1, List var2, String var3, HashMap var4);

	List getList(Class var1, List var2, int var3, int var4, String var5, HashMap var6);

	List getList(Class var1, String var2, String var3, HashMap var4);

	List getList(Class var1, String var2, int var3, int var4, String var5, HashMap var6);

	void synchronize(HashMap var1);

	DomainVo getDomainObject(Class var1, Serializable var2);

	void deleteDomainObject(DomainVo var1);

	void deleteDomainObjects(Class var1, String var2);

	void saveDomainObject(DomainVo var1);

	void executeBatchUpdate(LinkedHashSet var1) throws RuntimeException;

	void executeCallback(Class var1, Object var2) throws RuntimeException;

	List getList(Class var1);

	List getList(Class var1, List var2, String var3);

	List getList(Class var1, List var2, int var3, int var4, String var5);

	List getList(Class var1, String var2, String var3);

	List getList(Class var1, String var2, int var3, int var4, String var5);

	void synchronize();
}