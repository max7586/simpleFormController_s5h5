package com.att.fusion.service;

import com.att.fusion.dao.ModelDao;
import com.att.fusion.domain.BroadcastMessage;
import com.att.fusion.domain.Lookup;
import com.att.fusion.service.support.FusionService;
import com.att.fusion.web.support.AppUtils;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.List;

public class BroadcastServiceImpl extends FusionService implements BroadcastService {
	private static ModelDao modelDao;
	private static Hashtable broadcastMessages = new Hashtable();

	public void loadMessages() {
		List messageLocations = AppUtils.getLookupListNoCache("fn_lu_message_location", "message_location_id",
				"message_location_descr", "", "message_location_id");

		for (int i = 0; i < messageLocations.size(); ++i) {
			Lookup location = (Lookup) messageLocations.get(i);
			String locationId = location.getValue();
			broadcastMessages.put(locationId, this.getPersistedBroadcastMessages(locationId));
		}

	}

	private List getPersistedBroadcastMessages(String locationId) {
		HashMap params = new HashMap();
		params.put("location_id", new Integer(locationId));
		return this.getModelDao().executeNamedQuery("broadcastMessages", params, (Integer) null, (Integer) null,
				(HashMap) null);
	}

	public Hashtable getBroadcastMessages() {
		return broadcastMessages;
	}

	public static List getBroadcastMessages(String locationId) {
		return (List) broadcastMessages.get(locationId);
	}

	public static String displayMessages(String locationId) {
		return displayMessages(locationId, (String) null);
	}

	public static String displayMessages(String locationId, String siteCd) {
		StringBuffer html = new StringBuffer();
		List messages = getBroadcastMessages(locationId);

		for (int i = 0; i < messages.size(); ++i) {
			BroadcastMessage message = (BroadcastMessage) messages.get(i);
			if (message.getSiteCd() == null || message.getSiteCd() != null && message.getSiteCd().equals(siteCd)) {
				html.append("<li class=\"broadcastMessage\">").append(message.getMessageText());
			}
		}

		if (html.length() > 0) {
			html.insert(0, "<ul class=\"broadcastMessageList\">");
			html.append("</ul>");
		}

		return html.toString();
	}

	public static boolean hasMessages(String locationId) {
		return hasMessages(locationId, (String) null);
	}

	public static boolean hasMessages(String locationId, String siteCd) {
		List messages = getBroadcastMessages(locationId);
		boolean messagesExist = messages != null && messages.size() != 0;
		if (siteCd == null) {
			return messagesExist;
		} else {
			for (int i = 0; i < messages.size(); ++i) {
				BroadcastMessage message = (BroadcastMessage) messages.get(i);
				if (message.getSiteCd().equals(siteCd) || message.getSiteCd() == null) {
					return true;
				}
			}

			return false;
		}
	}

	public ModelDao getModelDao() {
		return modelDao;
	}

	public void setModelDao(ModelDao modelDao) {
		modelDao = modelDao;
	}
}