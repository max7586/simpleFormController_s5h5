package com.att.fusion.service;

import java.util.Hashtable;

public interface BroadcastService {
	Hashtable getBroadcastMessages();

	void loadMessages();
}