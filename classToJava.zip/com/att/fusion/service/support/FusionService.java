package com.att.fusion.service.support;

import com.att.fusion.FusionObject;

public class FusionService implements FusionObject {
}