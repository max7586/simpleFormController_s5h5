package com.att.fusion.domain;

import com.att.fusion.domain.support.DomainVo;
import java.util.Set;
import java.util.TreeSet;

public class Tab extends DomainVo {
	private Integer level;
	private String code;
	private String name;
	private String descr;
	private String action;
	private String functionCd;
	private boolean active;
	private Integer sortOrder;
	private String parentCode;
	private boolean disabled;
	private boolean selected;
	private Set subTabs = new TreeSet();

	public int compareTo(Object obj) {
		Integer c1 = this.getSortOrder();
		Integer c2 = ((Tab) obj).getSortOrder();
		return c1 != null && c2 != null ? c1.compareTo(c2) : 1;
	}

	public String getAction() {
		return this.action;
	}

	public boolean isActive() {
		return this.active;
	}

	public String getCode() {
		return this.code;
	}

	public String getDescr() {
		return this.descr;
	}

	public String getFunctionCd() {
		return this.functionCd;
	}

	public String getName() {
		return this.name;
	}

	public Integer getSortOrder() {
		return this.sortOrder;
	}

	public String getParentCode() {
		return this.parentCode;
	}

	public Set getSubTabs() {
		return this.subTabs;
	}

	public boolean isDisabled() {
		return this.disabled;
	}

	public Integer getLevel() {
		return this.level;
	}

	public boolean isSelected() {
		return this.selected;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	public void setFunctionCd(String functionCd) {
		this.functionCd = functionCd;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}

	public void setParentCode(String parentCode) {
		this.parentCode = parentCode;
	}

	public void setSubTabs(Set subTabs) {
		this.subTabs = subTabs;
	}

	public void setDisabled(boolean disabled) {
		this.disabled = disabled;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public void setSelected(boolean selected) {
		this.selected = selected;
	}
}