package com.att.fusion.domain;

import com.att.fusion.domain.support.DomainVo;
import java.util.Set;
import java.util.TreeSet;

public class Branch extends DomainVo {
	private String name;
	private Branch parentBranch;
	private Set childBranches;

	public Branch() {
		this.childBranches = new TreeSet();
	}

	public Branch(String name) {
		this();
		this.setName(name);
	}

	public Branch(String name, Branch parentBranch) {
		this(name);
		this.setParentBranch(parentBranch);
	}

	public String getName() {
		return this.name;
	}

	public void addChildBranch(Branch branch) {
		this.getChildBranches().add(branch);
	}

	public Set getChildBranches() {
		return this.childBranches;
	}

	public Branch getParentBranch() {
		return this.parentBranch;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setChildBranches(Set childBranches) {
		this.childBranches = childBranches;
	}

	public void setParentBranch(Branch parentBranch) {
		this.parentBranch = parentBranch;
	}
}