package com.att.fusion.domain.support;

import com.att.fusion.domain.AuditLog;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DomainVo extends FusionVo implements Serializable, Cloneable, Comparable {
	protected final Log logger = LogFactory.getLog(this.getClass());
	protected Long id;
	protected Date created;
	protected Date modified;
	protected Long createdId;
	protected Long modifiedId;
	protected Long rowNum;
	protected Serializable auditUserId;
	Set auditTrail = null;

	public void setId(Long i) {
		this.id = i;
	}

	public void setCreated(Date created) {
		this.created = created;
	}

	public void setModified(Date modified) {
		this.modified = modified;
	}

	public void setCreatedId(Long createdId) {
		this.createdId = createdId;
	}

	public void setModifiedId(Long modifiedId) {
		this.modifiedId = modifiedId;
	}

	public void setAuditUserId(Serializable auditUserId) {
		this.auditUserId = auditUserId;
	}

	public void setRowNum(Long rowNum) {
		this.rowNum = rowNum;
	}

	public void setAuditTrail(Set auditTrail) {
		this.auditTrail = auditTrail;
	}

	public Long getId() {
		return this.id;
	}

	public Date getCreated() {
		return this.created;
	}

	public Date getModified() {
		return this.modified;
	}

	public Long getCreatedId() {
		return this.createdId;
	}

	public Long getModifiedId() {
		return this.modifiedId;
	}

	public Serializable getAuditUserId() {
		return this.auditUserId;
	}

	public Long getRowNum() {
		return this.rowNum;
	}

	public Set getAuditTrail() {
		return this.auditTrail;
	}

	public void addAuditTrailLog(AuditLog auditLog) {
		if (this.getAuditTrail() == null) {
			this.setAuditTrail(new HashSet());
		}

		this.getAuditTrail().add(auditLog);
	}

	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

	public Object copy() {
		return this.copy(false);
	}

	public Object copy(boolean isIdNull) {
		ByteArrayOutputStream baos = null;
		ByteArrayInputStream bais = null;
		ObjectOutputStream oos = null;
		ObjectInputStream ois = null;
		DomainVo newVo = null;

		try {
			baos = new ByteArrayOutputStream();
			oos = new ObjectOutputStream(baos);
			oos.writeObject(this);
			bais = new ByteArrayInputStream(baos.toByteArray());
			ois = new ObjectInputStream(bais);
			newVo = (DomainVo) ois.readObject();
			if (isIdNull) {
				newVo.setId((Long) null);
			}
		} catch (Exception var8) {
			var8.printStackTrace();
		}

		return newVo;
	}

	public int compareTo(Object obj) {
		Long c1 = this.getId();
		Long c2 = ((DomainVo) obj).getId();
		return c1 != null && c2 != null ? c1.compareTo(c2) : 1;
	}
}