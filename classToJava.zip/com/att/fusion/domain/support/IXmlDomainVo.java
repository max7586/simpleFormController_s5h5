package com.att.fusion.domain.support;

public interface IXmlDomainVo {
	Class getXmlBeanClass();

	String getXmlText();
}