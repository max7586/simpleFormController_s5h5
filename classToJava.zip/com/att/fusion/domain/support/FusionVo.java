package com.att.fusion.domain.support;

import com.att.fusion.FusionObject;

public class FusionVo implements FusionObject {
}