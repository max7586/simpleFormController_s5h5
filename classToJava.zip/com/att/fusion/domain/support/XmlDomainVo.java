package com.att.fusion.domain.support;

import com.att.fusion.domain.support.IXmlDomainVo.FusionXmlBeanFactory;
import com.att.fusion.exception.FusionXmlBeanCreationException;
import com.att.fusion.web.support.AppUtils;
import org.apache.xmlbeans.XmlObject;

public abstract class XmlDomainVo extends DomainVo implements IXmlDomainVo {
	private String xmlText;

	public String getXmlText() {
		return this.xmlText;
	}

	public void setXmlText(String xmlString) {
		this.xmlText = xmlString;
	}

	public String getSerializedXmlText() throws FusionXmlBeanCreationException {
		XmlObject xmlBeanInstance = (XmlObject) FusionXmlBeanFactory.getEmptyXmlBeanInstance(this);
		this.performObjectMapping(this, xmlBeanInstance);
		return xmlBeanInstance.xmlText();
	}

	public void serializeIntoXmlText() throws FusionXmlBeanCreationException {
		this.setXmlText(this.getSerializedXmlText());
	}

	public void deserializeVOFromXmlText() throws FusionXmlBeanCreationException {
		XmlObject xmlBeanInstance = (XmlObject) FusionXmlBeanFactory.getLoadedXmlBeanInstance(this);
		this.performObjectMapping(xmlBeanInstance, this);
	}

	protected void performObjectMapping(Object source, Object destination) {
		AppUtils.getDomainObjectToXmlBeanMapper().map(source, destination);
	}

	public abstract Class getXmlBeanClass();
}