package com.att.fusion.domain;

import java.util.Set;
import java.util.TreeSet;

public class MenuData extends Menu {
	private MenuData parentMenu;
	private Set childMenus = new TreeSet();

	public Set getChildMenus() {
		return this.childMenus;
	}

	public MenuData getParentMenu() {
		return this.parentMenu;
	}

	public void setChildMenus(Set childMenus) {
		this.childMenus = childMenus;
	}

	public void setParentMenu(MenuData parentMenu) {
		this.parentMenu = parentMenu;
	}
}