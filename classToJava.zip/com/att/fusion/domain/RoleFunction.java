package com.att.fusion.domain;

import com.att.fusion.domain.support.DomainVo;

public class RoleFunction extends DomainVo {
	private String code;
	private String name;

	public String getName() {
		return this.name;
	}

	public String getCode() {
		return this.code;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public int compareTo(Object obj) {
		String c1 = this.getName();
		String c2 = ((RoleFunction) obj).getName();
		return c1 != null && c2 != null ? c1.compareTo(c2) : 1;
	}
}