package com.att.fusion.domain.hibernate;

import com.mchange.v2.c3p0.C3P0ProxyConnection;
import com.mchange.v2.c3p0.impl.NewProxyResultSet;
import java.io.Serializable;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import oracle.jdbc.OracleConnection;
import oracle.jdbc.OracleResultSet;
import oracle.sql.OPAQUE;
import oracle.xdb.XMLType;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.usertype.UserType;
import org.springframework.jdbc.support.nativejdbc.C3P0NativeJdbcExtractor;

public class FusionXMLType implements UserType, Serializable {
	private static String NATIVE_XML_TYPE_NAME = "SYS.XMLTYPE";
	private static final int[] SqlTypes = new int[]{2007};
	protected final Log logger = LogFactory.getLog(this.getClass());

	public Object assemble(Serializable cachedAttribute, Object owner) throws HibernateException {
		return null;
	}

	public Object deepCopy(Object attribute) throws HibernateException {
		return null;
	}

	public Serializable disassemble(Object attribute) throws HibernateException {
		return null;
	}

	public boolean equals(Object attribute1, Object attribute2) throws HibernateException {
		return attribute1 == attribute2 || attribute1 != null && attribute2 != null && attribute1.equals(attribute2);
	}

	public int hashCode(Object arg0) throws HibernateException {
		return arg0.hashCode();
	}

	public boolean isMutable() {
		return false;
	}

	public Object nullSafeGet(ResultSet rs, String[] names, Object owner) throws HibernateException, SQLException {
		XMLType xmlType = null;
		String xmlTypeAsString = "";

		try {
			if (rs instanceof OracleResultSet) {
				OracleResultSet oracleRs = (OracleResultSet) rs;
				OPAQUE opaqueValue = oracleRs.getOPAQUE(names[0]);
				if (opaqueValue != null) {
					xmlType = XMLType.createXML(opaqueValue);
					xmlTypeAsString = xmlType.getStringVal();
				}
			} else {
				if (!(rs instanceof NewProxyResultSet)) {
					throw new HibernateException(
							"JDBC driver in use does not support oracle XMLType handling" + rs.getClass());
				}

				C3P0NativeJdbcExtractor nativeJdbcExtractor = new C3P0NativeJdbcExtractor();
				NewProxyResultSet prs = (NewProxyResultSet) rs;
				ResultSet nativeRs = nativeJdbcExtractor.getNativeResultSet(rs);
				if (nativeRs instanceof oracle.jdbc.driver.OracleResultSet) {
					oracle.jdbc.driver.OracleResultSet oracleRs = (oracle.jdbc.driver.OracleResultSet) nativeJdbcExtractor
							.getNativeResultSet(rs);
					OPAQUE opaqueValue = oracleRs.getOPAQUE(names[0]);
					if (opaqueValue != null) {
						xmlType = XMLType.createXML(opaqueValue);
						xmlTypeAsString = xmlType.getStringVal();
					}
				} else {
					xmlType = (XMLType) rs.getObject(names[0]);
					if (xmlType != null) {
						xmlTypeAsString = xmlType.getStringVal();
					}
				}
			}
		} finally {
			if (xmlType != null) {
				xmlType.close();
			}

		}

		return xmlTypeAsString;
	}

	public void nullSafeSet(PreparedStatement st, Object value, int index) throws HibernateException, SQLException {
		XMLType xmlType = null;
		OracleConnection con = null;

		try {
			if (value != null) {
				if (st.getConnection() instanceof C3P0ProxyConnection) {
					C3P0NativeJdbcExtractor nativeExtractor = new C3P0NativeJdbcExtractor();
					con = (OracleConnection) nativeExtractor.getNativeConnectionFromStatement(st);
				} else if (st.getConnection() instanceof OracleConnection) {
					con = (OracleConnection) st.getConnection();
				}

				xmlType = XMLType.createXML(con, (String) value);
				st.setObject(index, xmlType);
				return;
			}

			st.setNull(index, 2007, NATIVE_XML_TYPE_NAME);
		} finally {
			if (xmlType != null) {
				xmlType.close();
			}

		}

	}

	public Object replace(Object original, Object target, Object owner) throws HibernateException {
		return null;
	}

	public Class returnedClass() {
		return null;
	}

	public int[] sqlTypes() {
		return SqlTypes;
	}
}