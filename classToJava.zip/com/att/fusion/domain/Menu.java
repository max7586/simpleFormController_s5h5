package com.att.fusion.domain;

import com.att.fusion.domain.support.DomainVo;

public class Menu extends DomainVo {
	private String menuLevel;
	private String label;
	private Long parentId;
	private String action;
	private String functionCd;
	private String sortOrder;
	private String servlet;
	private String queryString;
	private String externalUrl;
	private String target;
	private boolean active;

	public String getAction() {
		return this.action;
	}

	public boolean isActive() {
		return this.active;
	}

	public String getExternalUrl() {
		return this.externalUrl;
	}

	public String getFunctionCd() {
		return this.functionCd;
	}

	public String getLabel() {
		return this.label;
	}

	public String getMenuLevel() {
		return this.menuLevel;
	}

	public Long getParentId() {
		return this.parentId;
	}

	public String getQueryString() {
		return this.queryString;
	}

	public String getServlet() {
		return this.servlet;
	}

	public String getSortOrder() {
		return this.sortOrder;
	}

	public String getTarget() {
		return this.target;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setExternalUrl(String externalUrl) {
		this.externalUrl = externalUrl;
	}

	public void setFunctionCd(String functionCd) {
		this.functionCd = functionCd;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public void setMenuLevel(String menuLevel) {
		this.menuLevel = menuLevel;
	}

	public void setParentId(Long parentId) {
		this.parentId = parentId;
	}

	public void setQueryString(String queryString) {
		this.queryString = queryString;
	}

	public void setServlet(String servlet) {
		this.servlet = servlet;
	}

	public void setSortOrder(String sortOrder) {
		this.sortOrder = sortOrder;
	}

	public void setTarget(String target) {
		this.target = target;
	}
}