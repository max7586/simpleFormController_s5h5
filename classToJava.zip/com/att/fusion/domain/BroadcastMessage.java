package com.att.fusion.domain;

import com.att.fusion.domain.support.DomainVo;
import java.util.Date;

public class BroadcastMessage extends DomainVo {
	public static final String ID_MESSAGE_LOCATION_LOGIN = "10";
	public static final String ID_MESSAGE_LOCATION_WELCOME = "20";
	private String messageText;
	private Integer locationId;
	private Date startDate;
	private Date endDate;
	private Integer sortOrder;
	private Boolean active;
	private String siteCd;

	public Boolean getActive() {
		return this.active;
	}

	public Date getEndDate() {
		return this.endDate;
	}

	public Integer getLocationId() {
		return this.locationId;
	}

	public String getMessageText() {
		return this.messageText;
	}

	public Integer getSortOrder() {
		return this.sortOrder;
	}

	public Date getStartDate() {
		return this.startDate;
	}

	public String getSiteCd() {
		return this.siteCd;
	}

	public void setActive(Boolean active) {
		this.active = active;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public void setLocationId(Integer locationId) {
		this.locationId = locationId;
	}

	public void setMessageText(String messageText) {
		this.messageText = messageText;
	}

	public void setSortOrder(Integer sortOrder) {
		this.sortOrder = sortOrder;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public void setSiteCd(String siteCd) {
		this.siteCd = siteCd;
	}

	public int compareTo(Object obj) {
		Integer c1 = this.getLocationId();
		Integer c2 = ((BroadcastMessage) obj).getLocationId();
		if (c1.compareTo(c2) == 0) {
			c1 = this.getSortOrder();
			c2 = ((BroadcastMessage) obj).getSortOrder();
			if (c1.compareTo(c2) == 0) {
				Long c3 = this.getId();
				Long c4 = ((BroadcastMessage) obj).getId();
				return c3.compareTo(c4);
			}
		}

		return c1.compareTo(c2);
	}
}