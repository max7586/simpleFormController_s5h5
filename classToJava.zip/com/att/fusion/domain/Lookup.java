package com.att.fusion.domain;

import com.att.fusion.domain.support.FusionVo;
import com.att.fusion.domain.support.NameValueId;
import java.io.Serializable;

public class Lookup extends FusionVo implements Serializable {
	private NameValueId nameValueId;

	public Lookup() {
		this.nameValueId = new NameValueId();
	}

	public Lookup(String label, String value) {
		this();
		this.setLabel(label);
		this.setValue(value);
	}

	public String getValue() {
		return this.getNameValueId().getValue();
	}

	public String getLabel() {
		return this.getNameValueId().getLabel();
	}

	public void setValue(String value) {
		this.getNameValueId().setValue(value);
	}

	public void setLabel(String label) {
		this.getNameValueId().setLabel(label);
	}

	public NameValueId getNameValueId() {
		return this.nameValueId;
	}

	public void setNameValueId(NameValueId nameValueId) {
		this.nameValueId = nameValueId;
	}
}