package com.att.fusion.validator;

import com.att.fusion.domain.User;
import com.att.fusion.domain.support.DomainVo;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.validator.support.FusionValidator;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FeedbackMessage;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.Errors;

public class ProfileValidator extends FusionValidator {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public boolean supports(Class givenClass) {
		return givenClass.equals(DomainVo.class) || givenClass.equals(User.class);
	}

	public void validate(Object obj, Errors errors) {
		User bean = (User) obj;
		String auditUserId = (String) bean.getAuditUserId();
		if (bean == null) {
			errors.reject("error.nullcommand", "Null data received");
			if (auditUserId != null) {
				AppUtils.addFeedback(auditUserId, new FeedbackMessage("error.nullcommand", 10, true));
			}
		} else {
			this.logger.info("Validating profile form");
			this.logger.info("Validating all required fields have been entered.");
			if (bean.getFirstName() == null || bean.getFirstName().length() < 1) {
				errors.rejectValue("firstName", "profile.error.firstName.empty",
						SystemProperties.getProperty("default_error_message"));
				if (auditUserId != null) {
					AppUtils.addFeedback(auditUserId, new FeedbackMessage("profile.error.firstName.empty", 20, true));
				}
			}

			if (bean.getLastName() == null || bean.getLastName().length() < 1) {
				errors.rejectValue("lastName", "profile.error.lastName.empty",
						SystemProperties.getProperty("default_error_message"));
				if (auditUserId != null) {
					AppUtils.addFeedback(auditUserId, new FeedbackMessage("profile.error.lastName.empty", 20, true));
				}
			}

			if (bean.getPhone() == null || bean.getPhone().length() < 1) {
				errors.rejectValue("phone", "profile.error.phone.empty",
						SystemProperties.getProperty("default_error_message"));
				if (auditUserId != null) {
					AppUtils.addFeedback(auditUserId, new FeedbackMessage("profile.error.phone.empty", 20, true));
				}
			}

			if (bean.getEmail() == null || bean.getEmail().length() < 1) {
				errors.rejectValue("email", "profile.error.email.empty",
						SystemProperties.getProperty("default_error_message"));
				if (auditUserId != null) {
					AppUtils.addFeedback(auditUserId, new FeedbackMessage("profile.error.email.empty", 20, true));
				}
			}
		}

	}
}