package com.att.fusion.validator;

import com.att.fusion.command.LoginBean;
import com.att.fusion.validator.support.FusionValidator;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.Errors;

public class LoginValidator extends FusionValidator {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public boolean supports(Class givenClass) {
		return givenClass.equals(LoginBean.class);
	}

	public void validate(Object obj, Errors errors) {
		LoginBean commandBean = (LoginBean) obj;
		if (commandBean == null) {
			errors.reject("error.nullcommand", "Null data received");
		} else {
			this.logger.info("Validating form");
			if (commandBean.getLoginId() == null || commandBean.getLoginId().length() < 1) {
				errors.rejectValue("loginId", "login.error.loginid.empty");
			}

			if (commandBean.getLoginPwd() == null || commandBean.getLoginPwd().length() < 1) {
				errors.rejectValue("loginPwd", "login.error.password.empty");
			}
		}

	}
}