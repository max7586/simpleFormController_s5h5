package com.att.fusion.validator.support;

import com.att.fusion.FusionObject;
import org.springframework.validation.Validator;

public abstract class FusionValidator implements FusionObject, Validator {
}