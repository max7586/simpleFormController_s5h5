package com.att.fusion.command.support;

import com.att.fusion.FusionObject.Utilities;
import java.util.List;

public abstract class SearchBase extends FusionCommand {
	public static String SORT_BY_MODIFIER_DESC = "D";
	public static String SORT_BY_MODIFIER_ASC = "A";
	public static String SORT_BY_MODIFIER_DESC_IMAGE_NAME = "sort_desc.gif";
	public static String SORT_BY_MODIFIER_ASC_IMAGE_NAME = "sort_asc.gif";
	private String sortBy1 = null;
	private String sortBy2 = null;
	private String sortBy3 = null;
	private String sortBy1Orig = null;
	private String sortBy2Orig = null;
	private String sortBy3Orig = null;
	private String sortByModifier1 = null;
	private String sortByModifier2 = null;
	private String sortByModifier3 = null;
	private String sortByModifier1Orig = null;
	private String sortByModifier2Orig = null;
	private String sortByModifier3Orig = null;
	private String accessType = "WRITE";
	private String submitAction = "";
	private String masterId = "";
	private String detailId = "";
	private String showResult = "Y";
	private SearchResult searchResult = null;
	private boolean sortingUpdated;

	public SearchBase(List items) {
		this.searchResult = items == null ? new SearchResult() : new SearchResult(items);
	}

	public String getSortBy1() {
		return this.sortBy1;
	}

	public String getSortBy2() {
		return this.sortBy2;
	}

	public String getSortBy3() {
		return this.sortBy3;
	}

	public String getSortBy1Orig() {
		return this.sortBy1;
	}

	public String getSortBy2Orig() {
		return this.sortBy2;
	}

	public String getSortBy3Orig() {
		return this.sortBy3;
	}

	public String getAccessType() {
		return this.accessType;
	}

	public String getSubmitAction() {
		return this.submitAction;
	}

	public String getMasterId() {
		return this.masterId;
	}

	public String getDetailId() {
		return this.detailId;
	}

	public String getShowResult() {
		return this.showResult;
	}

	public SearchResult getSearchResult() {
		return this.searchResult;
	}

	public String getSortByModifier1() {
		return this.sortByModifier1;
	}

	public String getSortByModifier1Orig() {
		return this.sortByModifier1;
	}

	public String getSortByModifier2() {
		return this.sortByModifier2;
	}

	public String getSortByModifier2Orig() {
		return this.sortByModifier2;
	}

	public String getSortByModifier3() {
		return this.sortByModifier3;
	}

	public String getSortByModifier3Orig() {
		return this.sortByModifier3;
	}

	public int getPageNo() {
		return !this.isCriteriaUpdated() && !this.isSortingUpdated() ? this.getSearchResult().getPageNo() : 0;
	}

	public int getPageSize() {
		return this.getSearchResult().getPageSize();
	}

	public int getDataSize() {
		return this.getSearchResult().getDataSize();
	}

	public int getNewDataSize() {
		return this.isCriteriaUpdated() ? -1 : this.getDataSize();
	}

	public void setSortBy1(String sortBy1) {
		this.sortBy1 = sortBy1;
	}

	public void setSortBy2(String sortBy2) {
		this.sortBy2 = sortBy2;
	}

	public void setSortBy3(String sortBy3) {
		this.sortBy3 = sortBy3;
	}

	public void setSortBy1Orig(String sortBy1Orig) {
		this.sortBy1Orig = sortBy1Orig;
	}

	public void setSortBy2Orig(String sortBy2Orig) {
		this.sortBy2Orig = sortBy2Orig;
	}

	public void setSortBy3Orig(String sortBy3Orig) {
		this.sortBy3Orig = sortBy3Orig;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}

	public void setSubmitAction(String submitAction) {
		this.submitAction = submitAction;
	}

	public void setMasterId(String masterId) {
		this.masterId = masterId;
	}

	public void setDetailId(String detailId) {
		this.detailId = detailId;
	}

	public void setShowResult(String showResult) {
		this.showResult = showResult;
	}

	public void setSearchResult(SearchResult searchResult) {
		this.searchResult = searchResult;
	}

	public void setSortByModifier1(String sortByModifier1) {
		this.sortByModifier1 = sortByModifier1;
	}

	public void setSortByModifier1Orig(String sortByModifier1Orig) {
		this.sortByModifier1Orig = sortByModifier1Orig;
	}

	public void setSortByModifier2(String sortByModifier2) {
		this.sortByModifier2 = sortByModifier2;
	}

	public void setSortByModifier2Orig(String sortByModifier2Orig) {
		this.sortByModifier2Orig = sortByModifier2Orig;
	}

	public void setSortByModifier3(String sortByModifier3) {
		this.sortByModifier3 = sortByModifier3;
	}

	public void setSortByModifier3Orig(String sortByModifier3Orig) {
		this.sortByModifier3Orig = sortByModifier3Orig;
	}

	public void setSortingUpdated(boolean sortingUpdated) {
		this.sortingUpdated = sortingUpdated;
	}

	public void setPageNo(int pageNo) {
		this.getSearchResult().setPageNo(pageNo);
	}

	public void setPageSize(int pageSize) {
		this.getSearchResult().setPageSize(pageSize);
	}

	public void setDataSize(int dataSize) {
		this.getSearchResult().setDataSize(dataSize);
	}

	public void resetSearch() {
		this.setSortBy1((String) null);
		this.setSortBy2((String) null);
		this.setSortBy3((String) null);
		this.setSortByModifier1(SORT_BY_MODIFIER_ASC);
		this.setSortByModifier2(SORT_BY_MODIFIER_ASC);
		this.setSortByModifier3(SORT_BY_MODIFIER_ASC);
		this.setPageNo(0);
		this.setDataSize(-1);
	}

	public abstract boolean isCriteriaUpdated();

	public boolean isSortingUpdated() {
		return !Utilities.nvl(this.sortBy1).equals(Utilities.nvl(this.sortBy1Orig))
				|| !Utilities.nvl(this.sortBy2).equals(Utilities.nvl(this.sortBy2Orig))
				|| !Utilities.nvl(this.sortBy3).equals(Utilities.nvl(this.sortBy3Orig))
				|| !Utilities.nvl(this.sortByModifier1).equals(Utilities.nvl(this.sortByModifier1Orig))
				|| !Utilities.nvl(this.sortByModifier2).equals(Utilities.nvl(this.sortByModifier2Orig))
				|| !Utilities.nvl(this.sortByModifier3).equals(Utilities.nvl(this.sortByModifier3Orig));
	}
}