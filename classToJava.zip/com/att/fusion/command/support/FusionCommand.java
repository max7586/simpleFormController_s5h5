package com.att.fusion.command.support;

import com.att.fusion.FusionObject;

public class FusionCommand implements FusionObject {
	private String task;

	public String getTask() {
		return this.task;
	}

	public void setTask(String task) {
		this.task = task;
	}
}