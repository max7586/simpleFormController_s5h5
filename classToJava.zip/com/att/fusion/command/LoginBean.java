package com.att.fusion.command;

import com.att.fusion.command.support.FusionCommand;
import com.att.fusion.domain.User;
import com.att.fusion.menu.MenuConfigData;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LoginBean extends FusionCommand {
	private String loginId;
	private String loginPwd;
	private String hrid;
	private String attuid;
	private String siteAccess;
	private String loginErrorMessage;
	private User user;
	private MenuConfigData menu;
	private MenuConfigData businessDirectMenu;
	protected final Log logger = LogFactory.getLog(this.getClass());

	public String getLoginId() {
		return this.loginId;
	}

	public String getLoginPwd() {
		return this.loginPwd;
	}

	public MenuConfigData getMenu() {
		return this.menu;
	}

	public User getUser() {
		return this.user;
	}

	public String getHrid() {
		return this.hrid;
	}

	public String getSiteAccess() {
		return this.siteAccess;
	}

	public MenuConfigData getBusinessDirectMenu() {
		return this.businessDirectMenu;
	}

	public String getLoginErrorMessage() {
		return this.loginErrorMessage;
	}

	public String getAttuid() {
		return this.attuid;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}

	public void setMenu(MenuConfigData menu) {
		this.menu = menu;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public void setHrid(String hrid) {
		this.hrid = hrid;
	}

	public void setSiteAccess(String siteAccess) {
		this.siteAccess = siteAccess;
	}

	public void setBusinessDirectMenu(MenuConfigData businessDirectMenu) {
		this.businessDirectMenu = businessDirectMenu;
	}

	public void setLoginErrorMessage(String loginErrorMessage) {
		this.loginErrorMessage = loginErrorMessage;
	}

	public void setAttuid(String attuid) {
		this.attuid = attuid;
	}
}