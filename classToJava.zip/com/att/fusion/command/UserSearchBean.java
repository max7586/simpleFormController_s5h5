package com.att.fusion.command;

import com.att.fusion.FusionObject.Utilities;
import com.att.fusion.command.support.SearchBase;
import com.att.fusion.domain.User;
import java.util.List;

public class UserSearchBean extends SearchBase {
	private User user;
	private User userOrig;

	public UserSearchBean() {
		this((List) null);
	}

	public UserSearchBean(List items) {
		super(items);
		this.user = null;
		this.userOrig = null;
		this.user = new User();
		this.userOrig = new User();
		this.setSortBy1("lastName");
		this.setSortBy1Orig("");
		this.setSortByModifier1(SearchBase.SORT_BY_MODIFIER_ASC);
		this.setSortByModifier1Orig("");
		this.setSortByModifier2(SearchBase.SORT_BY_MODIFIER_ASC);
		this.setSortByModifier2Orig("");
		this.setSortByModifier3(SearchBase.SORT_BY_MODIFIER_ASC);
		this.setSortByModifier3Orig("");
	}

	public String getFirstName() {
		return this.user.getFirstName();
	}

	public String getLastName() {
		return this.user.getLastName();
	}

	public String getHrid() {
		return this.user.getHrid();
	}

	public String getEmail() {
		return this.user.getEmail();
	}

	public String getFirstNameOrig() {
		return this.user.getFirstName();
	}

	public String getLastNameOrig() {
		return this.user.getLastName();
	}

	public String getHridOrig() {
		return this.user.getHrid();
	}

	public String getEmailOrig() {
		return this.user.getEmail();
	}

	public User getUser() {
		return this.user;
	}

	public void setFirstName(String value) {
		this.user.setFirstName(value);
	}

	public void setLastName(String value) {
		this.user.setLastName(value);
	}

	public void setHrid(String value) {
		this.user.setHrid(value);
	}

	public void setEmail(String value) {
		this.user.setEmail(value);
	}

	public void setFirstNameOrig(String value) {
		this.userOrig.setFirstName(value);
	}

	public void ssetLastNameOrig(String value) {
		this.userOrig.setLastName(value);
	}

	public void setHridOrig(String value) {
		this.userOrig.setHrid(value);
	}

	public void setEmailOrig(String value) {
		this.userOrig.setEmail(value);
	}

	public void setUser(User value) {
		this.user = value;
	}

	public void resetSearch() {
		super.resetSearch();
		this.setUser(new User());
	}

	public boolean isCriteriaUpdated() {
		if (this.user == null && this.userOrig == null) {
			return false;
		} else if (this.user != null && this.userOrig != null) {
			return !Utilities.nvl(this.user.getFirstName()).equals(Utilities.nvl(this.userOrig.getFirstName()))
					|| !Utilities.nvl(this.user.getLastName()).equals(Utilities.nvl(this.userOrig.getLastName()))
					|| !Utilities.nvl(this.user.getHrid()).equals(Utilities.nvl(this.userOrig.getHrid()))
					|| !Utilities.nvl(this.user.getEmail()).equals(Utilities.nvl(this.userOrig.getEmail()));
		} else {
			return true;
		}
	}
}