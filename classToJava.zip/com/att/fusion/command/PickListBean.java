package com.att.fusion.command;

import com.att.fusion.command.support.FusionCommand;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class PickListBean extends FusionCommand {
	private long parentId;
	private String parentName;
	private String[] selected;
	protected final Log logger = LogFactory.getLog(this.getClass());

	public long getParentId() {
		return this.parentId;
	}

	public String[] getSelected() {
		return this.selected;
	}

	public String getParentName() {
		return this.parentName;
	}

	public void setParentId(long parentId) {
		this.parentId = parentId;
	}

	public void setSelected(String[] selected) {
		this.selected = selected;
	}

	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
}