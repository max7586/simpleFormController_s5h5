package com.att.fusion.util;

import java.util.Iterator;
import java.util.TreeMap;

public class WordList {
	private TreeMap words;
	private int numWords;
	public static final int COMPARE_STRICT = 0;
	public static final int COMPARE_IGNORE_CASE = 1;

	public WordList() {
		this.words = new TreeMap();
		this.numWords = 0;
	}

	public WordList(String text) {
		this(text, " ");
	}

	public WordList(String text, String delimeter) {
		this(text, " ", 1);
	}

	public WordList(String text, String delimeter, int comparisonLevel) {
		this();
		text = this.removeNonWordCharacters(text);
		String[] list = text.split(delimeter);
		if (list != null) {
			this.numWords = list.length;
		}

		for (int i = 0; i < list.length; ++i) {
			String word = list[i];
			if (comparisonLevel == 1) {
				word = word.toLowerCase();
			}

			Integer count = (Integer) this.words.get(word);
			Integer newCount = new Integer(0);
			if (count == null) {
				count = newCount;
			}

			int c = count;
			++c;
			count = new Integer(c);
			this.words.put(word, count);
		}

	}

	public double equivalence(WordList list) {
		double equivalence = 0.0D;
		double totalMatches = 0.0D;
		double maxNumWords = 0.0D;
		TreeMap otherWords = list.getWords();
		Iterator i = this.getWords().keySet().iterator();
		if (this.getNumWords() > list.getNumWords()) {
			maxNumWords = (double) this.getNumWords();
		} else {
			maxNumWords = (double) list.getNumWords();
		}

		if (maxNumWords > 0.0D) {
			while (i.hasNext()) {
				int count = false;
				int otherCount = 0;
				String word = (String) i.next();
				int count = (Integer) this.getWords().get(word);
				if (otherWords.get(word) != null) {
					otherCount = (Integer) otherWords.get(word);
				}

				if (otherCount > 0) {
					if (otherCount == count) {
						totalMatches += (double) count;
					} else {
						totalMatches += (double) Math.abs(count - otherCount);
					}
				}
			}

			equivalence = totalMatches / maxNumWords;
		}

		return equivalence;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();
		Iterator i = this.words.keySet().iterator();

		while (i.hasNext()) {
			String word = (String) i.next();
			Integer count = (Integer) this.words.get(word);
			sb.append(word).append("\t").append("-").append("\t").append(count).append("\n");
		}

		return sb.toString();
	}

	public int getNumWords() {
		return this.numWords;
	}

	public TreeMap getWords() {
		return this.words;
	}

	public void setNumWords(int numWords) {
		this.numWords = numWords;
	}

	public void setWords(TreeMap words) {
		this.words = words;
	}

	private String removeNonWordCharacters(String text) {
		text = text.replaceAll("\\W&&[^ ]", "");
		text = text.replaceAll("[!\"#$%&'()*+,-./:;<=>?@^_`{|}~]", "");
		return text;
	}
}