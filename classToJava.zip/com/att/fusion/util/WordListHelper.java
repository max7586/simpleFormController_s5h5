package com.att.fusion.util;

public class WordListHelper {
	public static double equivalence(String list, String otherList) {
		WordList w1 = new WordList(list);
		WordList w2 = new WordList(otherList);
		return w1.equivalence(w2);
	}
}