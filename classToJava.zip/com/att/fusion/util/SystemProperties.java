package com.att.fusion.util;

import java.io.IOException;
import java.util.Properties;
import javax.servlet.ServletContext;

public class SystemProperties {
	private ServletContext servletContext;
	private static Properties systemProperties = null;
	private static Properties successTasks = null;
	public static final String DOMAIN_CLASS_LOCATION = "domain_class_location";
	public static final String DEFAULT_ERROR_MESSAGE = "default_error_message";
	public static final String CSP_COOKIE_NAME = "csp_cookie_name";
	public static final String CSP_GATE_KEEPER_DATA_KEY = "csp_gate_keeper_data_key";
	public static final String CSP_GATE_KEEPER_PROD_KEY = "csp_gate_keeper_prod_key";
	public static final String CSP_LOGIN_URL = "csp_login_url";
	public static final String CSP_LOGOUT_URL = "csp_logout_url";
	public static final String WEB_JUNCTION_USER_ID_HEADER_NAME = "web_junction_user_id_header_name";
	public static final String WEB_JUNCTION_LOGOUT_URL = "web_junction_logout_url";
	public static final String APPLICATION_NAME = "application_name";
	public static final String HIBERNATE_CONFIG_FILE_PATH = "hibernate_config_file_path";
	public static final String APPLICATION_USER_ID = "application_user_id";
	public static final String POST_INITIAL_CONTEXT_FACTORY = "post_initial_context_factory";
	public static final String POST_PROVIDER_URL = "post_provider_url";
	public static final String POST_SECURITY_PRINCIPAL = "post_security_principal";
	public static final String POST_MAX_RESULT_SIZE = "post_max_result_size";
	public static final String POST_DEFAULT_ROLE_ID = "post_default_role_id";
	public static final String FILES_PATH = "files_path";
	public static final String TEMP_PATH = "temp_path";
	public static final String NUM_UPLOAD_FILES = "num_upload_files";
	public static final String SYS_ADMIN_ROLE_ID = "sys_admin_role_id";
	public static final String SYS_ADMIN_ROLE_FUNCTION_DELETE_FROM_UI = "sys_admin_role_function_delete_from_ui";
	public static final String MENU_PROPERTIES_FILE_LOCATION = "menu_properties_file_location";
	public static final String MENU_QUERY_NAME = "menu_query_name";
	public static final String APPLICATION_MENU_SET_NAME = "application_menu_set_name";
	public static final String APPLICATION_MENU_ATTRIBUTE_NAME = "application_menu_attribute_name";
	public static final String APPLICATION_MENU_PROPERTIES_NAME = "application_menu_properties_name";
	public static final String BUSINESS_DIRECT_MENU_SET_NAME = "business_direct_menu_set_name";
	public static final String BUSINESS_DIRECT_MENU_ATTRIBUTE_NAME = "business_direct_menu_attribute_name";
	public static final String BUSINESS_DIRECT_MENU_PROPERTIES_NAME = "business_direct_menu_properties_name";
	public static final String RAPTOR_CONFIG_FILE_PATH = "raptor_config_file_path";
	public static final String HOMEPAGE_DATA_CALLBACK_CLASS = "homepage_data_callback_class";
	public static final String ERROR_EMAIL_DISTRIBUTION = "error_email_distribution";
	public static final String ERROR_EMAIL_SOURCE_ADDRESS = "error_email_source_address";
	public static final String PROFILE_SEARCH_REPORT_ID = "profile_search_report_id";
	public static final String CALLABLE_PROFILE_SEARCH_REPORT_ID = "callable_profile_search_report_id";
	public static final String CLUSTERED = "clustered";
	public static final String USER_ATTRIBUTE_NAME = "user_attribute_name";
	public static final String ROLES_ATTRIBUTE_NAME = "roles_attribute_name";
	public static final String ROLE_FUNCTIONS_ATTRIBUTE_NAME = "role_functions_attribute_name";
	public static final String DOCLIB_ADMIN_ROLE_ID = "doclib_admin_role_id";
	public static final String DOCLIB_USER_ROLE_ID = "doclib_user_role_id";
	public static final String SYSTEM_PROPERTIES_FILENAME = "system.properties";
	public static final String FUSION_PROPERTIES_FILENAME = "fusion.properties";
	public static final String SUCCESS_TASKS_PROPERTIES_FILENAME = "success_tasks.properties";
	public static final String LOGIN_METHOD_CSP = "login_method_csp";
	public static final String LOGIN_METHOD_WEB_JUNCTION = "login_method_web_junction";
	public static final String LOGIN_METHOD_BACKDOOR = "login_method_backdoor";
	public static final String LOGIN_METHOD_ATTRIBUTE_NAME = "login_method_attribute_name";
	public static final String MESSAGE_KEY_LOGIN_ERROR_COOKIE_EMPTY = "login.error.hrid.empty";
	public static final String MESSAGE_KEY_LOGIN_ERROR_HEADER_EMPTY = "login.error.header.empty";
	public static final String MESSAGE_KEY_LOGIN_ERROR_USER_INACTIVE = "login.error.user.inactive";
	public static final String MESSAGE_KEY_LOGIN_ERROR_USER_NOT_FOUND = "login.error.hrid.not-found";
	public static final String MESSAGE_KEY_LOGIN_ERROR_APPLICATION_LOCKED = "login.error.application.locked";

	public void load() throws IOException {
		Properties p = new Properties();
		p.load(this.getServletContext().getResourceAsStream("/WEB-INF/conf/system.properties"));
		p.load(this.getServletContext().getResourceAsStream("/WEB-INF/fusion/conf/fusion.properties"));
		systemProperties = p;
		p = new Properties();
		p.load(this.getServletContext().getResourceAsStream("/WEB-INF/conf/success_tasks.properties"));
		successTasks = p;
	}

	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public ServletContext getServletContext() {
		return this.servletContext;
	}

	public static Properties getSuccessTasks() {
		return successTasks;
	}

	public static String getProperty(String key) {
		return systemProperties.getProperty(key);
	}

	public String getApplicationName() {
		return getProperty("application_name");
	}
}