package com.att.fusion.util.adapter;

import att.raptor.config.ConfigLoader;
import att.raptor.system.Globals;
import com.att.fusion.domain.Menu;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.util.adapter.support.FusionAdapter;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.UserUtils;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;

public class RaptorAdapter extends FusionAdapter {
	public static final int RAPTOR_USER_ID = 20000;
	public static final String RAPTOR_CONTROLLER_CLASSNAME = "att.raptor.controller.Controller";

	public void initializeRaptor() {
		ConfigLoader.setConfigFilesPath(SystemProperties.getProperty("raptor_config_file_path"));
		Globals.initializeSystem(this.getServletContext());
	}

	public static String getUserID(HttpServletRequest request) {
		return String.valueOf(UserUtils.getUserId(request));
	}

	public static String getUserName(String userId) {
		Map params = new HashMap();
		params.put("user_id", new Long(userId));
		List list = getQueryService().executeNamedQuery("getUserNameById", params);
		String firstName = "";
		String lastName = "";
		if (list != null && !list.isEmpty()) {
			Object[] user = (Object[]) ((Object[]) list.get(0));
			firstName = (String) user[0];
			lastName = (String) user[1];
		}

		return lastName + ", " + firstName;
	}

	public static String getUserEmail(String userId) {
		Map params = new HashMap();
		params.put("user_id", new Long(userId));
		List list = getQueryService().executeNamedQuery("getUserEmail", params);
		String email = "";
		if (list != null && !list.isEmpty()) {
			email = (String) list.get(0);
		}

		return email;
	}

	public static Map getAllUsers() {
		List users = getQueryService().executeNamedQuery("getAllUsers");
		Map map = new LinkedHashMap();
		if (users != null) {
			Iterator i = users.iterator();

			while (i.hasNext()) {
				Object[] user = (Object[]) ((Object[]) i.next());
				Long id = (Long) user[0];
				String firstName = (String) user[1];
				String lastName = (String) user[2];
				map.put(id, lastName + ", " + firstName);
			}
		}

		return map;
	}

	public static String getRoleName(String roleId) {
		Map params = new HashMap();
		params.put("role_id", new Long(roleId));
		List list = getQueryService().executeNamedQuery("getRoleNameById", params);
		String roleName = "";
		if (list != null && !list.isEmpty()) {
			roleName = (String) list.get(0);
		}

		return roleName;
	}

	public static Map getAllRoles() {
		List roles = getQueryService().executeNamedQuery("getAllRoles");
		Map map = new LinkedHashMap();
		if (roles != null) {
			Iterator i = roles.iterator();

			while (i.hasNext()) {
				Object[] user = (Object[]) ((Object[]) i.next());
				Long id = (Long) user[0];
				String roleName = (String) user[1];
				map.put(id, roleName);
			}
		}

		return map;
	}

	public static Map getAllRoles(String userId) {
		Map params = new HashMap();
		params.put("user_id", new Long(userId));
		List roles = getQueryService().executeNamedQuery("getUserRolesById", params);
		Map map = new LinkedHashMap();
		if (roles != null) {
			Iterator i = roles.iterator();

			while (i.hasNext()) {
				Object[] role = (Object[]) ((Object[]) i.next());
				Long id = (Long) role[0];
				String roleName = (String) role[1];
				map.put(id, roleName);
			}
		}

		return map;
	}

	public static boolean isUserInRole(String userId, String roleId) {
		return getAllRoles(userId).containsKey(new Long(roleId));
	}

	public static void processErrorNotification(HttpServletRequest request, Exception e) {
		AppUtils.processError(e, logger, request);
	}

	public static String getMenuLabel(String menuId) {
		return ((Menu) getDomainService().getDomainObject(Menu.class, new Long(menuId))).getLabel();
	}
}