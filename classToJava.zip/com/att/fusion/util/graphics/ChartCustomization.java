package com.att.fusion.util.graphics;

import org.jfree.chart.JFreeChart;

public abstract class ChartCustomization {
	public abstract JFreeChart modify(JFreeChart var1);
}