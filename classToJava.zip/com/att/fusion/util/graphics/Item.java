package com.att.fusion.util.graphics;

public class Item {
	private String name;
	private double number;

	public Item(String name, double number) {
		this.name = name;
		this.number = number;
	}

	public void setNumber(double number) {
		this.number = number;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}

	public double getNumber() {
		return this.number;
	}
}