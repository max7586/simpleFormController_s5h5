package com.att.fusion.util;

import com.att.fusion.exception.SessionExpiredException;
import com.att.fusion.web.support.UserUtils;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.URLEncoder;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.util.StringUtils;

public class DownloadServlet extends HttpServlet {
	public static final String FILES_PATH_CD = "F";
	public static final String TEMP_PATH_CD = "T";

	public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
		String folder;
		try {
			boolean isExternal = request.getParameter("external") != null;
			if (UserUtils.getUserSession(request) != null || isExternal) {
				folder = request.getParameter("folder") != null ? request.getParameter("folder") : "T";
				String filename = request.getParameter("filename");
				String downloadFilename = request.getParameter("download_filename");
				boolean removeFilenameTimestamp = request.getParameter("remove_filename_timestamp") != null;
				String downloadName = downloadFilename != null
						? downloadFilename
						: (filename != null && folder.equals("F")
								? (removeFilenameTimestamp ? filename.substring(filename.indexOf("_") + 1) : filename)
								: (filename != null ? filename : null));
				filename = StringUtils.replace(filename, "`", "#");
				if (downloadName == null) {
					response.sendError(404, "Filename not specified");
					return;
				}

				String folderPath = folder.equals("F")
						? SystemProperties.getProperty("files_path")
						: SystemProperties.getProperty("temp_path");
				File myFile = new File(folderPath + filename);
				if (!myFile.canRead()) {
					response.sendError(404, "Cannot find file " + myFile.getName());
					return;
				}

				response.setContentLength((int) myFile.length());
				response.setContentType("application/octet-stream");
				response.setHeader("Content-Disposition", "attachment; filename=\"" + downloadName + "\"");
				InputStream in = null;
				BufferedOutputStream out = null;

				try {
					in = new BufferedInputStream(new FileInputStream(myFile));
					out = new BufferedOutputStream(response.getOutputStream());
					pipe(in, out, 2048);
					out.flush();
				} finally {
					in.close();
				}
			}
		} catch (SessionExpiredException var17) {
			folder = request.getServerName() + ":" + request.getServerPort() + request.getContextPath()
					+ request.getServletPath() + "?folder=" + request.getParameter("folder") + "&filename="
					+ request.getParameter("filename") + "&external=Y";
			RequestDispatcher rd = this.getServletContext()
					.getRequestDispatcher("/login.htm?returnUrl=" + URLEncoder.encode(folder));
			rd.forward(request, response);
		}

	}

	public static long pipe(InputStream in, OutputStream out, int chunkSize) throws IOException {
		if (chunkSize < 1) {
			throw new IOException("Invalid chunk size.");
		} else {
			byte[] buffer = new byte[chunkSize];

			long total;
			int n;
			for (total = 0L; (n = in.read(buffer)) != -1; total += (long) n) {
				out.write(buffer, 0, n);
			}

			return total;
		}
	}
}