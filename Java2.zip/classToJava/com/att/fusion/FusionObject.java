//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion;

public interface FusionObject {
    public static class Parameters {
        public static final String PARAM_USERID = "userId";
        public static final String PARAM_HTTP_REQUEST = "request";
        public static final String PARAM_FILTERS = "filters";
        public static final String REQUEST_PARAM_DISPLAY_SUCCESS_MESSAGE = "display_success_message";

        public Parameters() {
        }
    }

    public static class Utilities {
        public Utilities() {
        }

        public static String nvl(String s) {
            return s == null ? "" : s;
        }

        public static String nvl(String s, String sDefault) {
            return nvl(s).equals("") ? sDefault : s;
        }
    }
}
