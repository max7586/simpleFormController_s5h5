//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.service;

import java.util.Hashtable;

public interface BroadcastService {
	Hashtable getBroadcastMessages();

	void loadMessages();
}
