//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.service.support;

import java.util.Properties;
import javax.naming.Context;
import javax.naming.NamingException;
import javax.naming.directory.DirContext;
import javax.naming.directory.InitialDirContext;
import javax.naming.ldap.InitialLdapContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class ServiceLocator {
	private Context context;
	private Context rootContext;
	private DirContext dirContext;
	private InitialLdapContext ldapContext;
	protected final Log logger = LogFactory.getLog(this.getClass());

	public ServiceLocator() {
	}

	public DirContext getDirContext(String initialContextFactory, String providerUrl, String securityPrincipal) {
		if (this.dirContext == null) {
			Properties properties = new Properties();
			properties.put("java.naming.factory.initial", initialContextFactory);
			properties.put("java.naming.provider.url", providerUrl);
			properties.put("java.naming.security.principal", securityPrincipal);

			try {
				this.dirContext = new InitialDirContext(properties);
			} catch (NamingException var6) {
				this.logger.error("An error has occurred while creating an Initial Directory Context: " + var6.getMessage());
				this.logger.error("Explanation: " + var6.getExplanation());
			}
		}

		return this.dirContext;
	}
}
