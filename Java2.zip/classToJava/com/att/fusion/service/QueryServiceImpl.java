//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.service;

import com.att.fusion.dao.ModelDao;
import com.att.fusion.service.support.FusionService;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class QueryServiceImpl extends FusionService implements QueryService {
	protected final Log logger = LogFactory.getLog(this.getClass());
	private ModelDao modelDao;

	public QueryServiceImpl() {
	}

	public List executeQuery(String sql, Class domainClass, HashMap additionalParams) {
		return this.executeQuery(sql, domainClass, null, null, additionalParams);
	}

	public List executeQuery(String sql, Class domainClass, Integer fromIndex, Integer toIndex, HashMap additionalParams) {
		return this.getModelDao().executeQuery(sql, domainClass, fromIndex, toIndex, additionalParams);
	}

	public List executeQuery(String sql, HashMap additionalParams) {
		return this.executeQuery(sql, null, null, additionalParams);
	}

	public List executeQuery(String sql, Integer fromIndex, Integer toIndex, HashMap additionalParams) {
		return this.getModelDao().executeQuery(sql, fromIndex, toIndex, additionalParams);
	}

	public List executeNamedQuery(String queryName, Integer fromIndex, Integer toIndex, HashMap additionalParams) {
		return this.executeNamedQuery(queryName, null, fromIndex, toIndex, additionalParams);
	}

	public List executeNamedQuery(String queryName, Map params, HashMap additionalParams) {
		return this.executeNamedQuery(queryName, params, null, null, additionalParams);
	}

	public List executeNamedQuery(String queryName, Map params, Integer fromIndex, Integer toIndex, HashMap additionalParams) {
		return this.getModelDao().executeNamedQuery(queryName, params, fromIndex, toIndex, additionalParams);
	}

	public int executeUpdateQuery(String sql, HashMap additionalParams) throws RuntimeException {
		int rowsAffected = 0;
		return this.getModelDao().executeUpdateQuery(sql, additionalParams);
	}

	public int executeNamedUpdateQuery(String queryName, Map params, HashMap additionalParams) throws RuntimeException {
		int rowsAffected = 0;
		return this.getModelDao().executeNamedUpdateQuery(queryName, params, additionalParams);
	}

	public void executeBatchUpdate(LinkedHashSet batch, boolean atomic, HashMap additionalParams) throws RuntimeException {
		this.getModelDao().executeBatch(batch, atomic, additionalParams);
	}

	public List executeQuery(String sql, Class domainClass) {
		return this.executeQuery(sql, domainClass, null, null, null);
	}

	public List executeQuery(String sql, Class domainClass, Integer fromIndex, Integer toIndex) {
		return this.executeQuery(sql, domainClass, fromIndex, toIndex, null);
	}

	public List executeQuery(String sql) {
		return this.executeQuery(sql, null, null, (HashMap)null);
	}

	public List executeQuery(String sql, Integer fromIndex, Integer toIndex) {
		return this.executeQuery(sql, fromIndex, toIndex, null);
	}

	public List executeNamedQuery(String queryName) {
		return this.executeNamedQuery(queryName, null, null, null, null);
	}

	public List executeNamedQuery(String queryName, Integer fromIndex, Integer toIndex) {
		return this.executeNamedQuery(queryName, null, fromIndex, toIndex, null);
	}

	public List executeNamedQuery(String queryName, Map params) {
		return this.executeNamedQuery(queryName, params, null, null, null);
	}

	public List executeNamedQuery(String queryName, Map params, Integer fromIndex, Integer toIndex) {
		return this.executeNamedQuery(queryName, params, fromIndex, toIndex, null);
	}

	public int executeUpdateQuery(String sql) throws RuntimeException {
		return this.executeUpdateQuery(sql, null);
	}

	public int executeNamedUpdateQuery(String queryName) throws RuntimeException {
		return this.executeNamedUpdateQuery(queryName, null, null);
	}

	public int executeNamedUpdateQuery(String queryName, Map params) throws RuntimeException {
		return this.executeNamedUpdateQuery(queryName, params, null);
	}

	public void executeBatchUpdate(LinkedHashSet batch, boolean atomic) throws RuntimeException {
		this.executeBatchUpdate(batch, atomic, null);
	}

	public ModelDao getModelDao() {
		return this.modelDao;
	}

	public void setModelDao(ModelDao modelDao) {
		this.modelDao = modelDao;
	}
}
