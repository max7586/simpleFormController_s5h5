//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.service;

import com.att.fusion.dao.ModelDao;
import com.att.fusion.domain.AuditLog;
import com.att.fusion.service.support.FusionService;
import java.util.HashMap;

public class AuditServiceImpl extends FusionService implements AuditService {
	private static ModelDao modelDao;

	public AuditServiceImpl() {
	}

	public void logActivity(AuditLog vo, HashMap additionalParams) {
		this.getModelDao().update(vo, additionalParams);
	}

	public ModelDao getModelDao() {
		return modelDao;
	}

	public void setModelDao(ModelDao modelDao) {
		AuditServiceImpl.modelDao = modelDao;
	}
}
