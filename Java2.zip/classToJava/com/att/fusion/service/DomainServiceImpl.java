//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.service;

import com.att.fusion.dao.ModelDao;
import com.att.fusion.domain.support.DomainVo;
import com.att.fusion.service.support.FusionService;
import java.io.Serializable;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class DomainServiceImpl extends FusionService implements DomainService {
	protected final Log logger = LogFactory.getLog(this.getClass());
	private ModelDao modelDao;

	public DomainServiceImpl() {
	}

	public DomainVo getDomainObject(Class domainClass, Serializable id, HashMap additionalParams) {
		return this.getModelDao().get(domainClass, id, additionalParams);
	}

	public void deleteDomainObject(DomainVo domainObject, HashMap additionalParams) {
		this.getModelDao().remove(domainObject, additionalParams);
	}

	public void deleteDomainObjects(Class domainClass, String whereClause, HashMap additionalParams) {
		this.getModelDao().remove(domainClass, whereClause, additionalParams);
	}

	public void saveDomainObject(DomainVo domainObject, HashMap additionalParams) {
		this.getModelDao().update(domainObject, additionalParams);
	}

	public void executeBatchUpdate(LinkedHashSet batch, HashMap additionalParams) throws RuntimeException {
		this.getModelDao().executeBatch(batch, true, additionalParams);
	}

	public void executeCallback(Class callbackClass, Object callbackBean, HashMap additionalParams) throws RuntimeException {
		this.getModelDao().executeCallback(callbackClass, callbackBean, additionalParams);
	}

	public List getList(Class domainClass, HashMap additionalParams) {
		return this.getModelDao().getList(domainClass, additionalParams);
	}

	public List getList(Class domainClass, List filter, String orderBy, HashMap additionalParams) {
		return this.getModelDao().getList(domainClass, filter, null, null, orderBy, additionalParams);
	}

	public List getList(Class domainClass, List filter, int fromIndex, int toIndex, String orderBy, HashMap additionalParams) {
		return this.getModelDao().getList(domainClass, filter, new Integer(fromIndex), new Integer(toIndex), orderBy, additionalParams);
	}

	public List getList(Class domainClass, String filter, String orderBy, HashMap additionalParams) {
		return this.getModelDao().getList(domainClass, filter, null, null, orderBy, additionalParams);
	}

	public List getList(Class domainClass, String filter, int fromIndex, int toIndex, String orderBy, HashMap additionalParams) {
		return this.getModelDao().getList(domainClass, filter, new Integer(fromIndex), new Integer(toIndex), orderBy, additionalParams);
	}

	public void synchronize(HashMap additionalParams) {
		this.getModelDao().flush(additionalParams);
	}

	public DomainVo getDomainObject(Class domainClass, Serializable id) {
		return this.getDomainObject(domainClass, id, null);
	}

	public void deleteDomainObject(DomainVo domainObject) {
		this.deleteDomainObject(domainObject, null);
	}

	public void deleteDomainObjects(Class domainClass, String whereClause) {
		this.deleteDomainObjects(domainClass, whereClause, null);
	}

	public void saveDomainObject(DomainVo domainObject) {
		this.saveDomainObject(domainObject, null);
	}

	public void executeBatchUpdate(LinkedHashSet batch) throws RuntimeException {
		this.executeBatchUpdate(batch, null);
	}

	public void executeCallback(Class callbackClass, Object callbackBean) throws RuntimeException {
		this.executeCallback(callbackClass, callbackBean, null);
	}

	public List getList(Class domainClass) {
		return this.getList(domainClass, null);
	}

	public List getList(Class domainClass, List filter, String orderBy) {
		return this.getList(domainClass, filter, orderBy, null);
	}

	public List getList(Class domainClass, List filter, int fromIndex, int toIndex, String orderBy) {
		return this.getList(domainClass, filter, fromIndex, toIndex, orderBy, null);
	}

	public List getList(Class domainClass, String filter, String orderBy) {
		return this.getList(domainClass, filter, orderBy, null);
	}

	public List getList(Class domainClass, String filter, int fromIndex, int toIndex, String orderBy) {
		return this.getList(domainClass, filter, fromIndex, toIndex, orderBy, null);
	}

	public void synchronize() {
		this.synchronize(null);
	}

	public ModelDao getModelDao() {
		return this.modelDao;
	}

	public void setModelDao(ModelDao modelDao) {
		this.modelDao = modelDao;
	}
}
