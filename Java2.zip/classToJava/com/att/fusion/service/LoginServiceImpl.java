//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.service;

import com.att.fusion.command.LoginBean;
import com.att.fusion.dao.ModelDao;
import com.att.fusion.dao.support.QueryFilter;
import com.att.fusion.domain.AuditLog;
import com.att.fusion.domain.Role;
import com.att.fusion.domain.User;
import com.att.fusion.menu.MenuBuilder;
import com.att.fusion.service.support.FusionService;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.UserUtils;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class LoginServiceImpl extends FusionService implements LoginService {
	protected final Log logger = LogFactory.getLog(this.getClass());
	private MenuBuilder menuBuilder;
	private ModelDao modelDao;
	private AuditService auditService;

	public LoginServiceImpl() {
	}

	public LoginBean findUser(LoginBean bean, String menuPropertiesFilename, HashMap additionalParams) throws Exception {
		User user = null;
		User userCopy = null;
		if (bean.getAttuid() != null && bean.getAttuid() != null) {
			user = this.findUser(bean);
		} else {
			user = this.findUser(bean.getLoginId(), bean.getLoginPwd());
		}

		if (user != null) {
			if (AppUtils.isApplicationLocked() && !UserUtils.hasRole(user, SystemProperties.getProperty("sys_admin_role_id"))) {
				bean.setLoginErrorMessage("login.error.application.locked");
			}

			if (!user.getActive()) {
				bean.setLoginErrorMessage("login.error.user.inactive");
			}

			boolean hasActiveRole = false;

			for(Role role : user.getRoles()) {
				if (role.getActive()) {
					hasActiveRole = true;
					break;
				}
			}

			if (!hasActiveRole) {
				bean.setLoginErrorMessage("login.error.user.inactive");
			}

			if (bean.getLoginErrorMessage() == null) {
				userCopy = (User)user.copy();
				user.setLastLoginDate(new Date());
				this.getModelDao().update(user, additionalParams);
				AuditLog log = new AuditLog();
				log.setActivityCode("login");
				log.setCreatedId(user.getId());
				this.getAuditService().logActivity(log, additionalParams);
				bean.setMenu(
						this.getMenuBuilder()
								.buildMenu(
										SystemProperties.getProperty("application_menu_set_name"),
										bean.getSiteAccess(),
										UserUtils.getRoleFunctions(UserUtils.getAllUserRoles(user)),
										menuPropertiesFilename
								)
				);
				bean.setBusinessDirectMenu(
						this.getMenuBuilder()
								.buildMenu(
										SystemProperties.getProperty("business_direct_menu_set_name"),
										bean.getSiteAccess(),
										UserUtils.getRoleFunctions(UserUtils.getAllUserRoles(user)),
										SystemProperties.getProperty("business_direct_menu_properties_name")
								)
				);
				bean.setUser(userCopy);
			}
		}

		return bean;
	}

	public User findUser(String loginId, String password) {
		ArrayList criteria = new ArrayList();
		List list = null;
		criteria.add(new QueryFilter("login_id", loginId, 20));
		criteria.add(new QueryFilter("login_pwd", password, 20));
		list = this.getModelDao().getList(User.class, criteria, null);
		return list != null && list.size() != 0 ? (User)list.get(0) : null;
	}

	public User findUser(LoginBean bean) {
		ArrayList criteria = new ArrayList();
		List list = null;
		criteria.add(new QueryFilter("sbcid", bean.getAttuid(), 20));
		list = this.getModelDao().getList(User.class, criteria, null);
		return list != null && list.size() != 0 ? (User)list.get(0) : null;
	}

	public MenuBuilder getMenuBuilder() {
		return this.menuBuilder;
	}

	public ModelDao getModelDao() {
		return this.modelDao;
	}

	public AuditService getAuditService() {
		return this.auditService;
	}

	public void setMenuBuilder(MenuBuilder menuBuilder) {
		this.menuBuilder = menuBuilder;
	}

	public void setModelDao(ModelDao modelDao) {
		this.modelDao = modelDao;
	}

	public void setAuditService(AuditService auditService) {
		this.auditService = auditService;
	}
}
