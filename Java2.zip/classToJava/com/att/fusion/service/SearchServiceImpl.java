//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.service;

import com.att.fusion.command.support.SearchResult;
import com.att.fusion.dao.SearchDao;
import com.att.fusion.service.support.FusionService;
import java.util.HashMap;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class SearchServiceImpl extends FusionService implements SearchService {
	protected final Log logger = LogFactory.getLog(this.getClass());
	private SearchDao dao;

	public SearchServiceImpl() {
	}

	public SearchResult getSearchResult(
			Class domainClass, List searchCriteria, String sortBy1, String sortBy2, String sortBy3, int pageNo, int dataSize, HashMap additionalParams
	) {
		return this.getSearchResult(domainClass, searchCriteria, sortBy1, false, sortBy2, false, sortBy3, false, pageNo, dataSize, additionalParams);
	}

	public SearchResult getSearchResult(
			Class domainClass,
			List searchCriteria,
			String sortBy1,
			boolean sortBy1Desc,
			String sortBy2,
			boolean sortBy2Desc,
			String sortBy3,
			boolean sortBy3Desc,
			int pageNo,
			int dataSize,
			HashMap additionalParams
	) {
		return this.getSearchDao()
				.getSearchResult(domainClass, searchCriteria, sortBy1, sortBy1Desc, sortBy2, sortBy2Desc, sortBy3, sortBy3Desc, pageNo, dataSize, additionalParams);
	}

	public List getLookupList(String dbTable, String dbValueCol, String dbLabelCol, String dbFilter, String dbOrderBy, HashMap additionalParams) {
		return this.getSearchDao().getLookupList(dbTable, dbValueCol, dbLabelCol, dbFilter, dbOrderBy, additionalParams);
	}

	public void setSearchDao(SearchDao dao) {
		this.dao = dao;
	}

	public SearchDao getSearchDao() {
		return this.dao;
	}
}
