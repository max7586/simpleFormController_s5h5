//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.service;

import com.att.fusion.command.support.SearchResult;
import com.att.fusion.domain.support.DomainVo;

public interface LdapService {
	SearchResult searchPost(DomainVo var1, String var2, String var3, String var4, int var5, int var6, int var7) throws Exception;
}
