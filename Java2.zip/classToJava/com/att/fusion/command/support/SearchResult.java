//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.command.support;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SearchResult extends ArrayList implements Serializable {
	private int pageNo = 0;
	private int pageSize = 50;
	private int dataSize = -1;
	private String accessType = null;

	public SearchResult() {
	}

	public SearchResult(List items) {
		super(items);
	}

	public int getPageNo() {
		return this.pageNo;
	}

	public int getPageSize() {
		return this.pageSize;
	}

	public int getDataSize() {
		return this.dataSize;
	}

	public int getSize() {
		return this.size();
	}

	public String getAccessType() {
		return this.accessType;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public void setPageSize(int pageSize) {
		this.dataSize = pageSize;
	}

	public void setDataSize(int dataSize) {
		this.dataSize = dataSize;
	}

	public void setAccessType(String accessType) {
		this.accessType = accessType;
	}
}
