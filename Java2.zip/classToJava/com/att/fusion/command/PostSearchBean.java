//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.command;

import com.att.fusion.FusionObject.Utilities;
import com.att.fusion.command.support.SearchBase;
import com.att.fusion.domain.User;
import java.util.List;

public class PostSearchBean extends SearchBase {
	private User user = null;
	private User userOrig = null;
	private String[] selected;
	private String[] postHrid;
	private String[] postSbcid;
	private String[] postFirstName;
	private String[] postLastName;
	private String[] postOrgCode;
	private String[] postPhone;
	private String[] postEmail;
	private String[] postAddress1;
	private String[] postCity;
	private String[] postState;
	private String[] postZipCode;
	private String[] postLocationClli;
	private String[] postBusinessCountryCode;
	private String[] postDepartmentCode;
	private String[] postBusinessCountryName;
	private String[] postDepartment;
	private String[] postJobTitle;
	private String[] postManagerAttuid;
	private String[] postCommandChain;
	private String[] postCompanyCode;
	private String[] postCompany;

	public PostSearchBean() {
		this(null);
	}

	public PostSearchBean(List items) {
		super(items);
		this.user = new User();
		this.userOrig = new User();
		this.setSortBy1("");
		this.setSortBy1Orig("");
	}

	public String getFirstName() {
		return this.user.getFirstName();
	}

	public String getLastName() {
		return this.user.getLastName();
	}

	public String getHrid() {
		return this.user.getHrid();
	}

	public String getSbcid() {
		return this.user.getSbcid();
	}

	public String getOrgCode() {
		return this.user.getOrgCode();
	}

	public String getEmail() {
		return this.user.getEmail();
	}

	public String getFirstNameOrig() {
		return this.user.getFirstName();
	}

	public String getLastNameOrig() {
		return this.user.getLastName();
	}

	public String getHridOrig() {
		return this.user.getHrid();
	}

	public String getSbcidOrig() {
		return this.user.getSbcid();
	}

	public String getOrgCodeOrig() {
		return this.user.getOrgCode();
	}

	public String getEmailOrig() {
		return this.user.getEmail();
	}

	public User getUser() {
		return this.user;
	}

	public String[] getPostEmail() {
		return this.postEmail;
	}

	public String[] getPostFirstName() {
		return this.postFirstName;
	}

	public String[] getPostHrid() {
		return this.postHrid;
	}

	public String[] getPostLastName() {
		return this.postLastName;
	}

	public String[] getPostOrgCode() {
		return this.postOrgCode;
	}

	public String[] getPostPhone() {
		return this.postPhone;
	}

	public String[] getPostSbcid() {
		return this.postSbcid;
	}

	public String[] getSelected() {
		return this.selected;
	}

	public String[] getPostAddress1() {
		return this.postAddress1;
	}

	public String[] getPostBusinessCountryCode() {
		return this.postBusinessCountryCode;
	}

	public String[] getPostCity() {
		return this.postCity;
	}

	public String[] getPostCommandChain() {
		return this.postCommandChain;
	}

	public String[] getPostCompany() {
		return this.postCompany;
	}

	public String[] getPostCompanyCode() {
		return this.postCompanyCode;
	}

	public String[] getPostDepartment() {
		return this.postDepartment;
	}

	public String[] getPostDepartmentCode() {
		return this.postDepartmentCode;
	}

	public String[] getPostBusinessCountryName() {
		return this.postBusinessCountryName;
	}

	public String[] getPostJobTitle() {
		return this.postJobTitle;
	}

	public String[] getPostLocationClli() {
		return this.postLocationClli;
	}

	public String[] getPostManagerAttuid() {
		return this.postManagerAttuid;
	}

	public String[] getPostState() {
		return this.postState;
	}

	public String[] getPostZipCode() {
		return this.postZipCode;
	}

	public void setFirstName(String value) {
		this.user.setFirstName(value);
	}

	public void setLastName(String value) {
		this.user.setLastName(value);
	}

	public void setHrid(String value) {
		this.user.setHrid(value);
	}

	public void setSbcid(String value) {
		this.user.setSbcid(value);
	}

	public void setOrgCode(String value) {
		this.user.setOrgCode(value);
	}

	public void setEmail(String value) {
		this.user.setEmail(value);
	}

	public void setFirstNameOrig(String value) {
		this.userOrig.setFirstName(value);
	}

	public void setLastNameOrig(String value) {
		this.userOrig.setLastName(value);
	}

	public void setHridOrig(String value) {
		this.userOrig.setHrid(value);
	}

	public void setSbcidOrig(String value) {
		this.userOrig.setSbcid(value);
	}

	public void setOrgCodeOrig(String value) {
		this.userOrig.setOrgCode(value);
	}

	public void setEmailOrig(String value) {
		this.userOrig.setEmail(value);
	}

	public void setUser(User value) {
		this.user = value;
	}

	public void setPostEmail(String[] postEmail) {
		this.postEmail = postEmail;
	}

	public void setPostFirstName(String[] postFirstName) {
		this.postFirstName = postFirstName;
	}

	public void setPostHrid(String[] postHrid) {
		this.postHrid = postHrid;
	}

	public void setPostLastName(String[] postLastName) {
		this.postLastName = postLastName;
	}

	public void setPostOrgCode(String[] postOrgCode) {
		this.postOrgCode = postOrgCode;
	}

	public void setPostPhone(String[] postPhone) {
		this.postPhone = postPhone;
	}

	public void setPostSbcid(String[] postSbcid) {
		this.postSbcid = postSbcid;
	}

	public void setSelected(String[] selected) {
		this.selected = selected;
	}

	public void setPostAddress1(String[] postAddress1) {
		this.postAddress1 = postAddress1;
	}

	public void setPostBusinessCountryCode(String[] postBusinessCountryCode) {
		this.postBusinessCountryCode = postBusinessCountryCode;
	}

	public void setPostCity(String[] postCity) {
		this.postCity = postCity;
	}

	public void setPostCommandChain(String[] postCommandChain) {
		this.postCommandChain = postCommandChain;
	}

	public void setPostCompany(String[] postCompany) {
		this.postCompany = postCompany;
	}

	public void setPostCompanyCode(String[] postCompanyCode) {
		this.postCompanyCode = postCompanyCode;
	}

	public void setPostDepartment(String[] postDepartment) {
		this.postDepartment = postDepartment;
	}

	public void setPostDepartmentCode(String[] postDepartmentCode) {
		this.postDepartmentCode = postDepartmentCode;
	}

	public void setPostBusinessCountryName(String[] postBusinessCountryName) {
		this.postBusinessCountryName = postBusinessCountryName;
	}

	public void setPostJobTitle(String[] postJobTitle) {
		this.postJobTitle = postJobTitle;
	}

	public void setPostLocationClli(String[] postLocationClli) {
		this.postLocationClli = postLocationClli;
	}

	public void setPostManagerAttuid(String[] postManagerAttuid) {
		this.postManagerAttuid = postManagerAttuid;
	}

	public void setPostState(String[] postState) {
		this.postState = postState;
	}

	public void setPostZipCode(String[] postZipCode) {
		this.postZipCode = postZipCode;
	}

	public void resetSearch() {
		super.resetSearch();
		this.setUser(new User());
	}

	public boolean isCriteriaUpdated() {
		if (this.user == null && this.userOrig == null) {
			return false;
		} else if (this.user != null && this.userOrig != null) {
			return !Utilities.nvl(this.user.getFirstName()).equals(Utilities.nvl(this.userOrig.getFirstName()))
					|| !Utilities.nvl(this.user.getLastName()).equals(Utilities.nvl(this.userOrig.getLastName()))
					|| !Utilities.nvl(this.user.getHrid()).equals(Utilities.nvl(this.userOrig.getHrid()))
					|| !Utilities.nvl(this.user.getSbcid()).equals(Utilities.nvl(this.userOrig.getSbcid()))
					|| !Utilities.nvl(this.user.getOrgCode()).equals(Utilities.nvl(this.userOrig.getOrgCode()))
					|| !Utilities.nvl(this.user.getEmail()).equals(Utilities.nvl(this.userOrig.getEmail()));
		} else {
			return true;
		}
	}
}
