//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.menu;

import java.io.Serializable;
import java.util.Collection;
import java.util.Iterator;
import java.util.Vector;

public class MenuItem implements Serializable {
	protected String id;
	protected String label;
	protected String url = "";
	protected String target;
	protected Collection childMenuItems;
	protected boolean enabled;

	public MenuItem(String id, String label) throws Exception {
		this.target = "";
		this.childMenuItems = new Vector();
		this.enabled = true;
		if (id == null) {
			throw new Exception("The menu item id cannot be null.");
		} else {
			this.id = id;
			this.label = label;
		}
	}

	public MenuItem(String id, String label, String url, boolean isEnabled) throws Exception {
		this.target = "";
		this.childMenuItems = new Vector();
		this.enabled = true;
		if (id == null) {
			throw new Exception("The menu item id cannot be null.");
		} else {
			this.id = id;
			this.enabled = isEnabled;
			this.label = label;
			this.url = url;
		}
	}

	public MenuItem(String id, String label, String url, String target, boolean isEnabled) throws Exception {
		this.target = "";
		this.childMenuItems = new Vector();
		this.enabled = true;
		if (id == null) {
			throw new Exception("The menu item id cannot be null.");
		} else {
			this.id = id;
			this.enabled = isEnabled;
			this.label = label;
			this.url = url;
			this.target = target;
		}
	}

	public MenuItem() {
		this.childMenuItems = new Vector();
		this.enabled = true;
	}

	public MenuItem addChild(MenuConfigData menuConfigData, String id, String label) throws Exception {
		MenuItem menuItem = new MenuItem(id, label);
		this.childMenuItems.add(menuItem);
		menuConfigData.addItemToIndex(menuItem);
		return menuItem;
	}

	public MenuItem addChild(MenuConfigData menuConfigData, String id, String label, String url, boolean isEnabled) throws Exception {
		MenuItem menuItem = new MenuItem(id, label, url, isEnabled);
		this.childMenuItems.add(menuItem);
		menuConfigData.addItemToIndex(menuItem);
		return menuItem;
	}

	public MenuItem addChild(MenuConfigData menuConfigData, String id, String label, String url, String target, boolean isEnabled) throws Exception {
		MenuItem menuItem = new MenuItem(id, label, url, target, isEnabled);
		this.childMenuItems.add(menuItem);
		menuConfigData.addItemToIndex(menuItem);
		return menuItem;
	}

	public void printTopItems(StringBuffer topSb, StringBuffer sb, String s, String menuId) {
		if (this.childMenuItems != null) {
			if (this.hasChildren()) {
				topSb.append(
						"<td class='"
								+ MenuProperties.getProperty("top_menu_class", menuId)
								+ "' align='center'><a id=\""
								+ MenuProperties.getProperty("menu_id_prefix", menuId)
								+ "menu"
								+ s
								+ "\" class='"
								+ MenuProperties.getProperty("top_menu_link_class", menuId)
								+ "' href='"
								+ (
								this.url.equals("")
										? "javascript:void(0);"
										: MenuBuilder.globalReplace(this.url, "{0}", "" + MenuProperties.getProperty("menu_id_prefix", menuId) + "menu" + s)
						)
								+ "' onMouseOver=\"enterTopMenuItem(this, event, 'HM_Menu"
								+ s
								+ "'"
								+ MenuProperties.getProperty("on_mouse_over_trailer", menuId)
								+ ");\" onMouseOut=\"leaveTopMenuItem(this, 'HM_Menu"
								+ s
								+ "'"
								+ MenuProperties.getProperty("on_mouse_out_trailer", menuId)
								+ ");\">"
								+ this.label
								+ "</a></td>"
				);
				sb.append("HM_Array" + s + " = [\n").append(MenuHelper.getMenuBuilder(menuId)).append(",\n");
				Iterator iterator = this.childMenuItems.iterator();
				int i = 1;
				StringBuffer cSb = new StringBuffer();

				while(iterator.hasNext()) {
					MenuItem menuItem = (MenuItem)iterator.next();
					if (menuItem.isEnabled()) {
						menuItem.printItem(sb, cSb, s + "_" + i++);
					}
				}

				sb.deleteCharAt(sb.length() - 2);
				sb.append("]\n\n");
				sb.append(cSb.toString());
			} else {
				topSb.append(
						"<td class='"
								+ MenuProperties.getProperty("top_menu_class", menuId)
								+ "' align='center'><a id=\""
								+ MenuProperties.getProperty("menu_id_prefix", menuId)
								+ "menu"
								+ s
								+ "\" class='"
								+ MenuProperties.getProperty("top_menu_link_class", menuId)
								+ "' href='"
								+ (
								this.url.equals("")
										? "javascript:void(0);"
										: MenuBuilder.globalReplace(this.url, "{0}", "" + MenuProperties.getProperty("menu_id_prefix", menuId) + "menu" + s)
						)
								+ "' onMouseOver='enterTopMenuItem(this, event, null"
								+ MenuProperties.getProperty("on_mouse_over_trailer", menuId)
								+ ");' onMouseOut='leaveTopMenuItem(this, null"
								+ MenuProperties.getProperty("on_mouse_out_trailer", menuId)
								+ ");'>"
								+ this.label
								+ "</a></td>"
				);
			}
		}
	}

	public void printItem(StringBuffer sb, StringBuffer cSb, String s) {
		if (this.childMenuItems != null) {
			if (this.hasChildren()) {
				sb.append(
						"['<span width=\"100%\" title=\"" + this.label + "\">&nbsp;&nbsp;" + this.label + "&nbsp;&nbsp;</span>','" + this.url + "',1,0,1]," + "\n"
				);
				cSb.append("HM_Array" + s + " = [\n[],\n");
				Iterator iterator = this.childMenuItems.iterator();
				int i = 1;
				StringBuffer childSb = new StringBuffer();

				while(iterator.hasNext()) {
					MenuItem menuItem = (MenuItem)iterator.next();
					if (menuItem.isEnabled()) {
						menuItem.printItem(cSb, childSb, s + "_" + i++);
					}
				}

				cSb.deleteCharAt(cSb.length() - 2);
				cSb.append("]\n\n");
				cSb.append(childSb.toString());
			} else {
				sb.append(
						"['<span width=\"100%\" title=\"" + this.label + "\">&nbsp;&nbsp;" + this.label + "&nbsp;&nbsp;</span>','" + this.url + "',1,0,0]," + "\n"
				);
			}
		}
	}

	public Collection getChildMenuItems() {
		return this.childMenuItems;
	}

	public void setChildMenuItems(Collection childMenuItems) {
		this.childMenuItems = childMenuItems;
	}

	public String getId() {
		return this.id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public boolean isEnabled() {
		return this.enabled;
	}

	public void setEnabled(boolean isEnabled) {
		this.enabled = isEnabled;
	}

	public String getLabel() {
		return this.label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getUrl() {
		return this.url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public boolean hasUrl() {
		return !this.url.equals("");
	}

	public boolean hasChildren() {
		return this.childMenuItems.size() > 0;
	}

	public String getTarget() {
		return this.target;
	}

	public void setTarget(String target) {
		this.target = target;
	}
}
