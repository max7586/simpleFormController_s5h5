//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.menu;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Vector;

public class MenuConfigData implements Serializable {
	protected Collection menuItems = new Vector();
	protected Map menuItemsIndex = new HashMap();
	protected String menuId;

	public MenuConfigData() {
	}

	public MenuConfigData(String menuId) {
		this();
		this.menuId = menuId;
	}

	public MenuItem addTopLevelMenu(String id, String label, String url, boolean isEnabled) throws Exception {
		MenuItem menuItem = new MenuItem(id, label, url, isEnabled);
		this.menuItems.add(menuItem);
		this.addItemToIndex(menuItem);
		return menuItem;
	}

	public MenuItem addTopLevelMenu(String id, String label, String url, String target, boolean isEnabled) throws Exception {
		MenuItem menuItem = new MenuItem(id, label, url, target, isEnabled);
		this.menuItems.add(menuItem);
		this.addItemToIndex(menuItem);
		return menuItem;
	}

	public void buildIndex() {
		this.menuItemsIndex.clear();
		Iterator i = this.menuItems.iterator();

		while(i.hasNext()) {
			this.addItemToIndex((MenuItem)i.next());
		}
	}

	public void clearMenuItems() {
		this.menuItems.clear();
	}

	public void setMenuItems(Collection c) throws Exception {
		this.clearMenuItems();
		this.menuItems.addAll(c);
		this.buildIndex();
	}

	public void setMenuId(String menuId) {
		this.menuId = menuId;
	}

	public Collection getMenuItems() {
		return this.menuItems;
	}

	public String getMenuId() {
		return this.menuId;
	}

	public MenuItem findMenuItem(String id) throws Exception {
		try {
			return (MenuItem)this.menuItemsIndex.get(id);
		} catch (NullPointerException var3) {
			throw new Exception("No menu item found in index with the given id - " + id);
		}
	}

	protected void addItemToIndex(MenuItem menuItem) {
		this.menuItemsIndex.put(menuItem.getId(), menuItem);
		Iterator i = menuItem.getChildMenuItems().iterator();

		while(i.hasNext()) {
			this.addItemToIndex((MenuItem)i.next());
		}
	}
}
