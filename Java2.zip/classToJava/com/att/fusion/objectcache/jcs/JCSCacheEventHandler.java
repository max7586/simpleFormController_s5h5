//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.objectcache.jcs;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.jcs.engine.control.event.behavior.IElementEvent;
import org.apache.jcs.engine.control.event.behavior.IElementEventConstants;
import org.apache.jcs.engine.control.event.behavior.IElementEventHandler;

public class JCSCacheEventHandler implements IElementEventHandler, IElementEventConstants {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public JCSCacheEventHandler() {
	}

	public void handleElementEvent(IElementEvent event) {
		switch(event.getElementEvent()) {
			case 0:
				this.logger.error("Event ELEMENT_EVENT_EXCEEDED_MAXLIFE_BACKGROUND occurred for element " + event);
				break;
			case 1:
				this.logger.error("Event ELEMENT_EVENT_EXCEEDED_MAXLIFE_ONREQUEST occurred for element " + event);
				break;
			case 2:
				this.logger.error("Event ELEMENT_EVENT_EXCEEDED_IDLETIME_BACKGROUND occurred for element " + event);
				break;
			case 3:
				this.logger.error("Event ELEMENT_EVENT_EXCEEDED_IDLETIME_ONREQUEST occurred for element " + event);
				break;
			case 4:
				this.logger.error("Event ELEMENT_EVENT_SPOOLED_DISK_AVAILABLE occurred for element " + event);
				break;
			case 5:
				this.logger.error("Event ELEMENT_EVENT_SPOOLED_DISK_NOT_AVAILABLE occurred for element " + event);
				break;
			case 6:
				this.logger.error("Event ELEMENT_EVENT_SPOOLED_NOT_ALLOWED occurred for element " + event);
		}
	}
}
