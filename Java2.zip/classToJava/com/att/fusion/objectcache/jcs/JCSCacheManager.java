//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.objectcache.jcs;

import com.att.fusion.objectcache.AbstractCacheManager;
import com.att.fusion.service.QueryService;
import com.att.fusion.util.SystemProperties;
import java.io.IOException;
import java.util.Properties;
import java.util.Vector;
import javax.servlet.ServletContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.jcs.JCS;
import org.apache.jcs.access.exception.CacheException;
import org.apache.jcs.engine.CacheConstants;
import org.apache.jcs.engine.behavior.IElementAttributes;
import org.apache.jcs.engine.control.CompositeCacheManager;

public abstract class JCSCacheManager extends AbstractCacheManager implements CacheConstants {
	public static String LOOKUP_OBJECT_CACHE_NAME = "lookUpObjectCache";
	public static String JCS_CONFIG_FILE_PATH = "cache_config_file_path";
	public static String CACHE_LOAD_ON_STARTUP = "cache_load_on_startup";
	public static String CACHE_PROPERTY_VALUE_TRUE = "true";
	public static String CACHE_CONTROL_SWITCH_ON = "1";
	public static String CACHE_CONTROL_SWITCH_OFF = "0";
	public static String CACHE_CONTROL_SWITCH = "cache_switch";
	protected final Log logger = LogFactory.getLog(this.getClass());
	private static JCS lookUpCache;
	private ServletContext servletContext;
	private Properties cacheConfigProperties = null;
	private final Vector jscManagedCacheList = new Vector();
	private QueryService queryService;

	public JCSCacheManager() {
		this.jscManagedCacheList.add(LOOKUP_OBJECT_CACHE_NAME);
	}

	public void configure() throws IOException {
		super.configure();
		Properties p = new Properties();
		p.load(this.getServletContext().getResourceAsStream(SystemProperties.getProperty(JCS_CONFIG_FILE_PATH)));
		CompositeCacheManager ccm = CompositeCacheManager.getUnconfiguredInstance();
		ccm.configure(p);
		this.setCacheConfigProperties(p);

		try {
			this.initializeLookUpCache();
		} catch (CacheException var4) {
			this.logger.error("Exception while initializing LookUp object cache", var4);
		}
	}

	private void initializeLookUpCache() throws CacheException {
		lookUpCache = JCS.getInstance(LOOKUP_OBJECT_CACHE_NAME);
		JCSCacheEventHandler eventHandler = new JCSCacheEventHandler();
		IElementAttributes elementAttributes = lookUpCache.getDefaultElementAttributes();
		elementAttributes.addElementEventHandler(eventHandler);
		lookUpCache.setDefaultElementAttributes(elementAttributes);
		if (SystemProperties.getProperty(CACHE_LOAD_ON_STARTUP).equalsIgnoreCase(CACHE_PROPERTY_VALUE_TRUE)) {
			this.loadDataOnStartUp();
		}
	}

	public Object getObject(String key) {
		if (SystemProperties.getProperty(CACHE_CONTROL_SWITCH).equalsIgnoreCase(CACHE_CONTROL_SWITCH_ON)) {
			return lookUpCache == null ? null : lookUpCache.get(key);
		} else {
			return null;
		}
	}

	public void putObject(String key, Object objectToCache) {
		try {
			if (SystemProperties.getProperty(CACHE_CONTROL_SWITCH).equalsIgnoreCase(CACHE_CONTROL_SWITCH_ON) && lookUpCache != null) {
				lookUpCache.put(key, objectToCache);
			}
		} catch (CacheException var4) {
			this.logger.error("Exception in caching the object with key " + key, var4);
		}
	}

	public void clearCache(String region) {
		try {
			if (region.equals(LOOKUP_OBJECT_CACHE_NAME)) {
				lookUpCache.clear();
			}
		} catch (CacheException var3) {
			this.logger.error("Exception in clearing the cache for the region " + region);
		}
	}

	public void clearCache() {
		this.clearCache(LOOKUP_OBJECT_CACHE_NAME);
	}

	private void loadDataOnStartUp() {
		this.loadLookUpCache();
	}

	public abstract void loadLookUpCache();

	public void refreshLookUpCache() {
		this.clearCache(LOOKUP_OBJECT_CACHE_NAME);
		this.loadLookUpCache();
	}

	public Properties getCacheConfigProperties() {
		return this.cacheConfigProperties;
	}

	public void setCacheConfigProperties(Properties cacheConfigProperties) {
		this.cacheConfigProperties = cacheConfigProperties;
	}

	public Vector getJscManagedCacheList() {
		return this.jscManagedCacheList;
	}

	public QueryService getQueryService() {
		return this.queryService;
	}

	public void setQueryService(QueryService queryService) {
		this.queryService = queryService;
	}

	public ServletContext getServletContext() {
		return this.servletContext;
	}

	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}
}
