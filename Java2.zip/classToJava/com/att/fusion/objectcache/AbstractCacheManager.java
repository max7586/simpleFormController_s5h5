//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.objectcache;

import com.att.fusion.objectcache.support.FusionCacheManager;
import java.io.IOException;

public abstract class AbstractCacheManager implements FusionCacheManager {
	public AbstractCacheManager() {
	}

	public Object getObject(String key) {
		return null;
	}

	public void putObject(String key, Object objectToCache) {
	}

	public boolean isObjectInCache(String key) {
		return false;
	}

	public void removeObject(String key) {
	}

	public void clearCache() {
	}

	public void configure() throws IOException {
	}
}
