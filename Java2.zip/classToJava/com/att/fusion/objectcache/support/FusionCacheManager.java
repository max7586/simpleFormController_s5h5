//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.objectcache.support;

import com.att.fusion.FusionObject;
import java.io.IOException;

public interface FusionCacheManager extends FusionObject {
	Object getObject(String var1);

	void putObject(String var1, Object var2);

	boolean isObjectInCache(String var1);

	void removeObject(String var1);

	void clearCache();

	void configure() throws IOException;
}
