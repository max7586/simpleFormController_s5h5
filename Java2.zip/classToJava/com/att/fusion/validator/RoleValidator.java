//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.validator;

import com.att.fusion.domain.Role;
import com.att.fusion.domain.support.DomainVo;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.validator.support.FusionValidator;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FeedbackMessage;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.Errors;

public class RoleValidator extends FusionValidator {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public RoleValidator() {
	}

	public boolean supports(Class givenClass) {
		return givenClass.equals(DomainVo.class) || givenClass.equals(Role.class);
	}

	public void validate(Object obj, Errors errors) {
		Role bean = (Role)obj;
		String auditUserId = (String)bean.getAuditUserId();
		if (bean == null) {
			errors.reject("error.nullcommand", "Null data received");
			if (auditUserId != null) {
				AppUtils.addFeedback(auditUserId, new FeedbackMessage("error.nullcommand", 10, true));
			}
		} else {
			this.logger.info("Validating role form");
			this.logger.info("Validating all required fields have been entered.");
			if (bean.getName() == null || bean.getName().length() < 1) {
				errors.rejectValue("name", "role.error.name.empty", SystemProperties.getProperty("default_error_message"));
				if (auditUserId != null) {
					AppUtils.addFeedback(auditUserId, new FeedbackMessage("role.error.name.empty", 20, true));
				}
			}
		}
	}
}
