//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.validator;

import com.att.fusion.domain.BroadcastMessage;
import com.att.fusion.domain.support.DomainVo;
import com.att.fusion.validator.support.FusionValidator;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FeedbackMessage;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.Errors;

public class BroadcastValidator extends FusionValidator {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public BroadcastValidator() {
	}

	public boolean supports(Class givenClass) {
		return givenClass.equals(DomainVo.class) || givenClass.equals(BroadcastMessage.class);
	}

	public void validate(Object obj, Errors errors) {
		BroadcastMessage bean = (BroadcastMessage)obj;
		String auditUserId = (String)bean.getAuditUserId();
		if (bean == null) {
			errors.reject("error.nullcommand", "Null data received");
			if (auditUserId != null) {
				AppUtils.addFeedback(auditUserId, new FeedbackMessage("error.nullcommand", 10, true));
			}
		} else {
			this.logger.info("Validating broadcast message form");
			this.logger.info("Validating all required fields have been entered.");
			if (bean.getMessageText() == null || bean.getMessageText().length() < 1) {
				errors.rejectValue("messageText", "broadcast.error.messageText.empty");
				if (auditUserId != null) {
					AppUtils.addFeedback(auditUserId, new FeedbackMessage("broadcast.error.messageText.empty", 20, true));
				}
			}

			if (bean.getStartDate() == null) {
				errors.rejectValue("startDate", "broadcast.error.startDate.empty");
				if (auditUserId != null) {
					AppUtils.addFeedback(auditUserId, new FeedbackMessage("broadcast.error.startDate.empty", 20, true));
				}
			}

			if (bean.getEndDate() == null) {
				errors.rejectValue("endDate", "broadcast.error.endDate.empty");
				if (auditUserId != null) {
					AppUtils.addFeedback(auditUserId, new FeedbackMessage("broadcast.error.endDate.empty", 20, true));
				}
			}

			if (bean.getSortOrder() == null) {
				errors.rejectValue("sortOrder", "broadcast.error.sortOrder.empty");
				if (auditUserId != null) {
					AppUtils.addFeedback(auditUserId, new FeedbackMessage("broadcast.error.sortOrder.empty", 20, true));
				}
			}
		}
	}
}
