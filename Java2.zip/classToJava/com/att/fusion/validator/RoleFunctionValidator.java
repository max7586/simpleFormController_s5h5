//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.validator;

import com.att.fusion.domain.RoleFunction;
import com.att.fusion.domain.support.DomainVo;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.validator.support.FusionValidator;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FeedbackMessage;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.Errors;

public class RoleFunctionValidator extends FusionValidator {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public RoleFunctionValidator() {
	}

	public boolean supports(Class givenClass) {
		return givenClass.equals(DomainVo.class) || givenClass.equals(RoleFunction.class);
	}

	public void validate(Object obj, Errors errors) {
		RoleFunction bean = (RoleFunction)obj;
		String auditUserId = (String)bean.getAuditUserId();
		if (bean == null) {
			errors.reject("error.nullcommand", "Null data received");
			if (auditUserId != null) {
				AppUtils.addFeedback(auditUserId, new FeedbackMessage("error.nullcommand", 10, true));
			}
		} else {
			this.logger.info("Validating role function form");
			this.logger.info("Validating all required fields have been entered.");
			if (bean.getCode() == null || bean.getCode().length() < 1) {
				errors.rejectValue("code", "role-function.error.code.empty", SystemProperties.getProperty("default_error_message"));
				if (auditUserId != null) {
					AppUtils.addFeedback(auditUserId, new FeedbackMessage("role-function.error.code.empty", 20, true));
				}
			}

			if (bean.getName() == null || bean.getName().length() < 1) {
				errors.rejectValue("name", "role-function.error.name.empty", SystemProperties.getProperty("default_error_message"));
				if (auditUserId != null) {
					AppUtils.addFeedback(auditUserId, new FeedbackMessage("role-function.error.name.empty", 20, true));
				}
			}
		}
	}
}
