//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.exception.resolver;

import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FusionController;
import com.att.fusion.web.support.FusionFormController;
import com.att.fusion.web.support.MessagesList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

public class FusionRuntimeExceptionResolver implements HandlerExceptionResolver {
	public FusionRuntimeExceptionResolver() {
	}

	public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex) {
		Log logger = LogFactory.getLog(handler.getClass());
		FusionController controller = (FusionController)handler;
		FusionFormController formController = null;
		MessagesList messages = controller.getCustomMessages();
		logger.error("An error occurred while processing the controller:");
		AppUtils.processError(ex, logger, request, messages);
		if (controller instanceof FusionFormController) {
			formController = (FusionFormController)controller;
			return formController.handleError(request);
		} else {
			return new ModelAndView(controller.getExceptionView());
		}
	}
}
