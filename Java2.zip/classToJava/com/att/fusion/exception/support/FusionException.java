//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.exception.support;

import com.att.fusion.FusionObject;

public interface FusionException extends FusionObject {
}
