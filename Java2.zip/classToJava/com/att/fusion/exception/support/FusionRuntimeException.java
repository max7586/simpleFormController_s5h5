//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.exception.support;

public class FusionRuntimeException extends RuntimeException implements FusionException {
	public FusionRuntimeException() {
		this("");
	}

	public FusionRuntimeException(String message) {
		super(message);
	}
}
