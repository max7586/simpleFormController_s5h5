//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.exception;

import com.att.fusion.exception.support.FusionRuntimeException;

public class SessionExpiredException extends FusionRuntimeException {
	public static final String MESSAGE = "Your session has expired. Please login again.";

	public SessionExpiredException() {
		super("Your session has expired. Please login again.");
	}
}
