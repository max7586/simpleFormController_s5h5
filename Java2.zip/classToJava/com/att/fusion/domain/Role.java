//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.domain;

import com.att.fusion.domain.support.DomainVo;
import java.util.Set;
import java.util.TreeSet;

public class Role extends DomainVo {
	private String name;
	private boolean active;
	private Integer priority;
	private Set roleFunctions = new TreeSet();
	private Set childRoles = new TreeSet();

	public Role() {
	}

	public String getName() {
		return this.name;
	}

	public boolean getActive() {
		return this.active;
	}

	public Set getRoleFunctions() {
		return this.roleFunctions;
	}

	public Integer getPriority() {
		return this.priority;
	}

	public Set getChildRoles() {
		return this.childRoles;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setRoleFunctions(Set roleFunctions) {
		this.roleFunctions = roleFunctions;
	}

	public void setPriority(Integer priority) {
		this.priority = priority;
	}

	public void setChildRoles(Set childRoles) {
		this.childRoles = childRoles;
	}

	public void addRoleFunction(RoleFunction roleFunction) {
		this.roleFunctions.add(roleFunction);
	}

	public void addChildRole(Role role) {
		this.childRoles.add(role);
	}

	public void removeChildRole(Long roleId) {
		for(Role childRole : this.childRoles) {
			if (childRole.getId().equals(roleId)) {
				this.childRoles.remove(childRole);
				break;
			}
		}
	}

	public void removeRoleFunction(String roleFunctionCd) {
		for(RoleFunction roleFunction : this.roleFunctions) {
			if (roleFunction.getCode().equals(roleFunctionCd)) {
				this.roleFunctions.remove(roleFunction);
				break;
			}
		}
	}

	public int compareTo(Object obj) {
		String c1 = this.getName();
		String c2 = ((Role)obj).getName();
		return c1 != null && c2 != null ? c1.compareTo(c2) : 1;
	}
}
