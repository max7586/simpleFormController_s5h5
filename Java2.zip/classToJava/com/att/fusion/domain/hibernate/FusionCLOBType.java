//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.domain.hibernate;

import java.io.Serializable;
import java.io.StringReader;
import java.sql.Clob;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.HibernateException;
import org.hibernate.usertype.UserType;

public class FusionCLOBType implements UserType {
	private static final int[] SqlTypes = new int[]{2005};
	protected final Log logger = LogFactory.getLog(this.getClass());

	public FusionCLOBType() {
	}

	public int[] sqlTypes() {
		return SqlTypes;
	}

	public Class returnedClass() {
		return null;
	}

	public boolean equals(Object mappedAttribute1, Object mappedAttribute2) throws HibernateException {
		return mappedAttribute1 == mappedAttribute2 || mappedAttribute1 != null && mappedAttribute2 != null && mappedAttribute1.equals(mappedAttribute2);
	}

	public int hashCode(Object mappedAttribute) throws HibernateException {
		return mappedAttribute.hashCode();
	}

	public Object nullSafeGet(ResultSet rs, String[] names, Object owner) throws HibernateException, SQLException {
		String xmlTypeAsString = null;
		Clob clob = rs.getClob(names[0]);
		if (clob != null) {
			xmlTypeAsString = clob.getSubString(1L, (int)clob.length());
		}

		return xmlTypeAsString;
	}

	public void nullSafeSet(PreparedStatement st, Object value, int index) throws HibernateException, SQLException {
		if (value != null) {
			System.out.println("Value passed to nullSafeSet() = " + value);
			StringReader r = new StringReader((String)value);
			st.setCharacterStream(index, r, ((String)value).length());
		} else {
			st.setNull(index, SqlTypes[0]);
		}
	}

	public Object deepCopy(Object mappedAttribute) throws HibernateException {
		return null;
	}

	public boolean isMutable() {
		return false;
	}

	public Serializable disassemble(Object mappedAttribute) throws HibernateException {
		return null;
	}

	public Object assemble(Serializable cachedState, Object owner) throws HibernateException {
		return null;
	}

	public Object replace(Object original, Object target, Object owner) throws HibernateException {
		return null;
	}
}
