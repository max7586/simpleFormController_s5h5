//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.domain;

import com.att.fusion.domain.support.DomainVo;
import java.io.Serializable;
import java.util.Date;

public class AuditLog extends DomainVo {
	public static final String CD_ACTIVITY_LOGIN = "login";
	public static final String CD_ACTIVITY_LOGOUT = "logout";
	private String activityCode;
	private Serializable affectedRecordId;
	private String comments;

	public AuditLog() {
		this.setCreated(new Date());
	}

	public String getActivityCode() {
		return this.activityCode;
	}

	public String getComments() {
		return this.comments;
	}

	public Serializable getAffectedRecordId() {
		return this.affectedRecordId;
	}

	public void setActivityCode(String activityCode) {
		this.activityCode = activityCode;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	public void setAffectedRecordId(Serializable affectedRecordId) {
		this.affectedRecordId = affectedRecordId;
	}
}
