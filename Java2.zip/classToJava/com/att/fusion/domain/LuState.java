//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.domain;

import com.att.fusion.domain.support.DomainVo;

public class LuState extends DomainVo {
	private String abbr;
	private String state;

	LuState() {
	}

	public String getState() {
		return this.state;
	}

	public String getAbbr() {
		return this.abbr;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setAbbr(String abbr) {
		this.abbr = abbr;
	}

	public int compareTo(Object obj) {
		String c1 = this.getState();
		String c2 = ((LuState)obj).getState();
		return c1.compareTo(c2);
	}
}
