//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.domain;

import com.att.fusion.domain.support.FusionVo;
import com.att.fusion.domain.support.NameValueId;
import java.io.Serializable;

public class ChartData extends FusionVo implements Serializable {
	private NameValueId nameValueId;
	private String secondaryValue;
	private String tertiaryValue;
	private String quaternaryValue;

	public ChartData() {
	}

	public String getSecondaryValue() {
		return this.secondaryValue;
	}

	public String getQuaternaryValue() {
		return this.quaternaryValue;
	}

	public String getTertiaryValue() {
		return this.tertiaryValue;
	}

	public NameValueId getNameValueId() {
		return this.nameValueId;
	}

	public void setSecondaryValue(String secondaryValue) {
		this.secondaryValue = secondaryValue;
	}

	public void setQuaternaryValue(String quaternaryValue) {
		this.quaternaryValue = quaternaryValue;
	}

	public void setTertiaryValue(String tertiaryValue) {
		this.tertiaryValue = tertiaryValue;
	}

	public void setNameValueId(NameValueId nameValueId) {
		this.nameValueId = nameValueId;
	}

	public String getValue() {
		return this.getNameValueId().getValue();
	}

	public String getLabel() {
		return this.getNameValueId().getLabel();
	}
}
