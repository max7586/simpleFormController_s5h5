//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.domain;

import com.att.fusion.domain.support.DomainVo;
import java.util.Date;
import java.util.Set;
import java.util.TreeSet;

public class User extends DomainVo {
	private Long orgId;
	private Long managerId;
	private String firstName;
	private String middleInitial;
	private String lastName;
	private String phone;
	private String fax;
	private String cellular;
	private String email;
	private Long addressId;
	private String alertMethodCd;
	private String hrid;
	private String sbcid;
	private String orgCode;
	private String address1;
	private String address2;
	private String city;
	private String state;
	private String zipCode;
	private String country;
	private String managerAttuid;
	private String locationClli;
	private String businessCountryCode;
	private String businessCountryName;
	private String departmentCode;
	private String department;
	private String companyCode;
	private String company;
	private String zipCodeSuffix;
	private String jobTitle;
	private String commandChain;
	private String loginId;
	private String loginPwd;
	private Date lastLoginDate;
	private boolean active;
	private boolean internal;
	private Long selectedProfileId;
	private Set roles = new TreeSet();
	private Set pseudoRoles = new TreeSet();

	public User() {
	}

	public Long getAddressId() {
		return this.addressId;
	}

	public String getAlertMethodCd() {
		return this.alertMethodCd;
	}

	public String getCellular() {
		return this.cellular;
	}

	public String getEmail() {
		return this.email;
	}

	public String getFax() {
		return this.fax;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public String getHrid() {
		return this.hrid;
	}

	public Date getLastLoginDate() {
		return this.lastLoginDate;
	}

	public String getLastName() {
		return this.lastName;
	}

	public String getLoginId() {
		return this.loginId;
	}

	public String getLoginPwd() {
		return this.loginPwd;
	}

	public Long getManagerId() {
		return this.managerId;
	}

	public String getMiddleInitial() {
		return this.middleInitial;
	}

	public String getOrgCode() {
		return this.orgCode;
	}

	public Long getOrgId() {
		return this.orgId;
	}

	public String getPhone() {
		return this.phone;
	}

	public String getSbcid() {
		return this.sbcid;
	}

	public Set getRoles() {
		return this.roles;
	}

	public boolean getActive() {
		return this.active;
	}

	public boolean getInternal() {
		return this.internal;
	}

	public String getAddress1() {
		return this.address1;
	}

	public String getAddress2() {
		return this.address2;
	}

	public String getCity() {
		return this.city;
	}

	public String getCountry() {
		return this.country;
	}

	public String getState() {
		return this.state;
	}

	public String getZipCode() {
		return this.zipCode;
	}

	public String getBusinessCountryCode() {
		return this.businessCountryCode;
	}

	public String getCommandChain() {
		return this.commandChain;
	}

	public String getCompany() {
		return this.company;
	}

	public String getCompanyCode() {
		return this.companyCode;
	}

	public String getDepartment() {
		return this.department;
	}

	public String getJobTitle() {
		return this.jobTitle;
	}

	public String getLocationClli() {
		return this.locationClli;
	}

	public String getManagerAttuid() {
		return this.managerAttuid;
	}

	public String getZipCodeSuffix() {
		return this.zipCodeSuffix;
	}

	public String getDepartmentCode() {
		return this.departmentCode;
	}

	public String getBusinessCountryName() {
		return this.businessCountryName;
	}

	public Set getPseudoRoles() {
		return this.pseudoRoles;
	}

	public Long getSelectedProfileId() {
		return this.selectedProfileId;
	}

	public void setAddressId(Long addressId) {
		this.addressId = addressId;
	}

	public void setAlertMethodCd(String alertMethodCd) {
		this.alertMethodCd = alertMethodCd;
	}

	public void setCellular(String cellular) {
		this.cellular = cellular;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setHrid(String hrid) {
		this.hrid = hrid;
	}

	public void setLastLoginDate(Date lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}

	public void setLoginPwd(String loginPwd) {
		this.loginPwd = loginPwd;
	}

	public void setManagerId(Long managerId) {
		this.managerId = managerId;
	}

	public void setMiddleInitial(String middleInitial) {
		this.middleInitial = middleInitial;
	}

	public void setOrgCode(String orgCode) {
		this.orgCode = orgCode;
	}

	public void setOrgId(Long orgId) {
		this.orgId = orgId;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public void setSbcid(String sbcid) {
		this.sbcid = sbcid;
	}

	public void setRoles(Set roles) {
		this.roles = roles;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public void setInternal(boolean internal) {
		this.internal = internal;
	}

	public void setAddress1(String address1) {
		this.address1 = address1;
	}

	public void setAddress2(String address2) {
		this.address2 = address2;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public void setBusinessCountryCode(String businessCountryCode) {
		this.businessCountryCode = businessCountryCode;
	}

	public void setCommandChain(String commandChain) {
		this.commandChain = commandChain;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public void setDepartment(String department) {
		this.department = department;
	}

	public void setJobTitle(String jobTitle) {
		this.jobTitle = jobTitle;
	}

	public void setLocationClli(String locationClli) {
		this.locationClli = locationClli;
	}

	public void setManagerAttuid(String managerAttuid) {
		this.managerAttuid = managerAttuid;
	}

	public void setZipCodeSuffix(String zipCodeSuffix) {
		this.zipCodeSuffix = zipCodeSuffix;
	}

	public void setDepartmentCode(String departmentCode) {
		this.departmentCode = departmentCode;
	}

	public void setBusinessCountryName(String businessCountryName) {
		this.businessCountryName = businessCountryName;
	}

	public void setPseudoRoles(Set pseudoRoles) {
		this.pseudoRoles = pseudoRoles;
	}

	public void setSelectedProfileId(Long selectedProfileId) {
		this.selectedProfileId = selectedProfileId;
	}

	public void addRole(Role role) {
		this.roles.add(role);
	}

	public int compareTo(Object obj) {
		User user = (User)obj;
		String c1 = this.getLastName() + this.getFirstName() + this.getMiddleInitial();
		String c2 = user.getLastName() + user.getFirstName() + user.getMiddleInitial();
		return c1.compareTo(c2);
	}
}
