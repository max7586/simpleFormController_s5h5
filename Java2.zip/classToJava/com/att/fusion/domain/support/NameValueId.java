//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.domain.support;

import java.io.Serializable;

public class NameValueId implements Serializable {
	private String label;
	private String value;

	public NameValueId() {
	}

	public NameValueId(String value, String label) {
		this.setValue(value);
		this.setLabel(label);
	}

	public String getLabel() {
		return this.label;
	}

	public String getValue() {
		return this.value;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public boolean equals(Object o) {
		if (this == o) {
			return true;
		} else if (o == null) {
			return false;
		} else if (!(o instanceof NameValueId)) {
			return false;
		} else {
			NameValueId nameValueId = (NameValueId)o;
			if (!this.getValue().equals(nameValueId.getValue())) {
				return false;
			} else {
				return this.getLabel().equals(nameValueId.getLabel());
			}
		}
	}

	public int hashCode() {
		return this.getValue().hashCode();
	}
}
