//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.domain.support;

import com.att.fusion.exception.FusionXmlBeanCreationException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import org.apache.xmlbeans.XmlOptions;

public interface IXmlDomainVo {
	Class getXmlBeanClass();

	String getXmlText();

	public static class FusionXmlBeanFactory {
		public static String FACTORY_METHOD_NEW_INSTANCE = "newInstance";
		public static String FACTORY_METHOD_PARSE = "parse";
		public static String FACTORY_CLASS_NAME = "Factory";

		public FusionXmlBeanFactory() {
		}

		public static Object getEmptyXmlBeanInstance(IXmlDomainVo xmlDomainVo) throws FusionXmlBeanCreationException {
			Class xmlBeanClass = xmlDomainVo.getXmlBeanClass();
			return getEmptyXmlBeanInstance(xmlBeanClass);
		}

		public static Object getLoadedXmlBeanInstance(IXmlDomainVo xmlDomainVo) throws FusionXmlBeanCreationException {
			return getLoadedXmlBeanInstance(xmlDomainVo.getXmlBeanClass(), xmlDomainVo.getXmlText());
		}

		public static Object getLoadedXmlBeanInstance(Class xmlBeanClass, String xmlText) throws FusionXmlBeanCreationException {
			Object xmlBeanInstance = null;
			Class targetClass = null;
			if (isClassOfXmlBeanType(xmlBeanClass)) {
				targetClass = getXmlBeanFactoryClass(xmlBeanClass);
				if (targetClass != null) {
					try {
						Class[] paramTypes = new Class[]{String.class, XmlOptions.class};
						XmlOptions xmlOptions = new XmlOptions();
						xmlOptions.setSavePrettyPrint();
						Object[] paramValues = new Object[]{xmlText, xmlOptions};
						return invokeMethod(targetClass, FACTORY_METHOD_PARSE, paramTypes, paramValues);
					} catch (NoSuchMethodException var7) {
						throw new FusionXmlBeanCreationException("XMLBean Class does not have a factory method named newInstance() - " + var7.getMessage());
					} catch (InvocationTargetException var8) {
						var8.printStackTrace();
						throw new FusionXmlBeanCreationException(
								"Exception while invoking the newInstance() factory method on the XMLBean class - " + var8.getMessage()
						);
					} catch (IllegalAccessException var9) {
						throw new FusionXmlBeanCreationException("Unable to access the newInstace() factory method in the XMLBean - " + var9.getMessage());
					}
				} else {
					throw new FusionXmlBeanCreationException("Cannot find the Factory class inside the specified XMLBean class - " + xmlBeanClass);
				}
			} else {
				throw new FusionXmlBeanCreationException("Cannot create an XMLBean object from a class which does not implement XmlObject interface");
			}
		}

		public static Object getEmptyXmlBeanInstance(Class xmlBeanClass) throws FusionXmlBeanCreationException {
			Class targetClass = null;
			Object xmlBeanInstance = null;
			if (isClassOfXmlBeanType(xmlBeanClass)) {
				targetClass = getXmlBeanFactoryClass(xmlBeanClass);
				if (targetClass != null) {
					try {
						Class[] paramTypes = new Class[]{XmlOptions.class};
						XmlOptions xmlOptions = new XmlOptions();
						xmlOptions.setSavePrettyPrint();
						Object[] paramValues = new Object[]{xmlOptions};
						return invokeMethod(targetClass, FACTORY_METHOD_NEW_INSTANCE, paramTypes, paramValues);
					} catch (NoSuchMethodException var6) {
						throw new FusionXmlBeanCreationException("XMLBean Class does not have a factory method named newInstance() - " + var6.getMessage());
					} catch (InvocationTargetException var7) {
						throw new FusionXmlBeanCreationException(
								"Exception while invoking the newInstance() factory method on the XMLBean class - " + var7.getMessage()
						);
					} catch (IllegalAccessException var8) {
						throw new FusionXmlBeanCreationException("Unable to access the newInstace() factory method in the XMLBean - " + var8.getMessage());
					}
				} else {
					throw new FusionXmlBeanCreationException("Cannot find the Factory class inside the specified XMLBean class - " + xmlBeanClass);
				}
			} else {
				throw new FusionXmlBeanCreationException("Cannot create an XMLBean object from a class which does not implement XmlObject interface");
			}
		}

		public static boolean isClassOfXmlBeanType(Class inputClass) {
			Class implementedInterface = null;
			boolean isClassXmlBeanType = false;
			Class[] implementedInterfaces = inputClass.getInterfaces();
			if (implementedInterfaces != null && implementedInterfaces.length > 0) {
				for(int i = 0; i < implementedInterfaces.length; ++i) {
					implementedInterface = implementedInterfaces[i];
					if (implementedInterface.getName().equals("org.apache.xmlbeans.XmlObject")) {
						isClassXmlBeanType = true;
						break;
					}
				}
			}

			return isClassXmlBeanType;
		}

		private static Object invokeMethod(Class targetClass, String methodName, Class[] paramTypes, Object[] paramValues) throws NoSuchMethodException, InvocationTargetException, IllegalAccessException {
			Object returnValue = null;
			if (targetClass != null) {
				Method method = null;
				method = targetClass.getMethod(methodName, paramTypes);
				if (method != null) {
					returnValue = method.invoke(targetClass, paramValues);
				}
			}

			return returnValue;
		}

		private static Class getXmlBeanFactoryClass(Class xmlBeanClass) {
			boolean factoryClassFound = false;
			Class targetClass = null;
			Class[] innerClasses = xmlBeanClass.getClasses();

			for(int i = 0; i < innerClasses.length; ++i) {
				targetClass = innerClasses[i];
				if (targetClass.getName().equals(xmlBeanClass.getName() + "$" + "Factory")) {
					factoryClassFound = true;
					break;
				}
			}

			return factoryClassFound ? targetClass : null;
		}
	}
}
