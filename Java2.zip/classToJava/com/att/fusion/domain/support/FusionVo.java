//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.domain.support;

import com.att.fusion.FusionObject;

public class FusionVo implements FusionObject {
    public FusionVo() {
    }
}
