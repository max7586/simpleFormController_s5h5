//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.dao;

import com.att.fusion.dao.support.BatchSupport;
import com.att.fusion.domain.support.DomainVo;
import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface ModelDao extends BatchSupport {
	List getList(Class var1, HashMap var2);

	List getList(Class var1, int var2, int var3, HashMap var4);

	List getList(Class var1, List var2, HashMap var3);

	List getList(Class var1, List var2, String var3, HashMap var4);

	List getList(Class var1, List var2, Integer var3, Integer var4, String var5, HashMap var6);

	List getList(Class var1, String var2, Integer var3, Integer var4, String var5, HashMap var6);

	DomainVo get(Class var1, Serializable var2, HashMap var3);

	void update(DomainVo var1, HashMap var2);

	void remove(DomainVo var1, HashMap var2);

	void remove(Class var1, String var2, HashMap var3);

	List executeQuery(String var1, Class var2, Integer var3, Integer var4, HashMap var5);

	List executeQuery(String var1, Integer var2, Integer var3, HashMap var4);

	List executeNamedQuery(String var1, Map var2, Integer var3, Integer var4, HashMap var5);

	int executeUpdateQuery(String var1, HashMap var2) throws RuntimeException;

	int executeNamedUpdateQuery(String var1, Map var2, HashMap var3) throws RuntimeException;

	void executeCallback(Class var1, Object var2, HashMap var3) throws RuntimeException;

	void flush(HashMap var1);
}
