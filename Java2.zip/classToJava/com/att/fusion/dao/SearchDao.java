//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.dao;

import com.att.fusion.command.support.SearchResult;
import java.util.HashMap;
import java.util.List;

public interface SearchDao {
	SearchResult getSearchResult(
			Class var1, List var2, String var3, boolean var4, String var5, boolean var6, String var7, boolean var8, int var9, int var10, HashMap var11
	);

	List getLookupList(String var1, String var2, String var3, String var4, String var5, HashMap var6);
}
