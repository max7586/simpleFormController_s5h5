//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.dao.hibernate;

import com.att.fusion.FusionObject.Utilities;
import com.att.fusion.command.support.SearchResult;
import com.att.fusion.dao.SearchDao;
import com.att.fusion.dao.support.FusionDao;
import com.att.fusion.dao.support.QueryFilter;
import com.att.fusion.dao.support.SearchFilter;
import com.att.fusion.domain.Lookup;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Criterion;
import org.hibernate.criterion.Expression;
import org.hibernate.criterion.MatchMode;
import org.hibernate.criterion.Order;
import org.springframework.orm.hibernate3.SessionFactoryUtils;

public class SearchDaoImpl extends FusionDao implements SearchDao {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public SearchDaoImpl() {
	}

	public SearchResult getSearchResult(
			Class domainClass,
			List searchCriteria,
			String sortBy1,
			boolean sortBy1Desc,
			String sortBy2,
			boolean sortBy2Desc,
			String sortBy3,
			boolean sortBy3Desc,
			int pageNo,
			int dataSize,
			HashMap additionalParams
	) {
		SearchResult searchResult = new SearchResult();
		int fromIndex = pageNo * searchResult.getPageSize();
		int toIndex = (pageNo + 1) * searchResult.getPageSize() - 1;
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		this.logger.info("Getting " + domainClass.getName().toLowerCase() + " records from rows " + fromIndex + " to " + toIndex + "...");
		Criteria criteria = session.createCriteria(domainClass);
		List filter = new ArrayList();

		for(int i = 0; i < searchCriteria.size(); ++i) {
			SearchFilter searchFilter = (SearchFilter)searchCriteria.get(i);
			filter.add(new QueryFilter(searchFilter));
			MatchMode matchMode = null;
			switch(searchFilter.getMatchMode()) {
				case 10:
					matchMode = MatchMode.ANYWHERE;
					break;
				case 20:
					matchMode = MatchMode.END;
					break;
				case 30:
					matchMode = MatchMode.EXACT;
					break;
				case 40:
					matchMode = MatchMode.START;
			}

			Criterion criterion = null;
			switch(searchFilter.getOperator()) {
				case 110:
					criterion = Expression.idEq(searchFilter.getValue());
					break;
				case 120:
					criterion = Expression.eq(searchFilter.getField(), searchFilter.getValue());
					break;
				case 140:
					criterion = Expression.ilike(searchFilter.getField(), (String)searchFilter.getValue(), matchMode);
			}

			criteria.add(criterion);
		}

		if (Utilities.nvl(sortBy1).length() > 0) {
			Order order = !sortBy1Desc ? Order.asc(sortBy1) : Order.desc(sortBy1);
			criteria.addOrder(order);
		}

		if (Utilities.nvl(sortBy2).length() > 0) {
			Order order = !sortBy2Desc ? Order.asc(sortBy2) : Order.desc(sortBy2);
			criteria.addOrder(order);
		}

		if (Utilities.nvl(sortBy3).length() > 0) {
			Order order = !sortBy3Desc ? Order.asc(sortBy3) : Order.desc(sortBy3);
			criteria.addOrder(order);
		}

		List list = criteria.setFirstResult(fromIndex).setMaxResults(searchResult.getPageSize()).list();
		searchResult = new SearchResult(list);
		searchResult.setPageNo(pageNo);
		if (dataSize >= 0) {
			searchResult.setDataSize(dataSize);
		} else if (pageNo == 0 && list.size() < searchResult.getPageSize()) {
			searchResult.setDataSize(list.size());
		} else {
			StringBuffer filterClause = new StringBuffer("");
			if (filter != null) {
				Iterator i = filter.iterator();

				while(i.hasNext()) {
					if (filterClause.toString().equals("")) {
						filterClause.append(" where 1=1 ");
					}

					QueryFilter filterRow = (QueryFilter)i.next();
					filterClause.append(filterRow.getFilterClause());
				}
			}

			Long count = (Long)session.createQuery("select count(*) from " + domainClass.getName() + filterClause.toString()).uniqueResult();
			searchResult.setDataSize(count.intValue());
		}

		return searchResult;
	}

	public List getLookupList(String dbTable, String dbValueCol, String dbLabelCol, String dbFilter, String dbOrderBy, HashMap additionalParams) {
		this.logger.info("Retrieving " + dbTable + " lookup list...");
		List list = null;
		String dbOrderByCol = dbOrderBy;
		Session session = SessionFactoryUtils.getSession(this.getSessionFactory(), true);
		if (Utilities.nvl(dbOrderBy).length() == 0) {
			dbOrderByCol = dbLabelCol;
			dbOrderBy = dbLabelCol;
		} else if (dbOrderBy.lastIndexOf(" ") > -1) {
			dbOrderByCol = dbOrderBy.substring(0, dbOrderBy.lastIndexOf(" "));
		}

		StringBuffer sql = new StringBuffer();
		sql.append("select distinct ")
				.append(dbLabelCol)
				.append(" as label, ")
				.append(dbValueCol)
				.append(" as value, ")
				.append(dbOrderByCol)
				.append(" as sortOrder ")
				.append("from ")
				.append(dbTable)
				.append(" ")
				.append(Utilities.nvl(dbFilter).length() == 0 ? "" : " where " + dbFilter)
				.append(" order by ")
				.append(dbOrderBy);

		try {
			list = session.createSQLQuery(sql.toString()).addEntity(Lookup.class).list();
		} catch (Exception var12) {
			list = null;
			this.logger.info("The results for the lookup list query [" + sql + "] were empty.");
		}

		return list;
	}
}
