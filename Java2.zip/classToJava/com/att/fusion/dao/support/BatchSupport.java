//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.dao.support;

import java.util.HashMap;
import java.util.LinkedHashSet;

public interface BatchSupport {
	void executeBatch(LinkedHashSet var1, boolean var2, HashMap var3) throws RuntimeException;
}
