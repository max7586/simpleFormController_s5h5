//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.dao.support;

import com.att.fusion.FusionObject;
import java.util.HashSet;
import java.util.Set;

public class Filter implements FusionObject {
	private String name;
	private Set parameters = new HashSet();

	public Filter() {
	}

	public Filter(String name) {
		this();
		this.setName(name);
	}

	public Filter(String name, Set parameters) {
		this(name);
		this.setParameters(parameters);
	}

	public String getName() {
		return this.name;
	}

	public Set getParameters() {
		return this.parameters;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void addParameter(FilterParameter parameter) {
		this.getParameters().add(parameter);
	}

	public void setParameters(Set parameters) {
		this.parameters = parameters;
	}
}
