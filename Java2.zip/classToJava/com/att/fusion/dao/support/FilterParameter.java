//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.dao.support;

import com.att.fusion.FusionObject;

public class FilterParameter implements FusionObject {
	private String name;
	private Object value;

	public FilterParameter() {
	}

	public FilterParameter(String name, Object value) {
		this();
		this.setName(name);
		this.setValue(value);
	}

	public String getName() {
		return this.name;
	}

	public Object getValue() {
		return this.value;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setValue(Object value) {
		this.value = value;
	}
}
