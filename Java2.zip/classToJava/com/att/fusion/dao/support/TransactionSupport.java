//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.dao.support;

import com.att.fusion.dao.hibernate.ModelOperationsCommon;

public abstract class TransactionSupport extends ModelOperationsCommon implements CallbackSupport {
    public TransactionSupport() {
    }
}
