//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.dao.support;

import com.att.fusion.FusionObject;
import org.hibernate.SessionFactory;

public class FusionDao implements FusionObject {
	private SessionFactory sessionFactory;

	public FusionDao() {
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public SessionFactory getSessionFactory() {
		return this.sessionFactory;
	}
}
