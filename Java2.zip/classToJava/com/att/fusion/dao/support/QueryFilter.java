//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.dao.support;

import java.io.Serializable;

public class QueryFilter implements Serializable {
	private String name;
	private String[] value;
	private int type;
	private String operator;
	private String logicalOperator;
	private QueryFilter subExpression;
	public static final int NUMERIC_TYPE = 10;
	public static final int STRING_TYPE = 20;
	public static final int DATE_TYPE = 30;
	public static final int FUNCTION_TYPE = 40;
	public static final int MATH_TYPE = 50;
	public static final String AND_OPERATOR = "and";
	public static final String OR_OPERATOR = "or";
	public static final String BETWEEN_OPERATOR = "between";
	public static final String EQUALS_OPERATOR = "=";
	public static final String IN_OPERATOR = "in";
	public static final String LIKE_OPERATOR = "like";

	public QueryFilter(String name, String value) {
		this(name, "=", value.split("~"), 10, "and", null);
	}

	public QueryFilter(String name, String value, int type) {
		this(name, "=", value.split("~"), type, "and", null);
	}

	public QueryFilter(String name, String value, int type, String logicalOperator) {
		this(name, "=", value.split("~"), type, logicalOperator, null);
	}

	public QueryFilter(String name, String value, String operator, int type) {
		this(name, operator, value.split("~"), type, "and", null);
	}

	public QueryFilter(String name, String operator, String[] value, int type, String logicalOperator, QueryFilter subExpression) {
		this.setName(name);
		this.setOperator(operator);
		this.setValue(value);
		this.setType(type);
		this.setLogicalOperator(logicalOperator);
		this.setSubExpression(subExpression);
	}

	public QueryFilter(SearchFilter searchFilter) {
		String v = null;
		this.setLogicalOperator("and");
		this.setName(searchFilter.getField());
		switch(searchFilter.getType()) {
			case 210:
			case 220:
				this.setType(20);
				v = (String)searchFilter.getValue();
				break;
			case 230:
			case 240:
				this.setType(10);
				v = String.valueOf(searchFilter.getValue());
				break;
			case 250:
				this.setType(20);
				v = Boolean.TRUE.equals((Boolean)searchFilter.getValue()) ? "Y" : "N";
		}

		this.setValue(new String[]{new String(v)});
		switch(searchFilter.getOperator()) {
			case 110:
			case 120:
				this.setOperator("=");
				break;
			case 140:
				this.setOperator("like");
		}
	}

	public String getName() {
		return this.name;
	}

	public String getOperator() {
		return this.operator;
	}

	public int getType() {
		return this.type;
	}

	public String[] getValue() {
		return this.value;
	}

	public String getValue(int i) {
		return i < this.getValue().length ? this.value[i] : "";
	}

	public String getLogicalOperator() {
		return this.logicalOperator;
	}

	public QueryFilter getSubExpression() {
		return this.subExpression;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public void setType(int type) {
		this.type = type;
	}

	public void setValue(String[] value) {
		this.value = value;
	}

	public void setLogicalOperator(String logicalOperator) {
		this.logicalOperator = logicalOperator;
	}

	public void setSubExpression(QueryFilter subExpression) {
		this.subExpression = subExpression;
	}

	public String getFilterClause() {
		StringBuffer filterClause = new StringBuffer();
		filterClause.append(this.getLogicalOperator())
				.append(" ")
				.append(this.getFormattedFilterName(this.getName()))
				.append(" ")
				.append(this.getOperator())
				.append(" ");
		if (this.getOperator().equals("between")) {
			filterClause.append(this.getFormattedFilterValue(this.getValue(0)))
					.append(" ")
					.append("and")
					.append(" ")
					.append(this.getFormattedFilterValue(this.getValue(1)));
		} else if (this.getOperator().equals("like")) {
			filterClause.append("'%");
			filterClause.append(this.getValue(0).toLowerCase());
			filterClause.append("%'");
		} else if (this.getOperator().equals("in")) {
			filterClause.append("(");

			for(int i = 0; i < this.getValue().length; ++i) {
				filterClause.append(this.getValue(i));
				if (i < this.getValue().length - 1) {
					filterClause.append(",");
				}
			}

			filterClause.append(")");
		} else {
			filterClause.append(this.getFormattedFilterValue(this.getValue(0)));
		}

		filterClause.append(" ");
		return filterClause.toString();
	}

	private String getFormattedFilterValue(String value) {
		StringBuffer formattedFilterValue = new StringBuffer(value);
		int type = this.getType();
		switch(type) {
			case 20:
			case 30:
				formattedFilterValue.insert(0, "'");
				formattedFilterValue.append("'");
			case 10:
			case 40:
			case 50:
			default:
				return formattedFilterValue.toString();
		}
	}

	private String getFormattedFilterName(String value) {
		StringBuffer formattedFilterName = new StringBuffer(value);
		String operator = this.getOperator();
		if (operator.equals("like")) {
			formattedFilterName.insert(0, "lower(");
			formattedFilterName.append(")");
		}

		return formattedFilterName.toString();
	}
}
