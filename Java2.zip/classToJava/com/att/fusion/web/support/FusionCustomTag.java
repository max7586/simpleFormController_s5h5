//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web.support;

import java.net.URLDecoder;
import java.net.URLEncoder;

public class FusionCustomTag {
	public FusionCustomTag() {
	}

	public static String encodeUrl(String url) {
		try {
			return URLEncoder.encode(url, "UTF-8");
		} catch (Throwable var2) {
			return url;
		}
	}

	public static String decodeUrl(String url) {
		try {
			return URLDecoder.decode(url, "UTF-8");
		} catch (Throwable var2) {
			return url;
		}
	}

	public static String prefixHttp(String s) {
		return s.startsWith("http://") ? s : "http://" + s;
	}

	public static String nvl(String s) {
		return s == null ? "" : s;
	}

	public static String nvl(String s, String sDefault) {
		return nvl(s).equals("") ? sDefault : s;
	}
}
