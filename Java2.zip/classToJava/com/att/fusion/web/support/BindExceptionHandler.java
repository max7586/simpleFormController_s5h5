//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web.support;

import java.util.Date;
import org.springframework.web.servlet.support.BindStatus;

public class BindExceptionHandler {
	public static final String DEFAULT_ERROR_MESSAGE = "An error was generated while trying to save: ";
	public static final String REQUIRED_ERROR_MESSAGE = "Field is required";
	public static final String START_SEARCH_STRING = "[";
	public static final String END_SEARCH_STRING = "]";

	public BindExceptionHandler() {
	}

	public static synchronized String decode(Object status) {
		BindStatus bindStatus = (BindStatus)status;
		String errorCode = null;
		String rejectedValue = null;
		String errorMessage = null;
		String enteredType = null;
		String fieldType = null;
		StringBuffer message = new StringBuffer("");
		int fieldTypeOffSet = 0;
		errorCode = bindStatus.getErrorCode();
		rejectedValue = escapeHtml(bindStatus.getDisplayValue());
		errorMessage = bindStatus.getErrorMessage();
		if ("typeMismatch".equals(errorCode)) {
			fieldTypeOffSet = errorMessage.indexOf("]");
			enteredType = errorMessage.substring(errorMessage.indexOf("[") + 1, fieldTypeOffSet);
			fieldType = errorMessage.substring(errorMessage.indexOf("[", fieldTypeOffSet + 1) + 1, errorMessage.indexOf("]", fieldTypeOffSet + 1));
			message.append("The value ")
					.append("&#034;")
					.append(rejectedValue)
					.append("&#034;")
					.append(" is ")
					.append(getReadableType(enteredType))
					.append(" while the field only accepts ")
					.append(getReadableType(fieldType));
		} else if ("methodInvocation".equals(errorCode)) {
			message.append("An error was generated while trying to save: ").append(rejectedValue);
		} else if ("required".equals(errorCode)) {
			message.append("Field is required");
		} else {
			message.append("An error was generated while trying to save: ").append(rejectedValue);
		}

		return message.toString();
	}

	public static synchronized String getErrorMessage(Object status) {
		BindStatus bindStatus = (BindStatus)status;
		StringBuffer html = new StringBuffer();
		if (bindStatus != null && bindStatus.getErrorMessage() != null && bindStatus.getErrorMessage().length() > 0) {
			html.append(decode(status));
		}

		return html.toString();
	}

	private static synchronized String getReadableType(String className) {
		String type = "";
		if (className.equals(String.class.getName())) {
			type = "alphanumeric";
		} else if (className.equals(Character.class.getName())) {
			type = "a single character";
		} else if (className.equals(Boolean.class.getName())) {
			type = "boolean";
		} else if (className.equals(Date.class.getName()) || className.equals(java.sql.Date.class.getName())) {
			type = "a date";
		} else if (!className.equals(Byte.class.getName())
				&& !className.equals(Short.class.getName())
				&& !className.equals(Integer.class.getName())
				&& !className.equals(Long.class.getName())
				&& !className.equals(Float.class.getName())
				&& !className.equals(Double.class.getName())) {
			type = className;
		} else {
			type = "numeric";
		}

		return type;
	}

	public static String escapeHtml(String value) {
		value = value.replaceAll("&", "&amp;");
		value = value.replaceAll("<", "&lt;");
		value = value.replaceAll(">", "&gt;");
		value = value.replaceAll("\"", "&quot;");
		value = value.replaceAll("'", "&#039;");
		value = value.replaceAll("\r", " ");
		return value.replaceAll("\n", "<br/>");
	}
}
