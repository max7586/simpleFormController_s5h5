//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web.support;

public interface ControllerProperties {
	String TASK_GET = "get";
	String TASK_DELETE = "delete";
	String TASK_SAVE = "save";
	String TASK_PROCESS = "process";
	String TASK_TOGGLE_ACTIVE = "toggleActive";
	String TASK_DOWNLOAD = "download";
	String TASK_POPUP = "popup";
	String TASK_LOOKUP = "lookup";
	String TASK_ADD_ROW = "addRow";
	String TASK_APPROVE = "approve";
	String TASK_REJECT = "reject";
	String TASK_RESET = "reset";
	String TASK_ASSIGN = "assign";
	String TASK_CUT = "cut";
	String TASK_COPY = "copy";
	String TASK_PASTE = "paste";
	String TASK_SELECT = "select";
}
