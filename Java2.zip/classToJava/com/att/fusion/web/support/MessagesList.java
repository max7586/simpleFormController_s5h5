//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web.support;

import java.util.ArrayList;
import java.util.List;

public class MessagesList {
	private boolean successMessageDisplayed = true;
	private boolean includeCauseInCustomExceptions = false;
	private List successMessages;
	private List exceptionMessages;

	public MessagesList() {
		this.setExceptionMessages(new ArrayList());
		this.setSuccessMessages(new ArrayList());
	}

	public MessagesList(boolean displaySuccess) {
		this();
		this.setSuccessMessageDisplayed(displaySuccess);
	}

	public List getExceptionMessages() {
		return this.exceptionMessages;
	}

	public List getSuccessMessages() {
		return this.successMessages;
	}

	public boolean isSuccessMessageDisplayed() {
		return this.successMessageDisplayed;
	}

	public boolean isIncludeCauseInCustomExceptions() {
		return this.includeCauseInCustomExceptions;
	}

	public void setExceptionMessages(List exceptionMessages) {
		this.exceptionMessages = exceptionMessages;
	}

	public void setSuccessMessages(List successMessages) {
		this.successMessages = successMessages;
	}

	public void setSuccessMessageDisplayed(boolean successMessageDisplayed) {
		this.successMessageDisplayed = successMessageDisplayed;
	}

	public void setIncludeCauseInCustomExceptions(boolean includeCauseInCustomExceptions) {
		this.includeCauseInCustomExceptions = includeCauseInCustomExceptions;
	}

	public void addSuccessMessage(FeedbackMessage message) {
		this.getSuccessMessages().add(message);
	}

	public void addExceptionMessage(FeedbackMessage message) {
		this.getExceptionMessages().add(message);
	}

	public boolean hasExceptionMessages() {
		return !this.getExceptionMessages().isEmpty();
	}

	public boolean hasSuccessMessages() {
		return !this.getSuccessMessages().isEmpty();
	}
}
