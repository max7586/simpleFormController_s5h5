//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web.support;

import com.att.fusion.service.DomainService;
import com.att.fusion.service.QueryService;
import com.att.fusion.web.support.FusionController.StaticMessageHandler;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class FusionBaseController extends AbstractController implements FusionController {
	private MessagesList customMessages;
	private DomainService domainService;
	private QueryService queryService;
	private String exceptionView;

	public FusionBaseController() {
	}

	public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		String view = request.getRequestURI();
		view = view.substring(view.lastIndexOf(47) + 1, view.lastIndexOf(46));
		this.logger.debug("view: " + view);
		return new ModelAndView(view);
	}

	public MessagesList getCustomMessages() {
		return this.customMessages;
	}

	public DomainService getDomainService() {
		return this.domainService;
	}

	public QueryService getQueryService() {
		return this.queryService;
	}

	public String getExceptionView() {
		return this.exceptionView == null ? "runtime_error_handler" : this.exceptionView;
	}

	public void setDomainService(DomainService domainService) {
		this.domainService = domainService;
	}

	public void setQueryService(QueryService queryService) {
		this.queryService = queryService;
	}

	public void setCustomMessages(MessagesList customMessages) {
		this.customMessages = customMessages;
	}

	public void setExceptionView(String exceptionView) {
		this.exceptionView = exceptionView;
	}

	public Object getContext(HttpServletRequest request) {
		return "user_id = " + UserUtils.getUserId(request);
	}

	public boolean displaySuccessMessaging(HttpServletRequest request) {
		return StaticMessageHandler.displaySuccessMessaging(request);
	}

	public void setSuccessMessagingOn(HttpServletRequest request) {
		StaticMessageHandler.setSuccessMessagingOn(request);
	}

	public void setSuccessMessagingOff(HttpServletRequest request) {
		StaticMessageHandler.setSuccessMessagingOff(request);
	}
}
