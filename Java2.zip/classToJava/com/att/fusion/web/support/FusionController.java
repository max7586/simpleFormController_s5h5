//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web.support;

import com.att.fusion.FusionObject;
import javax.servlet.http.HttpServletRequest;

public interface FusionController extends ControllerProperties, FusionObject {
	MessagesList getCustomMessages();

	void setCustomMessages(MessagesList var1);

	boolean displaySuccessMessaging(HttpServletRequest var1);

	void setSuccessMessagingOn(HttpServletRequest var1);

	void setSuccessMessagingOff(HttpServletRequest var1);

	Object getContext(HttpServletRequest var1);

	String getExceptionView();

	void setExceptionView(String var1);

	public static class StaticMessageHandler {
		public StaticMessageHandler() {
		}

		public static boolean displaySuccessMessaging(HttpServletRequest request) {
			return request.getAttribute("display_success_message") != null;
		}

		public static void setSuccessMessagingOn(HttpServletRequest request) {
			request.setAttribute("display_success_message", "Y");
		}

		public static void setSuccessMessagingOff(HttpServletRequest request) {
			request.removeAttribute("display_success_message");
		}
	}
}
