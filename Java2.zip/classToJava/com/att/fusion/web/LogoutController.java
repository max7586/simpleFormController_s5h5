//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web;

import com.att.fusion.domain.User;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.FusionBaseController;
import com.att.fusion.web.support.UserUtils;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

public class LogoutController extends FusionBaseController {
	public LogoutController() {
	}

	public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelView = null;
		User user = UserUtils.getUserSession(request);
		String loginMethod = UserUtils.getLoginMethod(request);
		Cookie csp = WebUtils.getCookie(request, SystemProperties.getProperty("csp_cookie_name"));
		if (SystemProperties.getProperty("login_method_csp").equals(loginMethod)) {
			modelView = new ModelAndView(
					"redirect:"
							+ SystemProperties.getProperty("csp_logout_url")
							+ "http://"
							+ request.getServerName()
							+ ":"
							+ request.getServerPort()
							+ request.getContextPath()
							+ "/login.htm"
			);
		} else if (SystemProperties.getProperty("login_method_web_junction").equals(loginMethod)) {
			modelView = new ModelAndView("redirect:" + SystemProperties.getProperty("web_junction_logout_url"));
		} else if (SystemProperties.getProperty("login_method_backdoor").equals(loginMethod)) {
			modelView = new ModelAndView("redirect:login_external.htm");
		} else {
			modelView = new ModelAndView("redirect:login.htm");
		}

		request.getSession().invalidate();
		return modelView;
	}
}
