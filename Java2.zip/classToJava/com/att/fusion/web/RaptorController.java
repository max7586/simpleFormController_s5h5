//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web;

import att.raptor.controller.Controller;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FusionBaseController;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class RaptorController extends FusionBaseController {
	public RaptorController() {
	}

	public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) {
		boolean embedded = ServletRequestUtils.getStringParameter(request, "isEmbedded", "N").equals("Y");
		String jsp = "welcome";

		try {
			String actionKey = request.getParameter("action");
			if (actionKey != null && !actionKey.equals("raptor")) {
				jsp = new Controller().processRequest(actionKey, request);
			} else {
				jsp = new Controller().processRequest(request);
			}
		} catch (Throwable var6) {
			AppUtils.processError(var6, this.logger, request);
		}

		if (embedded && jsp.equals("raptor/report_run.jsp")) {
			jsp = "raptor/report_run_embedded.jsp";
		}

		return new ModelAndView(jsp);
	}
}
