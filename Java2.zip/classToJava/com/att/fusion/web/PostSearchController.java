//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web;

import com.att.fusion.command.PostSearchBean;
import com.att.fusion.command.support.SearchResult;
import com.att.fusion.domain.Lookup;
import com.att.fusion.domain.Role;
import com.att.fusion.domain.User;
import com.att.fusion.service.LdapService;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FeedbackMessage;
import com.att.fusion.web.support.FusionFormController;
import com.att.fusion.web.support.MessagesList;
import com.att.fusion.web.support.UserUtils;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.servlet.ModelAndView;

public class PostSearchController extends FusionFormController {
	protected final Log logger = LogFactory.getLog(this.getClass());
	private static List sortByList = null;
	private LdapService ldapService;

	public PostSearchController() {
	}

	private SearchResult loadSearchResultData(HttpServletRequest request, PostSearchBean searchCriteria) throws Exception {
		return this.getLdapService()
				.searchPost(
						searchCriteria.getUser(),
						searchCriteria.getSortBy1(),
						searchCriteria.getSortBy2(),
						searchCriteria.getSortBy3(),
						searchCriteria.getPageNo(),
						searchCriteria.getNewDataSize(),
						UserUtils.getUserId(request)
				);
	}

	protected void onBindOnNewForm(HttpServletRequest request, Object command, BindException errors) throws Exception {
		PostSearchBean postSearch = (PostSearchBean)command;
		postSearch.setSearchResult(this.loadSearchResultData(request, postSearch));
	}

	public ModelAndView reset(HttpServletRequest request, HttpServletResponse response, Object command, ModelAndView modelView, BindException errors) throws Exception {
		PostSearchBean postSearch = (PostSearchBean)command;
		postSearch.resetSearch();
		postSearch.setSearchResult(this.loadSearchResultData(request, postSearch));
		return this.showForm(request, response, errors);
	}

	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, Object command, ModelAndView modelView, BindException errors) throws Exception {
		PostSearchBean postSearch = (PostSearchBean)command;
		HashMap additionalParams = new HashMap();
		additionalParams.put("request", request);
		if (postSearch.getSelected() != null) {
			int numUsersImported = 0;
			Arrays.sort(postSearch.getSelected());

			for(int i = 0; i < postSearch.getPostSbcid().length; ++i) {
				if (Arrays.binarySearch(postSearch.getSelected(), postSearch.getPostSbcid()[i]) >= 0) {
					this.logger.info("Adding ATTUID - " + postSearch.getPostSbcid()[i]);
					User user = new User();
					user.setLastName(postSearch.getPostLastName()[i]);
					user.setFirstName(postSearch.getPostFirstName()[i]);
					if (postSearch.getPostHrid() != null && postSearch.getPostHrid().length > 0) {
						user.setHrid(postSearch.getPostHrid()[i]);
					}

					if (postSearch.getPostPhone() != null && postSearch.getPostPhone().length > 0) {
						user.setPhone(postSearch.getPostPhone()[i]);
					}

					if (postSearch.getPostEmail() != null && postSearch.getPostEmail().length > 0) {
						user.setEmail(postSearch.getPostEmail()[i]);
					}

					if (postSearch.getPostSbcid() != null && postSearch.getPostSbcid().length > 0) {
						user.setSbcid(postSearch.getPostSbcid()[i]);
					}

					if (postSearch.getPostAddress1() != null && postSearch.getPostAddress1().length > 0) {
						user.setAddress1(postSearch.getPostAddress1()[i]);
					}

					if (postSearch.getPostCity() != null && postSearch.getPostCity().length > 0) {
						user.setCity(postSearch.getPostCity()[i]);
					}

					if (postSearch.getPostState() != null && postSearch.getPostState().length > 0) {
						user.setState(postSearch.getPostState()[i]);
					}

					if (postSearch.getPostZipCode() != null && postSearch.getPostZipCode().length > 0) {
						user.setZipCode(postSearch.getPostZipCode()[i]);
					}

					if (postSearch.getPostLocationClli() != null && postSearch.getPostLocationClli().length > 0) {
						user.setLocationClli(postSearch.getPostLocationClli()[i]);
					}

					if (postSearch.getPostBusinessCountryCode() != null && postSearch.getPostBusinessCountryCode().length > 0) {
						user.setBusinessCountryCode(postSearch.getPostBusinessCountryCode()[i]);
					}

					if (postSearch.getPostBusinessCountryName() != null && postSearch.getPostBusinessCountryName().length > 0) {
						List countries = AppUtils.getLookupList(
								"fn_lu_country", "country_cd", "country", "equivalence(country,'" + postSearch.getPostBusinessCountryName()[i] + "') = 1.0", null
						);
						if (countries.size() == 1) {
							Lookup country = (Lookup)countries.get(0);
							user.setCountry(country.getValue());
						} else {
							this.logger
									.debug(
											"No countries or more than one country was found matching the country returned from WEBPHONE. Therefore, no country was set for this user."
									);
						}
					}

					if (postSearch.getPostDepartmentCode() != null && postSearch.getPostDepartmentCode().length > 0) {
						user.setDepartmentCode(postSearch.getPostDepartmentCode()[i]);
					}

					if (postSearch.getPostDepartment() != null && postSearch.getPostDepartment().length > 0) {
						user.setDepartment(postSearch.getPostDepartment()[i]);
					}

					if (postSearch.getPostJobTitle() != null && postSearch.getPostJobTitle().length > 0) {
						user.setJobTitle(postSearch.getPostJobTitle()[i]);
					}

					if (postSearch.getPostManagerAttuid() != null && postSearch.getPostManagerAttuid().length > 0) {
						user.setManagerAttuid(postSearch.getPostManagerAttuid()[i]);
					}

					if (postSearch.getPostCommandChain() != null && postSearch.getPostCommandChain().length > 0) {
						user.setCommandChain(postSearch.getPostCommandChain()[i]);
					}

					if (postSearch.getPostCompanyCode() != null && postSearch.getPostCompanyCode().length > 0) {
						user.setCompanyCode(postSearch.getPostCompanyCode()[i]);
					}

					if (postSearch.getPostCompany() != null && postSearch.getPostCompany().length > 0) {
						user.setCompany(postSearch.getPostCompany()[i]);
					}

					user.setActive(true);
					Role role = new Role();
					role.setId(Long.valueOf(SystemProperties.getProperty("post_default_role_id")));
					user.addRole(role);

					try {
						this.getDomainService().saveDomainObject(user, additionalParams);
						++numUsersImported;
					} catch (Exception var14) {
						MessagesList messages = new MessagesList();
						messages.addExceptionMessage(
								new FeedbackMessage(
										"An error occurred while attempting to import " + user.getFirstName() + " " + user.getLastName() + ": " + var14.getMessage(),
										10
								)
						);
						AppUtils.processError(var14, this.logger, request, messages);
					}
				}
			}

			AppUtils.addFeedback(request.getRequestedSessionId(), new FeedbackMessage(numUsersImported + " profiles were imported successfully.", 40));
		}

		postSearch.setSearchResult(this.loadSearchResultData(request, postSearch));
		return this.showForm(request, response, errors);
	}

	public ModelAndView get(HttpServletRequest request, HttpServletResponse response, Object command, ModelAndView modelView, BindException errors) throws Exception {
		PostSearchBean postSearch = (PostSearchBean)command;
		postSearch.setSearchResult(this.loadSearchResultData(request, postSearch));
		return this.showForm(request, response, errors);
	}

	protected Map referenceData(HttpServletRequest request) throws Exception {
		Map lookupData = new HashMap();
		HashMap existingUsers = new HashMap();
		List list = this.getQueryService().executeNamedQuery("getExistingUserAttuids");
		if (list != null) {
			for(Object[] user : list) {
				String attuid = (String)user[0];
				Long id = (Long)user[1];
				existingUsers.put(attuid, id);
			}
		}

		lookupData.put("existingUsers", existingUsers);
		lookupData.put("sortByList", getSortByList());
		return lookupData;
	}

	public static List getSortByList() {
		if (sortByList == null) {
			sortByList = new ArrayList();
			sortByList.add(new Lookup("Last Name", "last_name"));
			sortByList.add(new Lookup("First Name", "first_name"));
			sortByList.add(new Lookup("HRID", "hrid"));
			sortByList.add(new Lookup("SBCID", "sbcid"));
			sortByList.add(new Lookup("Organization", "org_code"));
			sortByList.add(new Lookup("Email", "email"));
		}

		return sortByList;
	}

	public LdapService getLdapService() {
		return this.ldapService;
	}

	public void setLdapService(LdapService ldapService) {
		this.ldapService = ldapService;
	}
}
