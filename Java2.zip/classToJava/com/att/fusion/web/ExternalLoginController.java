//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web;

import com.att.fusion.command.LoginBean;
import com.att.fusion.service.LoginService;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.FusionFormController;
import com.att.fusion.web.support.UserUtils;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.validation.ObjectError;
import org.springframework.web.servlet.ModelAndView;

public class ExternalLoginController extends FusionFormController {
	protected final Log logger = LogFactory.getLog(this.getClass());
	private LoginService loginService;

	public ExternalLoginController() {
	}

	public ModelAndView process(HttpServletRequest request, HttpServletResponse response, Object command, ModelAndView modelView, BindException errors) throws Exception {
		Map model = new HashMap();
		LoginBean commandBean = (LoginBean)command;
		String loginId = commandBean.getLoginId();
		commandBean = this.getLoginService().findUser(commandBean, (String)request.getAttribute("menu_properties_filename"), null);
		if (commandBean.getUser() == null) {
			String loginErrorMessage = commandBean.getLoginErrorMessage() != null ? commandBean.getLoginErrorMessage() : "login.error.external.invalid";
			model.put("error", loginErrorMessage);
			String[] errorCodes = new String[]{loginErrorMessage};
			errors.addError(new ObjectError("loginBean", errorCodes, null, loginErrorMessage));
			return this.showForm(request, response, errors);
		} else {
			UserUtils.setUserSession(
					request,
					commandBean.getUser(),
					commandBean.getMenu(),
					commandBean.getBusinessDirectMenu(),
					SystemProperties.getProperty("login_method_backdoor")
			);
			this.logger.info(loginId + " exists in the the system.");
			return new ModelAndView("redirect:welcome.htm");
		}
	}

	public LoginService getLoginService() {
		return this.loginService;
	}

	public void setLoginService(LoginService loginService) {
		this.loginService = loginService;
	}
}
