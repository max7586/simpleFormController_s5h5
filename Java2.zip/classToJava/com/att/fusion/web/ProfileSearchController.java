//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web;

import com.att.fusion.command.UserSearchBean;
import com.att.fusion.command.support.SearchBase;
import com.att.fusion.command.support.SearchResult;
import com.att.fusion.dao.support.SearchFilter;
import com.att.fusion.domain.Lookup;
import com.att.fusion.domain.User;
import com.att.fusion.service.SearchService;
import com.att.fusion.web.support.FusionFormController;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class ProfileSearchController extends FusionFormController {
	protected final Log logger = LogFactory.getLog(this.getClass());
	private static List sortByList = null;
	private SearchService searchService;

	public ProfileSearchController() {
	}

	private SearchResult loadSearchResultData(HttpServletRequest request, UserSearchBean searchCriteria) {
		List searchFilter = new ArrayList();
		User user = searchCriteria.getUser();
		if (user.getId() != null && user.getId() > 0L) {
			searchFilter.add(new SearchFilter("id", 110, user.getId()));
		}

		if (nvl(user.getFirstName()).length() > 0) {
			searchFilter.add(new SearchFilter("firstName", 140, user.getFirstName(), 10));
		}

		if (nvl(user.getLastName()).length() > 0) {
			searchFilter.add(new SearchFilter("lastName", 140, user.getLastName(), 10));
		}

		if (nvl(user.getHrid()).length() > 0) {
			searchFilter.add(new SearchFilter("hrid", 120, user.getHrid()));
		}

		if (nvl(user.getEmail()).length() > 0) {
			searchFilter.add(new SearchFilter("email", 140, user.getEmail(), 10));
		}

		searchFilter.add(new SearchFilter("internal", 120, Boolean.FALSE, 0, 250));
		return this.getSearchService()
				.getSearchResult(
						User.class,
						searchFilter,
						searchCriteria.getSortBy1(),
						SearchBase.SORT_BY_MODIFIER_DESC.equals(searchCriteria.getSortByModifier1()),
						searchCriteria.getSortBy2(),
						SearchBase.SORT_BY_MODIFIER_DESC.equals(searchCriteria.getSortByModifier2()),
						searchCriteria.getSortBy3(),
						SearchBase.SORT_BY_MODIFIER_DESC.equals(searchCriteria.getSortByModifier3()),
						searchCriteria.getPageNo(),
						searchCriteria.getNewDataSize(),
						null
				);
	}

	protected void onBindOnNewForm(HttpServletRequest request, Object command, BindException errors) throws Exception {
		UserSearchBean userSearch = (UserSearchBean)command;
		userSearch.setSearchResult(this.loadSearchResultData(request, userSearch));
	}

	public ModelAndView reset(HttpServletRequest request, HttpServletResponse response, Object command, ModelAndView modelView, BindException errors) throws Exception {
		UserSearchBean userSearch = (UserSearchBean)command;
		userSearch.resetSearch();
		userSearch.setSearchResult(this.loadSearchResultData(request, userSearch));
		return this.showForm(request, response, errors);
	}

	public ModelAndView toggleActive(HttpServletRequest request, HttpServletResponse response, Object command, ModelAndView modelView, BindException errors) throws Exception {
		UserSearchBean userSearch = (UserSearchBean)command;
		HashMap additionalParams = new HashMap();
		additionalParams.put("request", request);
		int userId = ServletRequestUtils.getIntParameter(request, "masterId", 0);
		if (userId != 0) {
			User user = (User)this.getDomainService().getDomainObject(User.class, new Long((long)userId));
			user.setActive(!user.getActive());
			this.getDomainService().saveDomainObject(user, additionalParams);
		}

		userSearch.setSearchResult(this.loadSearchResultData(request, userSearch));
		return this.showForm(request, response, errors);
	}

	public ModelAndView get(HttpServletRequest request, HttpServletResponse response, Object command, ModelAndView modelView, BindException errors) throws Exception {
		UserSearchBean userSearch = (UserSearchBean)command;
		userSearch.setSearchResult(this.loadSearchResultData(request, userSearch));
		return this.showForm(request, response, errors);
	}

	protected Map referenceData(HttpServletRequest request) throws Exception {
		Map lookupData = new HashMap();
		lookupData.put("sortByList", getSortByList());
		return lookupData;
	}

	public static List getSortByList() {
		if (sortByList == null) {
			sortByList = new ArrayList();
			sortByList.add(new Lookup("First Name", "firstName"));
			sortByList.add(new Lookup("Last Name", "lastName"));
			sortByList.add(new Lookup("Hrid", "hrid"));
			sortByList.add(new Lookup("Email", "email"));
		}

		return sortByList;
	}

	public SearchService getSearchService() {
		return this.searchService;
	}

	public void setSearchService(SearchService value) {
		this.searchService = value;
	}

	public static String nvl(String s) {
		return s == null ? "" : s;
	}

	public static String nvl(String s, String sDefault) {
		return nvl(s).equals("") ? sDefault : s;
	}
}
