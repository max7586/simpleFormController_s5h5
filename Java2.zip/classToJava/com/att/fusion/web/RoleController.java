//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web;

import com.att.fusion.domain.Role;
import com.att.fusion.domain.RoleFunction;
import com.att.fusion.domain.support.DomainVo;
import com.att.fusion.web.support.FusionFormController;
import java.util.HashMap;
import java.util.Set;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class RoleController extends FusionFormController {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public RoleController() {
	}

	public Object formBackingObject(HttpServletRequest request) {
		int roleId = ServletRequestUtils.getIntParameter(request, "role_id", 0);
		Role role = (Role)this.getDomainService().getDomainObject(Role.class, new Long((long)roleId));
		String roleFunctionId = ServletRequestUtils.getStringParameter(request, "role_function_id", "0");
		if (!roleFunctionId.equals("0")) {
			Set roleFunctions = role.getRoleFunctions();

			for(RoleFunction roleFunction : roleFunctions) {
				if (roleFunctionId.equals(roleFunction.getCode())) {
					roleFunctions.remove(roleFunction);
					break;
				}
			}
		}

		return role;
	}

	public ModelAndView save(HttpServletRequest request, HttpServletResponse response, Object command, ModelAndView modelView, BindException errors) throws Exception {
		DomainVo bean = (DomainVo)command;
		HashMap additionalParams = new HashMap();
		additionalParams.put("request", request);
		this.getDomainService().saveDomainObject(bean, additionalParams);
		return new ModelAndView("redirect:role_list.htm");
	}
}
