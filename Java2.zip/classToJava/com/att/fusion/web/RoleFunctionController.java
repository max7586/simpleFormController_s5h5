//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web;

import com.att.fusion.domain.RoleFunction;
import com.att.fusion.domain.support.DomainVo;
import com.att.fusion.web.support.FusionFormController;
import java.util.HashMap;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class RoleFunctionController extends FusionFormController {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public RoleFunctionController() {
	}

	public Object formBackingObject(HttpServletRequest request) {
		return this.getDomainService().getDomainObject(RoleFunction.class, ServletRequestUtils.getStringParameter(request, "role_function_id", "0"));
	}

	public ModelAndView save(HttpServletRequest request, HttpServletResponse response, Object command, ModelAndView modelView, BindException errors) throws Exception {
		DomainVo bean = (DomainVo)command;
		HashMap additionalParams = new HashMap();
		additionalParams.put("request", request);
		this.getDomainService().saveDomainObject(bean, additionalParams);
		return new ModelAndView("redirect:role_function_list.htm");
	}
}
