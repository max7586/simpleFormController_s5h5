//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web;

import com.att.fusion.command.PickListBean;
import com.att.fusion.domain.Role;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.FeedbackMessage;
import com.att.fusion.web.support.FusionFormController;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeSet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.BindException;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.servlet.ModelAndView;

public class PickListChildRoleController extends FusionFormController {
	protected final Log logger = LogFactory.getLog(this.getClass());

	public PickListChildRoleController() {
	}

	public Object formBackingObject(HttpServletRequest request) {
		PickListBean pickListBean = new PickListBean();
		pickListBean.setParentId(ServletRequestUtils.getLongParameter(request, "role_id", 0L));
		pickListBean.setParentName(ServletRequestUtils.getStringParameter(request, "role_name", "Role Id - " + pickListBean.getParentId()));
		return pickListBean;
	}

	protected Map referenceData(HttpServletRequest request) throws Exception {
		Map lookupData = new HashMap();
		Map params = new HashMap();
		HashMap selectedChildRoles = new HashMap();
		Long roleId = ServletRequestUtils.getLongParameter(request, "role_id");
		Role role = (Role)this.getDomainService().getDomainObject(Role.class, roleId);
		if (role.getChildRoles() != null) {
			for(Role childRole : role.getChildRoles()) {
				selectedChildRoles.put(childRole.getId(), childRole.getId());
			}
		}

		lookupData.put("selectedChildRoles", selectedChildRoles);
		params.put("role_id", roleId);
		lookupData.put("allChildRoles", this.getQueryService().executeNamedQuery("availableChildRoles", params));
		return lookupData;
	}

	public ModelAndView save(HttpServletRequest request, HttpServletResponse response, Object command, ModelAndView modelView, BindException errors) throws Exception {
		PickListBean bean = (PickListBean)command;
		long roleId = bean.getParentId();
		String[] selected = bean.getSelected();
		HashMap additionalParams = new HashMap();
		additionalParams.put("request", request);
		Role role = (Role)this.getDomainService().getDomainObject(Role.class, new Long(roleId));
		role.setChildRoles(new TreeSet());
		if (selected != null) {
			for(int i = 0; i < selected.length; ++i) {
				Long childRoleId = new Long(selected[i]);
				Role childRole = new Role();
				childRole.setId(childRoleId);
				role.addChildRole(childRole);
			}

			this.getDomainService().saveDomainObject(role, additionalParams);
		} else {
			AppUtils.addFeedback(request.getRequestedSessionId(), new FeedbackMessage("At least one child role must be selected.", 10));
		}

		return this.showForm(request, response, errors);
	}
}
