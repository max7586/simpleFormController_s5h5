//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.web;

import com.att.fusion.command.LoginBean;
import com.att.fusion.service.LoginService;
import com.att.fusion.util.SystemProperties;
import com.att.fusion.web.support.FusionBaseController;
import com.att.fusion.web.support.UserUtils;
import esGateKeeper.esGateKeeper;
import java.util.HashMap;
import java.util.Map;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StringUtils;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.util.WebUtils;

public class ProcessCspController extends FusionBaseController {
	public static final String DEFAULT_SUCCESS_VIEW = "welcome";
	public static final String DEFAULT_FAILURE_VIEW = "login";
	public static final String ERROR_MESSAGE_KEY = "error";
	private LoginService loginService;
	protected final Log logger = LogFactory.getLog(this.getClass());

	public ProcessCspController() {
	}

	public ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		Map model = new HashMap();
		LoginBean commandBean = new LoginBean();
		String attuid = this.getAttuid(request);
		if (attuid != null && attuid.length() != 0) {
			commandBean.setAttuid(attuid);
			commandBean = this.getLoginService().findUser(commandBean, (String)request.getAttribute("menu_properties_filename"), null);
			if (commandBean.getUser() == null) {
				String loginErrorMessage = commandBean.getLoginErrorMessage() != null ? commandBean.getLoginErrorMessage() : "login.error.hrid.not-found";
				model.put("error", loginErrorMessage);
				return new ModelAndView("login", "model", model);
			} else {
				UserUtils.setUserSession(
						request,
						commandBean.getUser(),
						commandBean.getMenu(),
						commandBean.getBusinessDirectMenu(),
						SystemProperties.getProperty("login_method_csp")
				);
				this.logger.info(commandBean.getUser().getSbcid() + " exists in the the system.");
				return new ModelAndView("redirect:welcome.htm");
			}
		} else {
			model.put("error", "login.error.hrid.empty");
			return new ModelAndView("login", "model", model);
		}
	}

	public String getAttuid(HttpServletRequest request) {
		String attuid = null;

		try {
			attuid = this.getCspData(request)[5];
		} catch (Throwable var4) {
			this.logger
					.info("An error occurred while attempting to extract the user's ATTUID from their CSP cookie. Here are the details: " + var4.getMessage());
		}

		return attuid;
	}

	public String[] getCspData(HttpServletRequest request) {
		Cookie csp = WebUtils.getCookie(request, SystemProperties.getProperty("csp_cookie_name"));
		String[] cspData = null;
		if (csp != null) {
			String cspCookie = esGateKeeper.esGateKeeper(
					csp.getValue(), SystemProperties.getProperty("csp_gate_keeper_data_key"), SystemProperties.getProperty("csp_gate_keeper_prod_key")
			);
			cspData = StringUtils.delimitedListToStringArray(cspCookie, "|");
		}

		return cspData;
	}

	public LoginService getLoginService() {
		return this.loginService;
	}

	public void setLoginService(LoginService loginService) {
		this.loginService = loginService;
	}
}
