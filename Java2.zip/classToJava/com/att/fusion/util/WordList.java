//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.util;

import java.util.Iterator;
import java.util.TreeMap;

public class WordList {
	private TreeMap words = new TreeMap();
	private int numWords = 0;
	public static final int COMPARE_STRICT = 0;
	public static final int COMPARE_IGNORE_CASE = 1;

	public WordList() {
	}

	public WordList(String text) {
		this(text, " ");
	}

	public WordList(String text, String delimeter) {
		this(text, " ", 1);
	}

	public WordList(String text, String delimeter, int comparisonLevel) {
		this();
		text = this.removeNonWordCharacters(text);
		String[] list = text.split(delimeter);
		if (list != null) {
			this.numWords = list.length;
		}

		for(int i = 0; i < list.length; ++i) {
			String word = list[i];
			if (comparisonLevel == 1) {
				word = word.toLowerCase();
			}

			Integer count = (Integer)this.words.get(word);
			Integer newCount = new Integer(0);
			if (count == null) {
				count = newCount;
			}

			int c = count;
			count = new Integer(++c);
			this.words.put(word, count);
		}
	}

	public double equivalence(WordList list) {
		double equivalence = 0.0;
		double totalMatches = 0.0;
		double maxNumWords = 0.0;
		TreeMap otherWords = list.getWords();
		Iterator i = this.getWords().keySet().iterator();
		if (this.getNumWords() > list.getNumWords()) {
			maxNumWords = (double)this.getNumWords();
		} else {
			maxNumWords = (double)list.getNumWords();
		}

		if (maxNumWords > 0.0) {
			while(i.hasNext()) {
				int count = 0;
				int otherCount = 0;
				String word = (String)i.next();
				count = this.getWords().get(word);
				if (otherWords.get(word) != null) {
					otherCount = otherWords.get(word);
				}

				if (otherCount > 0) {
					if (otherCount == count) {
						totalMatches += (double)count;
					} else {
						totalMatches += (double)Math.abs(count - otherCount);
					}
				}
			}

			equivalence = totalMatches / maxNumWords;
		}

		return equivalence;
	}

	public String toString() {
		StringBuffer sb = new StringBuffer();

		for(String word : this.words.keySet()) {
			Integer count = (Integer)this.words.get(word);
			sb.append(word).append("\t").append("-").append("\t").append(count).append("\n");
		}

		return sb.toString();
	}

	public int getNumWords() {
		return this.numWords;
	}

	public TreeMap getWords() {
		return this.words;
	}

	public void setNumWords(int numWords) {
		this.numWords = numWords;
	}

	public void setWords(TreeMap words) {
		this.words = words;
	}

	private String removeNonWordCharacters(String text) {
		text = text.replaceAll("\\W&&[^ ]", "");
		return text.replaceAll("[!\"#$%&'()*+,-./:;<=>?@^_`{|}~]", "");
	}
}
