//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.util.graphics;

import com.sun.image.codec.jpeg.JPEGCodec;
import com.sun.image.codec.jpeg.JPEGImageEncoder;
import java.awt.Color;
import java.awt.FontMetrics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.image.BufferedImage;
import java.io.IOException;
import java.io.OutputStream;
import java.text.NumberFormat;

public class PieChart {
	private int ImageWidth;
	private int ImageHeight;
	private int margin;
	private DataItems di;
	private Color[] colors = new Color[]{Color.red, Color.blue, Color.cyan, Color.yellow, Color.orange, Color.black};

	public PieChart(int InImageWidth, int InImageHeight, int InMargin, DataItems InDi) {
		this.ImageWidth = InImageWidth;
		this.ImageHeight = InImageHeight;
		this.margin = InMargin;
		this.di = InDi;
	}

	public String createImage(OutputStream stream) throws IOException {
		double startAngle = 0.0;
		double arcAngle = 0.0;
		double theta = 0.0;
		double currentTheta = 0.0;
		double labelTheta = 0.0;
		int PieWidth = this.ImageWidth - 2 * this.margin;
		int PieHeight = this.ImageHeight - 2 * this.margin;
		int Radius = PieWidth / 2;
		double totalNumber = 0.0;
		int colorIndex = 0;
		double labelX = 0.0;
		double labelY = 0.0;
		double percentage = 0.0;
		NumberFormat numberFormatter = NumberFormat.getNumberInstance();
		numberFormatter.setParseIntegerOnly(true);
		JPEGImageEncoder encoder = JPEGCodec.createJPEGEncoder(stream);
		BufferedImage bi = new BufferedImage(this.ImageWidth + 10, this.ImageHeight, 13);
		Graphics2D g2 = bi.createGraphics();
		g2.fillRect(0, 0, bi.getWidth(), bi.getHeight());

		for(int i = 0; i < this.di.itemCount(); ++i) {
			totalNumber += this.di.getNumber(i);
		}

		for(int i = 0; i < this.di.itemCount(); ++i) {
			arcAngle = 360.0 * (this.di.getNumber(i) / totalNumber);
			percentage = this.di.getNumber(i) / totalNumber;
			g2.setColor(this.colors[colorIndex++]);
			if (colorIndex == this.colors.length) {
				colorIndex = 0;
			}

			if (i == 0) {
				g2.fillArc(this.margin, this.margin, PieWidth, PieHeight, (int)(-1.0 * (startAngle - 5.0)), (int)(-1.0 * (arcAngle + 5.0)));
			} else {
				g2.fillArc(this.margin, this.margin, PieWidth, PieHeight, (int)(-1.0 * startAngle), (int)(-1.0 * arcAngle));
			}

			theta = arcAngle * 0.017444444444444446;
			currentTheta += theta;
			labelTheta = currentTheta - theta / 2.0;
			labelX = (double)Radius * Math.cos(labelTheta);
			labelY = (double)Radius * Math.sin(labelTheta);
			Point labelPoint = new Point(PieWidth / 2 + this.margin, PieHeight / 2 + this.margin);
			labelPoint.translate((int)labelX, (int)labelY);
			g2.setColor(Color.black);
			FontMetrics metrics = g2.getFontMetrics();
			String display_text = this.di.getName(i) + " (" + numberFormatter.format(this.di.getNumber(i)) + ")";
			int stringWidth = metrics.stringWidth(display_text);
			int charWidth = metrics.charWidth('M');
			if (labelPoint.x > this.margin + PieWidth / 2) {
				g2.drawString(display_text, labelPoint.x + charWidth, labelPoint.y);
			} else {
				g2.drawString(display_text, labelPoint.x - stringWidth - charWidth, labelPoint.y);
			}

			startAngle += arcAngle;
		}

		encoder.encode(bi);
		return "image/jpg";
	}
}
