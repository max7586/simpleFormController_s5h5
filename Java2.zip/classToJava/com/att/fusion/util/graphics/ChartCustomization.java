//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.util.graphics;

import org.jfree.chart.JFreeChart;

public abstract class ChartCustomization {
	public ChartCustomization() {
	}

	public abstract JFreeChart modify(JFreeChart var1);
}
