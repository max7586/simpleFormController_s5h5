//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.util.graphics;

import com.att.fusion.domain.ChartData;
import java.io.PrintWriter;
import java.util.List;
import javax.servlet.http.HttpSession;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartRenderingInfo;
import org.jfree.chart.ChartUtilities;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.entity.StandardEntityCollection;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.chart.servlet.ServletUtilities;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

public class ChartBuilder {
	public ChartBuilder() {
	}

	public static String generatePieChart(
			List ds, HttpSession session, PrintWriter pw, int width, int height, String chartType, boolean displayLegend, Class chartCustomizationClass
	) {
		String filename = null;

		try {
			if (ds.size() == 0) {
				System.out.println("No data has been found");
				throw new Exception("No data has been found");
			}

			String sData = "";
			String sData2 = "";
			DefaultPieDataset data = new DefaultPieDataset();

			for(ChartData chartData : ds) {
				sData = chartData.getLabel();
				sData2 = chartData.getValue();
				if (sData == null || sData.length() == 0) {
					sData = " ";
				}

				data.setValue(sData, new Double(sData2));
			}

			JFreeChart chart = null;
			if (chartType.equals("3D")) {
				chart = ChartFactory.createPieChart3D("", data, displayLegend, true, false);
			} else {
				chart = ChartFactory.createPieChart("", data, displayLegend, true, false);
			}

			chart = customizeChart(chart, chartCustomizationClass == null ? DefaultPieChart.class : chartCustomizationClass);
			filename = renderChartImage(chart, session, pw, width, height);
		} catch (Exception var14) {
			System.out.println("Exception - " + var14.toString());
			var14.printStackTrace(System.out);
			filename = "public_error_700x420.png";
		}

		return filename;
	}

	public static String generateBarChart3D(
			String chartTitle,
			String xText,
			String yText,
			String groupText,
			List ds,
			HttpSession session,
			PrintWriter pw,
			int width,
			int height,
			boolean displayLegend,
			Class chartCustomizationClass
	) {
		String filename = null;

		try {
			if (ds.size() == 0) {
				System.out.println("No data has been found");
				throw new Exception();
			}

			String sData = "";
			String sData2 = "";
			DefaultCategoryDataset dataset = new DefaultCategoryDataset();

			for(ChartData chartData : ds) {
				sData = chartData.getLabel();
				sData2 = chartData.getValue();
				if (sData == null || sData.length() == 0) {
					sData = " ";
				}

				try {
					if (chartData.getSecondaryValue() != null) {
						dataset.addValue(new Double(sData2), sData, chartData.getSecondaryValue());
					} else {
						dataset.addValue(new Double(sData2), sData, groupText);
					}
				} catch (Exception var18) {
					dataset.addValue(new Double(sData2), sData, groupText);
				}
			}

			JFreeChart chart = ChartFactory.createBarChart3D(chartTitle, xText, yText, dataset, PlotOrientation.VERTICAL, displayLegend, true, false);
			chart = customizeChart(chart, chartCustomizationClass == null ? Default3DBarChart.class : chartCustomizationClass);
			filename = renderChartImage(chart, session, pw, width, height);
		} catch (Exception var19) {
			System.out.println("Exception - " + var19.toString());
			var19.printStackTrace(System.out);
			filename = "public_error_700x420.png";
		}

		return filename;
	}

	public static String generateHorizontalBarChart(
			String chartTitle,
			String xText,
			String yText,
			List ds,
			HttpSession session,
			PrintWriter pw,
			PlotOrientation po,
			int width,
			int height,
			boolean displayLegend,
			Class chartCustomizationClass
	) {
		String filename = null;

		try {
			if (ds.size() == 0) {
				System.out.println("No data has been found");
				throw new Exception();
			}

			String sData = "";
			String sData2 = "";
			DefaultCategoryDataset dataset = new DefaultCategoryDataset();

			for(ChartData chartData : ds) {
				sData = chartData.getLabel();
				sData2 = chartData.getValue();
				if (sData == null || sData.length() == 0) {
					sData = " ";
				}

				dataset.addValue(new Double(sData2), sData, sData);
			}

			JFreeChart chart = ChartFactory.createBarChart(chartTitle, xText, yText, dataset, PlotOrientation.HORIZONTAL, displayLegend, true, false);
			chart = customizeChart(chart, chartCustomizationClass == null ? DefaultHorizontalBarChart.class : chartCustomizationClass);
			filename = renderChartImage(chart, session, pw, width, height);
		} catch (Exception var17) {
			System.out.println("Exception - " + var17.toString());
			var17.printStackTrace(System.out);
			filename = "public_error_700x420.png";
		}

		return filename;
	}

	public static String generateBarChart(
			String chartTitle,
			String xText,
			String yText,
			List ds,
			HttpSession session,
			PrintWriter pw,
			PlotOrientation po,
			int width,
			int height,
			boolean displayLegend,
			Class chartCustomizationClass
	) {
		String filename = null;

		try {
			if (ds.size() == 0) {
				System.out.println("No data has been found");
				throw new Exception();
			}

			String sData = "";
			String sData2 = "";
			DefaultCategoryDataset dataset = new DefaultCategoryDataset();

			for(ChartData chartData : ds) {
				sData = chartData.getLabel();
				sData2 = chartData.getValue();
				if (sData == null || sData.length() == 0) {
					sData = " ";
				}

				dataset.addValue(new Double(sData2), sData, sData);
			}

			JFreeChart chart = ChartFactory.createStackedBarChart(chartTitle, xText, yText, dataset, po, displayLegend, true, false);
			chart = customizeChart(chart, chartCustomizationClass == null ? DefaultBarChart.class : chartCustomizationClass);
			filename = renderChartImage(chart, session, pw, width, height);
		} catch (Exception var17) {
			System.out.println("Exception - " + var17.toString());
			var17.printStackTrace(System.out);
			filename = "public_error_700x420.png";
		}

		return filename;
	}

	private static String renderChartImage(JFreeChart chart, HttpSession session, PrintWriter pw, int width, int height) throws Exception {
		ChartRenderingInfo info = new ChartRenderingInfo(new StandardEntityCollection());
		String fileName = ServletUtilities.saveChartAsPNG(chart, width, height, info, session);
		ChartUtilities.writeImageMap(pw, fileName, info, false);
		pw.flush();
		return fileName;
	}

	private static JFreeChart customizeChart(JFreeChart chart, Class chartCustomizationClass) throws Exception {
		return chartCustomizationClass == null ? chart : ((ChartCustomization)chartCustomizationClass.newInstance()).modify(chart);
	}
}
