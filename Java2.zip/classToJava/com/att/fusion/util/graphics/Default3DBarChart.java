//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.util.graphics;

import java.awt.Color;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;

public class Default3DBarChart extends ChartCustomization {
	public Default3DBarChart() {
	}

	public JFreeChart modify(JFreeChart chart) {
		chart.setBackgroundPaint(Color.white);
		CategoryPlot plot = chart.getCategoryPlot();
		plot.setForegroundAlpha(1.0F);
		return chart;
	}
}
