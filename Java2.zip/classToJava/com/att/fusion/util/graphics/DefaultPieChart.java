//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.util.graphics;

import java.awt.Color;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.labels.StandardPieToolTipGenerator;
import org.jfree.chart.plot.PiePlot;

public class DefaultPieChart extends ChartCustomization {
	public DefaultPieChart() {
	}

	public JFreeChart modify(JFreeChart chart) {
		chart.setBackgroundPaint(Color.white);
		PiePlot plot = (PiePlot)chart.getPlot();
		plot.setNoDataMessage("No data available");
		plot.setToolTipGenerator(new StandardPieToolTipGenerator());
		return chart;
	}
}
