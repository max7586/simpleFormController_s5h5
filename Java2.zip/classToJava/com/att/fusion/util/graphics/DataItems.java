//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.util.graphics;

import java.util.ArrayList;

public class DataItems {
	private ArrayList itemArray = new ArrayList();

	public DataItems() {
	}

	public void add(Item InItem) {
		if (InItem != null) {
			this.itemArray.add(InItem);
		}
	}

	public int itemCount() {
		return this.itemArray.size();
	}

	public String getName(int index) {
		return index < this.itemArray.size() ? ((Item)this.itemArray.get(index)).getName() : "";
	}

	public double getNumber(int index) {
		return index < this.itemArray.size() ? ((Item)this.itemArray.get(index)).getNumber() : 0.0;
	}
}
