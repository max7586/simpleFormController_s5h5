//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.util.adapter.support;

import com.att.fusion.FusionObject;
import com.att.fusion.service.DomainService;
import com.att.fusion.service.QueryService;
import java.sql.Connection;
import java.util.LinkedHashMap;
import javax.servlet.ServletContext;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.SessionFactory;
import org.springframework.orm.hibernate3.SessionFactoryUtils;

public class FusionAdapter implements FusionObject {
	public static final String LOCAL_SESSION_FACTORY_KEY = "local";
	protected static final Log logger = LogFactory.getLog(FusionAdapter.class);
	private static DomainService domainService;
	private static QueryService queryService;
	private ServletContext servletContext;
	private static AdapterSessionFactoryContainer sessionFactoryContainer;

	public FusionAdapter() {
	}

	public ServletContext getServletContext() {
		return this.servletContext;
	}

	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

	public static DomainService getDomainService() {
		return domainService;
	}

	public static QueryService getQueryService() {
		return queryService;
	}

	public static AdapterSessionFactoryContainer getSessionFactoryContainer() {
		return sessionFactoryContainer;
	}

	public static LinkedHashMap getSessionFactories() {
		return getSessionFactoryContainer().getSessionFactories();
	}

	public void setDomainService(DomainService domainService) {
		FusionAdapter.domainService = domainService;
	}

	public void setQueryService(QueryService queryService) {
		FusionAdapter.queryService = queryService;
	}

	public void setSessionFactoryContainer(AdapterSessionFactoryContainer sessionFactoryContainer) {
		FusionAdapter.sessionFactoryContainer = sessionFactoryContainer;
	}

	public static Connection getConnection() {
		return getConnection("local");
	}

	public static Connection getConnection(String sessionFactoryKey) {
		logger.debug("getting connection for adapter...");
		Connection connection = null;

		try {
			SessionFactory sf = (SessionFactory)getSessionFactories().get(sessionFactoryKey);
			connection = SessionFactoryUtils.getDataSource(sf).getConnection();
		} catch (Exception var3) {
			logger.error("Could not acquire connection from session factory.");
			var3.printStackTrace();
		}

		return connection;
	}

	public static void releaseConnection(Connection conn) {
		try {
			conn.close();
			logger.debug("releasing connection from adapter...");
		} catch (Exception var2) {
			logger.error("Error while closing the connection.");
			var2.printStackTrace();
		}
	}
}
