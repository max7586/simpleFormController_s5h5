//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.util.adapter.support;

import java.util.LinkedHashMap;

public class AdapterSessionFactoryContainer {
	private LinkedHashMap sessionFactories;

	public AdapterSessionFactoryContainer() {
	}

	public LinkedHashMap getSessionFactories() {
		return this.sessionFactories;
	}

	public void setSessionFactories(LinkedHashMap sessionFactories) {
		this.sessionFactories = sessionFactories;
	}
}
