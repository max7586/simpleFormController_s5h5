//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.interceptor.support;

import com.att.fusion.FusionObject;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

public class FusionHandlerInterceptor extends HandlerInterceptorAdapter implements FusionObject {
    public FusionHandlerInterceptor() {
    }
}
