//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.interceptor;

import com.att.fusion.interceptor.support.FusionHandlerInterceptor;
import com.att.fusion.web.support.AppUtils;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class RaptorEmailAttachmentInterceptor extends FusionHandlerInterceptor {
	private static Log logger = LogFactory.getLog(SessionTimeoutInterceptor.class);

	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		HttpSession session = request.getSession(false);
		if (session == null && !this.isBypassLogin(request)) {
			logger.info("This internal url is not accessable.");
			response.sendRedirect("login.htm?session_expired=Y");
			return false;
		} else {
			return super.preHandle(request, response, handler);
		}
	}

	private boolean isBypassLogin(HttpServletRequest request) {
		logger.info(AppUtils.getRequestParameters(request));
		return request.getParameter("pdfAttachmentKey") != null
				&& request.getParameter("pdfAttachmentKey").length() >= 20
				&& request.getParameter("log_id") != null
				&& request.getParameter("action") != null
				&& request.getParameter("action").equalsIgnoreCase("raptor")
				&& request.getParameter("r_action") != null;
	}

	public RaptorEmailAttachmentInterceptor() {
	}
}
