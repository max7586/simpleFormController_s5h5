//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.interceptor;

import com.att.fusion.domain.User;
import com.att.fusion.exception.SessionExpiredException;
import com.att.fusion.interceptor.support.FusionHandlerInterceptor;
import com.att.fusion.web.support.AppUtils;
import com.att.fusion.web.support.UserUtils;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class SessionTimeoutInterceptor extends FusionHandlerInterceptor {
	private static Log logger = LogFactory.getLog(SessionTimeoutInterceptor.class);

	public SessionTimeoutInterceptor() {
	}

	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		HttpSession session = null;

		try {
			session = AppUtils.getSession(request);
			User user = UserUtils.getUserSession(request);
			if (user == null) {
				throw new SessionExpiredException();
			}
		} catch (SessionExpiredException var6) {
			if (logger.isErrorEnabled()) {
				logger.error("Session Expired ... ");
				response.sendRedirect("login.htm?session_expired=Y");
				return false;
			}
		}

		if (session == null) {
			if (request.getRequestURI().indexOf("login.htm") <= -1 && request.getRequestURI().indexOf("login_external.htm") <= -1) {
				logger.info("Session Timeout for User ");
				response.sendRedirect("login.htm?session_expired=Y");
				return false;
			} else {
				return super.preHandle(request, response, handler);
			}
		} else {
			return super.preHandle(request, response, handler);
		}
	}
}
