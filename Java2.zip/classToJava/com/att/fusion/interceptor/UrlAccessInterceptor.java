//
// Source code recreated from a .class file by Quiltflower
//

package com.att.fusion.interceptor;

import com.att.fusion.exception.UrlAccessRestrictedException;
import com.att.fusion.interceptor.support.FusionHandlerInterceptor;
import com.att.fusion.web.support.FusionController;
import com.att.fusion.web.support.UserUtils;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class UrlAccessInterceptor extends FusionHandlerInterceptor {
	private static Log logger = LogFactory.getLog(UrlAccessInterceptor.class);

	public UrlAccessInterceptor() {
	}

	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		String uri = request.getRequestURI();
		String url = uri.substring(uri.indexOf("/", 1) + 1);
		if (!UserUtils.isUrlAccessible(request, url)) {
			FusionController controller = (FusionController)handler;
			controller.setExceptionView("blank");
			throw new UrlAccessRestrictedException();
		} else {
			return super.preHandle(request, response, handler);
		}
	}
}
