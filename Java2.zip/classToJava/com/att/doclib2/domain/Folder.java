//
// Source code recreated from a .class file by Quiltflower
//

package com.att.doclib2.domain;

import com.att.fusion.domain.support.DomainVo;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class Folder extends DomainVo {
	private String folderName;
	private Long parentFolderId;
	private String descr;
	private String createdName;
	private String modifiedName;
	private String readOnly;
	private String fullPath;
	private boolean needNotification;
	private int subFolderCount;
	private List files;
	private List urls;
	private Set accesses = new TreeSet();
	private Set notifies;
	Folder parentFolder;

	public Folder() {
	}

	public boolean getDeletable() {
		return this.subFolderCount == 0 && this.files.size() == 0 && this.urls.size() == 0;
	}

	public String getDescr() {
		return this.descr;
	}

	public void setDescr(String descr) {
		this.descr = descr;
	}

	public String getFolderName() {
		return this.folderName;
	}

	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}

	public Long getParentFolderId() {
		return this.parentFolderId;
	}

	public void setParentFolderId(Long parentFolderId) {
		this.parentFolderId = parentFolderId;
	}

	public List getFiles() {
		return this.files;
	}

	public void setFiles(List files) {
		this.files = files;
	}

	public List getUrls() {
		return this.urls;
	}

	public void setUrls(List urls) {
		this.urls = urls;
	}

	public String getCreatedName() {
		return this.createdName;
	}

	public void setCreatedName(String createdName) {
		this.createdName = createdName;
	}

	public String getModifiedName() {
		return this.modifiedName;
	}

	public void setModifiedName(String modifiedName) {
		this.modifiedName = modifiedName;
	}

	public String getReadOnly() {
		return this.readOnly;
	}

	public void setReadOnly(String readOnly) {
		this.readOnly = readOnly;
	}

	public Folder getParentFolder() {
		return this.parentFolder;
	}

	public void setParentFolder(Folder parentFolder) {
		this.parentFolder = parentFolder;
	}

	public Set getAccesses() {
		return this.accesses;
	}

	public void setAccesses(Set accesses) {
		this.accesses = accesses;
	}

	public String getFullPath() {
		return this.fullPath;
	}

	public void setFullPath(String fullPath) {
		this.fullPath = fullPath;
	}

	public boolean getNeedNotification() {
		return this.needNotification;
	}

	public void setNeedNotification(boolean needNotification) {
		this.needNotification = needNotification;
	}

	public Set getNotifies() {
		return this.notifies;
	}

	public void setNotifies(Set notifies) {
		this.notifies = notifies;
	}

	public int getSubFolderCount() {
		return this.subFolderCount;
	}

	public void setSubFolderCount(int subFolderCount) {
		this.subFolderCount = subFolderCount;
	}
}
