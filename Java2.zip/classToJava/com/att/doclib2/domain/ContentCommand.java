//
// Source code recreated from a .class file by Quiltflower
//

package com.att.doclib2.domain;

import com.att.fusion.command.support.FusionCommand;
import com.att.fusion.util.SystemProperties;
import java.util.Set;
import java.util.TreeSet;

public class ContentCommand extends FusionCommand {
	Set<File> files;
	Set<Url> urls;
	public static final int NUM_UPLOAD_FILES = Integer.parseInt(SystemProperties.getProperty("num_upload_files"));

	public ContentCommand() {
	}

	public Set<File> getFiles() {
		return this.files;
	}

	public void setFiles(Set<File> files) {
		this.files = files;
	}

	public Set<Url> getUrls() {
		return this.urls;
	}

	public void setUrls(Set<Url> urls) {
		this.urls = urls;
	}

	public void initFiles() {
		this.files = new TreeSet();

		for(int i = 0; i < NUM_UPLOAD_FILES; ++i) {
			this.files.add(new File());
		}
	}

	public void initUrls() {
		this.urls = new TreeSet();

		for(int i = 0; i < NUM_UPLOAD_FILES; ++i) {
			this.urls.add(new Url());
		}
	}
}
