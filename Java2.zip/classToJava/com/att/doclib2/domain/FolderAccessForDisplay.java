//
// Source code recreated from a .class file by Quiltflower
//

package com.att.doclib2.domain;

public class FolderAccessForDisplay extends FolderAccess {
	private Long folderId;
	private String userName;
	private String roleName;
	private boolean notify;

	public FolderAccessForDisplay() {
	}

	public Long getFolderId() {
		return this.folderId;
	}

	public void setFolderId(Long folderId) {
		this.folderId = folderId;
	}

	public boolean getNotify() {
		return this.notify;
	}

	public void setNotify(boolean notify) {
		this.notify = notify;
	}

	public String getRoleName() {
		return this.roleName;
	}

	public void setRoleName(String roleName) {
		this.roleName = roleName;
	}

	public String getUserName() {
		return this.userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
}
