//
// Source code recreated from a .class file by Quiltflower
//

package com.att.doclib2.domain;

import com.att.fusion.domain.support.DomainVo;

public class TreeNode extends DomainVo {
	private String folderName;
	private Long parentFolderId;
	private String readOnly;
	private int subFolderCount;

	public TreeNode() {
	}

	public String getFolderName() {
		return this.folderName;
	}

	public void setFolderName(String folderName) {
		this.folderName = folderName;
	}

	public Long getParentFolderId() {
		return this.parentFolderId;
	}

	public void setParentFolderId(Long parentFolderId) {
		this.parentFolderId = parentFolderId;
	}

	public String getReadOnly() {
		return this.readOnly;
	}

	public void setReadOnly(String readOnly) {
		this.readOnly = readOnly;
	}

	public int getSubFolderCount() {
		return this.subFolderCount;
	}

	public void setSubFolderCount(int subFolderCount) {
		this.subFolderCount = subFolderCount;
	}
}
